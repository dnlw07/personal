import os
from pathlib import Path
from glob import glob
import re
import numpy as np
from datetime import datetime
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
# from excel_functions import *


def generate_install_files(output_package_path, package_name):

		# %%
		order_lst = ['D2_t00018_input_file_definition.sql','t00020_output_file_definition.sql','t00022_conversion_definition.sql','t00019_file_column_format.sql','t00021_field_conversion_map.sql','t00010_table_definition.sql','D2_t00007_dtlk_load_definition.sql','t00023_value_conversion_map.sql','t00016_etl_pkg_definition.sql']
		remove_lst = ['INSTALL.TXT', 'all.sql'] + order_lst


		# create install.txt file body
		install_items = [['/'.join(file_path.split(os.path.sep)[7:-1]), file_path.split(os.path.sep)[-1]] for file_path in glob(os.path.join(output_package_path, '**\*.*'), recursive=True) if file_path.split(os.path.sep)[-1] not in remove_lst] 

		items_bq = [item for item in install_items if item[0] != 'ANOW/JSON']
		items_postgres = [['/'.join(file_path.split(os.path.sep)[7:-1]), file_path.split(os.path.sep)[-1]] for file_path in glob(os.path.join(output_package_path, '**\*.*'), recursive=True) if file_path.split(os.path.sep)[-1] in order_lst] 
		items_postgres_sorted = sorted(items_postgres, key=lambda x: order_lst.index(x[1]))
		items_anow = [item for item in install_items if 'ANOW' in item[0]]
		
		if items_anow:
			install_items_sorted = items_bq + items_postgres_sorted + [['ANOW', 'anow_export.json'], ['ANOW', 'LIST.txt']]
		else:
			install_items_sorted = items_bq + items_postgres_sorted

		current_date = datetime.now()
		current_date = current_date.strftime("%d.%m.%Y")
		install_header_lst = [f'000|header|{package_name}|{current_date}|Bank|PZ006369']

		install_body_lst = []
		for num, (dir, file_name) in enumerate(install_items_sorted):
			if dir != '':
				# process_type, db_type
				if dir.split("/")[0] == "BQ":
					db_type = "gc"
					process_type = "run_bq"
				elif dir.split("/")[0] == "POSTGRES":
					db_type = "postgresql"
					process_type = "run_psql"
				elif dir.split("/")[0] == "ANOW":
					db_type = "anow"
					if "json" in file_name.lower():
						process_type = "export_proc"
					else:
						process_type = "load_proc"
				else:
					db_type = "error"
					process_type = "error"

				# file_format
				if "POSTGRES" in dir:
					file_format = "|DLMETADATA"
				elif "LIST.txt" in file_name:
					file_format = "|JSON"
				else:
					file_format = ""

				if not re.match('^(T1|PR)_.*', file_name):
					file_name = re.sub('D2', '[ENV]', file_name)
					install_body_lst.append(f'{num+1:03}|auto|ohio|{db_type}|{process_type}|{dir}|{file_name}{file_format}')

		install_lst = install_header_lst + install_body_lst
		install_txt = '\n'.join(install_lst) + '\n'

		# save procedure into file
		install_file = 'INSTALL.TXT'
		install_file_path = os.path.join(output_package_path, install_file)
		with open(install_file_path, 'w', encoding='utf-8', newline='\n') as f:
			f.write(install_txt)


# # Manually generate/update INSTALL.txt file
# package_path = Path(r'C:\Dane\repo\git\INSTALL\GCP\GCP-IDA_INS-06.00')
# generate_install_files(package_path, package_path.name)

