import os
import numpy as np
from datetime import datetime

# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
from excel_functions import *


def generate_metadata_files(main_dct, t16_dct, t18_dct, t19_dct, t20_dct, t21_dct, t22_dct, t10_dct, t07_dct, output_path, output_package_path, xDA, package_name, sheet_names):

	file_cd_lst = [f'\'%_{t18_dct[sheet_name][0]["in_file_cd"][3:]}\'' for sheet_name in sheet_names]
	table_nm_lst = [f'\'{t10_dct[sheet_name][0]["table_nm"]}\'' for sheet_name in sheet_names]
	file_cd_str = ', '.join(file_cd_lst)
	table_nm_str = ', '.join(table_nm_lst)


	log_script_txt = f'''
---------------------------------------------------------------------------------------
/* LOG SCRIPTS */
---------------------------------------------------------------------------------------
-- check SDA logs
SELECT * FROM mda_01_log.t01007_bucket_notification ORDER BY created_ts desc;
select load_key, tech_update_ts, extract_due_dt, extract_version, sys_cd, extract_mode_cd, src_file_nm, gcp_dataset_nm, gcp_table_nm, db_connection_nm, import_status_cd, extraction_st_ts, extraction_end_ts, transform_st_ts, transform_end_ts, gcs_load_st_ts, gcs_load_end_ts, bq_load_st_ts, bq_load_end_ts from mda_01_log.t01001_dtlk_load_control where 1=1 and gcp_table_nm in ({table_nm_str}) order by tech_update_ts desc;
select * from mda_01_log.t01001_dtlk_load_control where 1=1 and gcp_table_nm in ({table_nm_str}) order by tech_update_ts desc;
select * from mda_04_sem.t04001_dtlk_load_ext_sys_sem where 1=1 order by tech_insert_ts desc;

-- statusy t01001_dtlk_load_control:
-- WAITING
-- QUEUE

'''
	select_script_txt = '''
---------------------------------------------------------------------------------------
/* SELECT SCRIPTS */
---------------------------------------------------------------------------------------
'''
	delete_script_txt = '''
---------------------------------------------------------------------------------------
/* DELETE SCRIPTS */
---------------------------------------------------------------------------------------
'''
	insert_script_txt = '''
---------------------------------------------------------------------------------------
/* INSERT SCRIPTS */
---------------------------------------------------------------------------------------
'''
	debug_script_txt = '''
---------------------------------------------------------------------------------------
/* DEBUG SCRIPTS */
---------------------------------------------------------------------------------------
'''

	for sheet_name in sheet_names:

		insert_script_t18 = generate_insert_sripts(t18_dct[sheet_name], 'mda_00_def', 't00018_input_file_definition', mode='multi_line')
		insert_script_t20 = generate_insert_sripts(t20_dct[sheet_name], 'mda_00_def', 't00020_output_file_definition', mode='multi_line')
		insert_script_t10 = generate_insert_sripts(t10_dct[sheet_name], 'mda_00_def', 't00010_table_definition', mode='multi_line')
		insert_script_t07 = generate_insert_sripts(t07_dct[sheet_name], 'mda_00_def', 't00007_dtlk_load_definition', mode='multi_line')
		insert_script_t19 = generate_insert_sripts(t19_dct[sheet_name], 'mda_00_def', 't00019_file_column_format')
		insert_script_t21 = generate_insert_sripts(t21_dct[sheet_name], 'mda_00_def', 't00021_field_conversion_map')
		insert_script_t22 = generate_insert_sripts(t22_dct[sheet_name], 'mda_00_def', 't00022_conversion_definition')
		insert_script_t16 = generate_insert_sripts(t16_dct[sheet_name], 'mda_00_def', 't00016_etl_pkg_definition', mode='multi_line')

		# insert_script_lst = [insert_script_t18 + insert_script_t20 + insert_script_t10 + insert_script_t07 + insert_script_t22]
		insert_lst = []
		insert_lst.append(insert_script_t18)
		insert_lst.append(insert_script_t20)
		insert_lst.append(insert_script_t10)
		insert_lst.append(insert_script_t07)
		insert_lst.append(insert_script_t19)
		insert_lst.append(insert_script_t21)
		insert_lst.append(insert_script_t22)
		insert_lst.append(insert_script_t16)

		insert_txt = ''.join(insert_lst)


		# generate delete scripts for each meta table
		file_cd = t18_dct[sheet_name][0]['in_file_cd'][3:]
		dataset_nm = t10_dct[sheet_name][0]['dataset_nm']
		table_nm = t10_dct[sheet_name][0]['table_nm']


		# create files to store the SQL scripts
		insert_table_lst = ['t00018_input_file_definition','t00020_output_file_definition','t00010_table_definition','t00007_dtlk_load_definition', 't00019_file_column_format', 't00021_field_conversion_map', 't00022_conversion_definition', 't00016_etl_pkg_definition']
		for meta_table_nm, insert_script in zip(insert_table_lst, insert_lst):
			if meta_table_nm in ['t00018_input_file_definition','t00007_dtlk_load_definition']:
				for env in ['D2', 'T1', 'PR']:
					
					if env == 'D2':
						pass
					elif env == 'T1':
						insert_script = re.sub('pl_pkobp_datalake_dev_transporter_sda-j9q7gd', 'pl_pkobp_datalake_tst_transporter_sda-cnrgoe', insert_script)
						insert_script = re.sub('pl_pkobp_datalake_dev_input_converted_files_sda-swdwz5', 'pl_pkobp_datalake_tst_input_converted_files_sda-r4qdir', insert_script)
					elif env == 'PR':
						insert_script = re.sub('pl_pkobp_datalake_tst_transporter_sda-cnrgoe', 'pl_pkobp_datalake_prd_transporter_sda-4nji8f', insert_script)
						insert_script = re.sub('pl_pkobp_datalake_tst_input_converted_files_sda-r4qdir', 'pl_pkobp_datalake_prd_input_converted_files_sda-y96car', insert_script)
					
					file_path = rf'{output_package_path}\POSTGRES\DML\{env}_{meta_table_nm}.sql'
					with open(file_path, 'a', encoding='utf-8') as file:
						file.write(insert_script)
			else:
				file_path = rf'{output_package_path}\POSTGRES\DML\{meta_table_nm}.sql'
				with open(file_path, 'a', encoding='utf-8') as file:
					file.write(insert_script)



		select_script_txt = select_script_txt + f'''
/* {sheet_name} */
-- input file errors
select * from mda_00_def.t00007_dtlk_load_definition where gcp_table_nm ilike any(array['%_{file_cd}']);
select * from mda_00_def.t00010_table_definition where table_nm ilike any(array['%_{file_cd}']);
select * from mda_00_def.t00016_etl_pkg_definition where table_nm ilike any(array['%_{file_cd}']);
select * from mda_00_def.t00018_input_file_definition where in_file_cd ilike any(array['%_{file_cd}']);

-- conversion errors
select * from mda_00_def.t00019_file_column_format where in_out_file_cd ilike any(array['%_{file_cd}']);
select * from mda_00_def.t00021_field_conversion_map where conversion_cd ilike any(array['%_{file_cd}']);
select * from mda_00_def.t00022_conversion_definition where in_file_cd ilike any(array['%_{file_cd}']);
select * from mda_00_def.t00023_value_conversion_map  where output_file_cd ilike any(array['%_{file_cd}']);

-- output file errors (after conversion)
select * from mda_00_def.t00020_output_file_definition where out_file_cd ilike any(array['%_{file_cd}']);
select * from mda_00_def.t00002_ext_table_column_list where table_nm ilike any(array['%_{file_cd}']);

'''



		delete_script_txt = delete_script_txt + f'''
/* {sheet_name} */
-- remove logs
-- Remark: to delete SDA metadata following records needs to be deleted first
select * from mda_01_log.t01009_file_name_fields where in_file_cd ilike any(array['%_{file_cd}']);
delete from mda_01_log.t01009_file_name_fields where in_file_cd ilike any(array['%_{file_cd}']);

-- conversion errors
delete from mda_00_def.t00023_value_conversion_map  where output_file_cd ilike any(array['%_{file_cd}']);
delete from mda_00_def.t00021_field_conversion_map where conversion_cd ilike any(array['%_{file_cd}']);
delete from mda_00_def.t00019_file_column_format where in_out_file_cd ilike any(array['%_{file_cd}']);

-- output file errors (after conversion)
delete from mda_00_def.t00002_ext_table_column_list where table_nm ilike any(array['%_{file_cd}']);
delete from mda_00_def.t00022_conversion_definition where in_file_cd ilike any(array['%_{file_cd}']);
delete from mda_00_def.t00020_output_file_definition where out_file_cd ilike any(array['%_{file_cd}']);

-- input file errors
delete from mda_00_def.t00016_etl_pkg_definition where table_nm ilike any(array['%_{file_cd}']);
delete from mda_00_def.t00018_input_file_definition where in_file_cd ilike any(array['%_{file_cd}']);
delete from mda_00_def.t00010_table_definition where table_nm ilike any(array['%_{file_cd}']);
delete from mda_00_def.t00007_dtlk_load_definition where gcp_table_nm ilike any(array['%_{file_cd}']);

'''


		insert_script_txt = insert_script_txt + f'''
/* {sheet_name} */
{insert_txt}

'''

	debug_script_txt = debug_script_txt + f'''

-- debug MISSING_META_ERROR status
SELECT 
case 
when ifd.in_file_cd = 'in_ozsi_wmdtwpb'then 'EKSTRAKT_PLIKOWY'
when ifd.in_file_cd = 'in_pkof_nsp' then 'EKSTRAKT_BAZODANOWY'
end as UNIT_TEST,
*
FROM mda_00_def.t00022_conversion_definition cd

-- INNER JOIN mda_00_def.t00018_input_file_definition ifd 
-- ON cd.in_file_cd = ifd.in_file_cd 

-- INNER JOIN mda_00_def.t00020_output_file_definition ofd
-- ON cd.out_file_cd = ofd.out_file_cd 
-- 
-- INNER JOIN mda_00_def.t00007_dtlk_load_definition dld
-- ON cd.out_file_cd = dld.extract_nm 

-- INNER JOIN mda_00_def.t00010_table_definition td 
-- ON (CASE WHEN dld.gcp_project_nm = 'GCP_DTLK_PROJECT_ID' THEN 'GCP_DTLK_PROJECT_ID' ELSE dld.gcp_project_nm END) = 
-- (CASE WHEN td.project_id = 'GCP_DTLK_PROJECT_ID' THEN 'GCP_DTLK_PROJECT_ID' ELSE td.project_id END)
-- AND dld.gcp_dataset_nm = td.dataset_nm 
-- AND dld.gcp_table_nm = td.table_nm 

-- INNER JOIN mda_00_def.t00016_etl_pkg_definition epd
-- ON (CASE WHEN dld.gcp_project_nm = 'GCP_DTLK_PROJECT_ID' THEN 'GCP_DTLK_PROJECT_ID' ELSE dld.gcp_project_nm END) = 
-- (CASE WHEN epd.project_id = 'GCP_DTLK_PROJECT_ID' THEN 'GCP_DTLK_PROJECT_ID' ELSE epd.project_id END)
-- AND dld.gcp_dataset_nm = epd.dataset_nm 
-- AND dld.gcp_table_nm = epd.table_nm 
-- AND dld.gcp_etl_pkg_cd = epd.gcp_etl_pkg_cd 

WHERE 1=1
and ifd.in_file_cd ilike any(array['%_pkof_nsp', '%_bgdtiaf',/* wstaw tuaj --> */ {file_cd_str}])
order by unit_test desc
;


-- debug ERROR status
-- input file errors
select * from mda_00_def.t00007_dtlk_load_definition where gcp_table_nm ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);
select * from mda_00_def.t00010_table_definition where table_nm ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);
select * from mda_00_def.t00016_etl_pkg_definition where table_nm ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);
select * from mda_00_def.t00018_input_file_definition where in_file_cd ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);
select * from mda_00_def.t00022_conversion_definition where in_file_cd ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);

-- conversion errors
select * from mda_00_def.t00019_file_column_format where in_out_file_cd ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);
select * from mda_00_def.t00021_field_conversion_map where conversion_cd ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);
select * from mda_00_def.t00023_value_conversion_map  where output_file_cd ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);

-- output file errors (after conversion)
select * from mda_00_def.t00020_output_file_definition where out_file_cd ilike any(array['%_pkof_nsp', '%_bgdtiaf', {file_cd_str}]);

--select * from mda_00_def.t00002_ext_table_column_list where table_nm ilike 'NSP'; /* tylko ekstrakty bazodanowe??? */

'''

	script_txt = log_script_txt + select_script_txt + delete_script_txt + insert_script_txt + debug_script_txt

	# create a signle file to store all scripts
	file_path = rf'{output_path}\SDA_{package_name.upper()}_dml_metadata.sql'
	with open(file_path, 'w', encoding='utf-8') as file:
		file.write(script_txt)

	# create a signle file to store all scripts
	timestamp = datetime.now()
	timestamp_str = timestamp.strftime("%Y-%m-%d_%H_%M_%S_%f")
	file_path = rf'{output_path}\_archive\backup\SDA_dml_metadata_{timestamp_str}.sql'
	with open(file_path, 'w', encoding='utf-8') as file:
		file.write(script_txt)

