#%%
import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
import re
import pandas as pd
from openpyxl import load_workbook, Workbook
# from datetime import datetime
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from copy import deepcopy
from gen_sda_ddl import generate_ddl_files
from gen_sda_metadata import generate_metadata_files
from gen_sda_install import generate_install_files
# from gen_tag_list import generate_tag_list_file


# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
from excel_functions import *
from control_panel import package_id, xDA, version, tech_spec_file_path, sda_sheet_names



########################################################################################################################
# CONTROL PANEL
########################################################################################################################

xDA = 'SDA'
# package_id = 'ACCB'
# sda_sheet_names = ['BGDTMDF','BGDTIAF']  # input here sheet_names, table_names or table codes ('txxxxxx')
# tech_spec_file_path = rf"C:\Users\PZ006369\Desktop\Specyfikacje_Interfejsow_OZSI_v0.14.xlsx"
# version = '01.00'

########################################################################################################################


tech_spec_wb_paths = [tech_spec_file_path] # if None then generates only DDL files

package_name = f'GCP-{xDA}_{package_id}-{version}'
tag_name = f'GCP_{xDA}_{package_id}_{version}'

# path to executable file
# base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output', package_name)
output_path = rf'C:\Dane\repo\python\Generator\_output'
output_package_path = rf'C:\Dane\repo\python\Generator\_output\{package_name}'


# create missing folders in a package if yet not exist
if not os.path.exists(os.path.join(output_package_path)):
	os.makedirs(os.path.join(output_package_path))
if not os.path.exists(os.path.join(output_package_path, 'BQ')):
	os.makedirs(os.path.join(output_package_path, 'BQ'))
if not os.path.exists(os.path.join(output_package_path, 'BQ', 'DDL')):
	os.makedirs(os.path.join(output_package_path, 'BQ', 'DDL'))
if not os.path.exists(os.path.join(output_package_path, 'POSTGRES')):
	os.makedirs(os.path.join(output_package_path, 'POSTGRES'))
if not os.path.exists(os.path.join(output_package_path, 'POSTGRES', 'DML')):
	os.makedirs(os.path.join(output_package_path, 'POSTGRES', 'DML'))


# clear output directory
[os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.sql'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany


# loop through workbooks
for tech_spec_wb_path in tech_spec_wb_paths:

	tech_spec_wb = load_workbook(tech_spec_wb_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	sheet_names = [string for string in tech_spec_wb.sheetnames if string in sda_sheet_names]
	main_dct = all_datasets_by_table_name(tech_spec_wb, sheet_names, table_name_pattern='Lp.', offset_header_rows=0, orientation='H')

	t18_dct = all_datasets_by_table_name(tech_spec_wb, sheet_names, table_name_pattern='t00018_input_file_definition', offset_header_rows=1, orientation='V')
	t20_dct = all_datasets_by_table_name(tech_spec_wb, sheet_names, table_name_pattern='t00020_output_file_definition', offset_header_rows=1, orientation='V')
	t22_dct = all_datasets_by_table_name(tech_spec_wb, sheet_names, table_name_pattern='t00022_conversion_definition', offset_header_rows=1, orientation='V')
	t10_dct = all_datasets_by_table_name(tech_spec_wb, sheet_names, table_name_pattern='t00010_table_definition', offset_header_rows=1, orientation='V')
	t07_dct = all_datasets_by_table_name(tech_spec_wb, sheet_names, table_name_pattern='t00007_dtlk_load_definition', offset_header_rows=1, orientation='V')
	
	# filter only first row
	t18_dct = {sheet_name: [row_lst[0]] for sheet_name, row_lst in t18_dct.items() if row_lst}
	t20_dct = {sheet_name: [row_lst[0]] for sheet_name, row_lst in t20_dct.items() if row_lst}
	t22_dct = {sheet_name: [row_lst[0]] for sheet_name, row_lst in t22_dct.items() if row_lst}
	t10_dct = {sheet_name: [row_lst[0]] for sheet_name, row_lst in t10_dct.items() if row_lst}
	t07_dct = {sheet_name: [row_lst[0]] for sheet_name, row_lst in t07_dct.items() if row_lst}
	

	# rename keys to column_names
	t18_key_name_map = {
		'ID interfejsu': 'in_file_cd',
		'Opis': 'in_file_desc',
		'System źródłowy': 'input_file_sys_cd',
		'Nazwa interfejsu': '', ## remove key by mapping to empty string
		'Typ interfejsu': '', ## remove key by mapping to empty string
		'Tryb generowania': '', ## remove key by mapping to empty string
		'Harmonogram generowania': '', ## remove key by mapping to empty string
		'Sposób wersjonowania ekstraktu': '', ## remove key by mapping to empty string
		'Nazwa pliku z semaforem': '', ## remove key by mapping to empty string
		'Przykładowa nazwa pliku': '', ## remove key by mapping to empty string
		'Maska nazwy pliku': '', ## remove key by mapping to empty string
		'Maska nazwy pliku (regexp)': 'file_name_mask',
		'Maska nazwy pliku (pola)': 'file_name_fields',
		'Typ pliku': 'file_type',
		'Kodowanie': 'character_encoding_system',
		'Strona kodowa': 'character_encoding_cd',
		'Numer pierwszego wiersza z danymi': 'skipped_number_lines',
		'Numer ostatniego wiersza z danymi (liczony od końca)': '', ## remove key by mapping to empty string
		'Nagłówek (T - Tak, N - Nie)': 'is_header',
		'Stopka (T - Tak, N - Nie)': 'is_footer',
		'Separator rekordów': 'record_separator',
		'Separator pól': 'field_separator',
		'Separator dziesiętny': 'decimal_point',
		'Separator tysięczny': 'digit_separator',
		'Kwalifikator tekstu': '', ## remove key by mapping to empty string
		'Znak końca linii': '', ## remove key by mapping to empty string
		"Nazwa projektu GCP lub 'GCP_DTLK_PROJECT_ID'": 'gcp_project_nm',
		'Typ zasobu docelowego': 'storage_type',
		'Nazwa zasobu docelowego': 'resource_nm',
		'Ścieżka do pliku': 'file_path',
		'czy string w cudzysłowach (T - Tak, N - Nie)': 'is_quote',
		'czy string w cudzysłowach podwójnych (T - Tak, N - Nie)': 'is_double_quote',
		'znak cytowania: " (wartość domyślna) lub \' ': 'quote'
	}

	t20_key_name_map = {
		'ID interfejsu': 'out_file_cd',
		'Obszar, w którym tworzony jest plik (IMPORT/EXPORT)': 'file_area',
		'ID systemu, do którego wysyłany jest plik': 'file_sys_cd',
		'Format nazwy pliku': 'file_name_format',
		'Rozszerzenie pliku': 'file_type',
		'Kodowanie': 'character_encoding_system',
		'Strona kodowa': 'character_encoding_cd',
		'Nagłówek (T - Tak, N - Nie)': 'is_header',
		'Stopka (T - Tak, N - Nie)': 'is_footer',
		'Separator rekordów': 'record_separator',
		'Separator pól': 'field_separator',
		'Separator dziesiętny': 'decimal_point',
		'Separator tysięczny': 'digit_separator',
		'Typ docelowego zasobu do zapisu': 'gcp_resource_type',
		'Ścieżka do pliku': 'file_path'
	}

	t10_key_name_map = {
		'Nazwa tabeli': 'table_nm',
		'Nazwa datasetu': 'dataset_nm',
		'Nazwa projektu lub \'GCP_DTLK_PROJECT_ID\'': 'project_id',
		'Typ tabeli': 'model_table_type_cd',
		'Kolumna partycjonowania': 'partitioned_by',
		'Lista kolumn klucza głównego': 'pk_column_list',
		'Tryb ekstraktu': 'default_mode_cd',
		'Nazwa semafora SIN': 'sin_publish_sem_nm',
		'Nazwa metryki SIN': 'sin_metric_nm'
	}

	t07_key_name_map = {
		'Nazwa pakietu ETL': 'gcp_etl_pkg_cd',
		'Tryb ekstraktu': 'extract_mode_cd',
		'Format pliku': 'file_format',
		'Nazwa node SIN do połącznia z VM': 'tgt_sin_os_node_nm',
		'Ścieżka do pliku na VM z plikiem do konwersji': 'gcp_data_root_in_path',
		'Ścieżka do pliku na VM z plikiem po konwersji': 'gcp_data_root_path',
		'Nazwa tabeli': 'gcp_table_nm',
		'Nazwa datasetu': 'gcp_dataset_nm',
		'Lista mailingowa do notyfikacji': 'notification_mail',
		'Nazwa WFL ScheduleIN': 'process_sin_wfl_nm',
	}

	t21_key_name_map = {
		# '': 'conversion_cd',
		'Lp.': 'conversion_index',
		# '': 'conversion_field_index',
		# '': 'output_file_cd',
		'Pole interfejsu wyjściowego/tabeli': 'output_field_nm',
		# '': 'src_file_cd',
		'Pole interfejsu wejściowego': 'src_field_nm',
		'Standaryzacja - opis techniczny': 'conversion_type',
		# '': 'regex_value',
		# '': 'default_value'
	}


	t19_key_name_map = {
		# '': 'in_out_file_cd',
		# '': 'in_out_cd',
		'Pole interfejsu wyjściowego/tabeli': 'field_nm',
		'Lp.': 'field_index',
		'Typ danych': 'field_type',
		'Długość pola': 'fileld_length',
		# 'Długość pola 2': 'field_length_precision',
		# 'Długość pola 2': 'field_length_scale',
		'Format': 'filed_format',
	}

	t22_key_name_map = {
		'Opis konwersji': 'conversion_dsc',
		'Nazwa programu konwertującego': 'program_conversion',
		'Ścieżka do programu konwertującego': 'program_path',
	}

	# t23_key_name_map = {
	# }


	# clone main_dct
	t16_dct = {}
	t19_dct = {}
	t21_dct = deepcopy(main_dct)
	t22_dct = deepcopy(t18_dct)
	t22_dct = {sheet_name: [{}] for sheet_name, row_lst in t22_dct.items() if row_lst} # create empty dict structure
	# t23_dct = deepcopy(main_dct)

	# Rename keys in the dictionary
	t18_dct = {outer_key: [{t18_key_name_map.get(k, k): v for k, v in inner_dict.items()} for inner_dict in inner_list] for outer_key, inner_list in t18_dct.items()}
	t20_dct = {outer_key: [{t20_key_name_map.get(k, k): v for k, v in inner_dict.items()} for inner_dict in inner_list] for outer_key, inner_list in t20_dct.items()}
	t10_dct = {outer_key: [{t10_key_name_map.get(k, k): v for k, v in inner_dict.items()} for inner_dict in inner_list] for outer_key, inner_list in t10_dct.items()}
	t07_dct = {outer_key: [{t07_key_name_map.get(k, k): v for k, v in inner_dict.items()} for inner_dict in inner_list] for outer_key, inner_list in t07_dct.items()}
	t19_dct = {outer_key: [{t21_key_name_map.get(k, k): v for k, v in inner_dict.items()} for inner_dict in inner_list] for outer_key, inner_list in t19_dct.items()}
	t21_dct = {outer_key: [{t21_key_name_map.get(k, k): v for k, v in inner_dict.items()} for inner_dict in inner_list] for outer_key, inner_list in t21_dct.items()}
	t22_dct = {outer_key: [{t22_key_name_map.get(k, k): v for k, v in inner_dict.items()} for inner_dict in inner_list] for outer_key, inner_list in t22_dct.items()}
	# t23_dct = {outer_key: [{t07_key_name_map.get(k, k): v for k, v in inner_dict.items()} for inner_dict in inner_list] for outer_key, inner_list in t23_dct.items()}

	
	for sheet_name in sheet_names:

		# get values
		file_cd = deepcopy(t18_dct[sheet_name][0]['in_file_cd'].strip().lower())


		# update values
		t07_dct[sheet_name][0]['file_format'] = 'avro'
		t07_dct[sheet_name][0].update({'gcp_dataset_nm': t07_dct[sheet_name][0]['gcp_dataset_nm'].lower()})
		t07_dct[sheet_name][0].update({'gcp_table_nm': t07_dct[sheet_name][0]['gcp_table_nm'].lower()})

		if t18_dct[sheet_name][0]['record_separator'].strip().upper() == 'CRLF':
			record_separator_hex = '0x0a'
		elif t18_dct[sheet_name][0]['record_separator'].strip().upper() == 'LF':
			record_separator_hex = '0x0a'
		else:
			record_separator_hex = f"0x{t18_dct[sheet_name][0]['record_separator'].encode('utf-8').hex()}"

		if t18_dct[sheet_name][0]['digit_separator'].strip() != '':
			digit_separator_hex = f"0x{t18_dct[sheet_name][0]['digit_separator'].encode('utf-8').hex()}"
		else:
			digit_separator_hex = ''

		if t18_dct[sheet_name][0]['is_header'].strip().upper() == 'T':
			is_header_val = True
		elif t18_dct[sheet_name][0]['is_header'].strip().upper() == 'N':
			is_header_val = False
		else:
			is_header_val = None

		if t18_dct[sheet_name][0]['is_footer'].strip().upper() == 'T':
			is_footer_val = True
		elif t18_dct[sheet_name][0]['is_footer'].strip().upper() == 'N':
			is_footer_val = False
		else:
			is_footer_val = None

		if t18_dct[sheet_name][0]['is_quote'].strip().upper() == 'T':
			is_quote_val = True
		elif t18_dct[sheet_name][0]['is_quote'].strip().upper() == 'N':
			is_quote_val = False
		else:
			is_quote_val = None

		if t18_dct[sheet_name][0]['is_double_quote'].strip().upper() == 'T':
			is_double_quote_val = True
		elif t18_dct[sheet_name][0]['is_double_quote'].strip().upper() == 'N':
			is_double_quote_val = False
		else:
			is_double_quote_val = None

		t18_dct[sheet_name][0].update({'in_file_cd': f'in_{file_cd}'})
		t18_dct[sheet_name][0].update({'record_separator': record_separator_hex})
		t18_dct[sheet_name][0].update({'field_separator': f"0x{t18_dct[sheet_name][0]['field_separator'].encode('utf-8').hex()}"})
		t18_dct[sheet_name][0].update({'decimal_point': f"0x{t18_dct[sheet_name][0]['decimal_point'].encode('utf-8').hex()}"})
		t18_dct[sheet_name][0].update({'digit_separator': digit_separator_hex})
		t18_dct[sheet_name][0].update({'is_header': is_header_val})
		t18_dct[sheet_name][0].update({'is_footer': is_footer_val})
		t18_dct[sheet_name][0].update({'is_double_quote': is_quote_val})
		t18_dct[sheet_name][0].update({'is_quote': is_double_quote_val})


		if t20_dct[sheet_name][0]['record_separator'].strip().upper() == 'CRLF':
			record_separator_hex = '0x0a'
		elif t20_dct[sheet_name][0]['record_separator'].strip().upper() == 'LF':
			record_separator_hex = '0x0a'
		else:
			record_separator_hex = f"0x{t20_dct[sheet_name][0]['record_separator'].encode('utf-8').hex()}"

		if t20_dct[sheet_name][0]['digit_separator'].strip() != '':
			digit_separator_hex = f"0x{t20_dct[sheet_name][0]['digit_separator'].encode('utf-8').hex()}"
		else:
			digit_separator_hex = ''

		t20_dct[sheet_name][0].update({'out_file_cd': f'out_{file_cd}'})
		t20_dct[sheet_name][0].update({'record_separator': record_separator_hex})
		t20_dct[sheet_name][0].update({'character_encoding_system': 'UTF-8'})
		t20_dct[sheet_name][0].update({'character_encoding_cd': 'UTF-8'})
		t20_dct[sheet_name][0].update({'field_separator': f"0x{t20_dct[sheet_name][0]['field_separator'].encode('utf-8').hex()}"})
		t20_dct[sheet_name][0].update({'decimal_point': f"0x{t20_dct[sheet_name][0]['decimal_point'].encode('utf-8').hex()}"})
		t20_dct[sheet_name][0].update({'digit_separator': digit_separator_hex})
		t20_dct[sheet_name][0].update({'file_type': 'avro'})
		t20_dct[sheet_name][0].update({'is_header': True})
		t20_dct[sheet_name][0].update({'is_footer': False})


		# add missing keys
		t07_dct[sheet_name][0].update({'container_nm': 'TRANSPORTER'})
		t07_dct[sheet_name][0].update({'extract_nm': f'out_{file_cd}'})
		t07_dct[sheet_name][0].update({'sys_cd': 'OZSI'})
		t07_dct[sheet_name][0].update({'processing_state_cd': 'ACTIVE'})
		t07_dct[sheet_name][0].update({'delivery_type_cd': 'BUCKET_FILE'})
		t07_dct[sheet_name][0].update({'parallel_factor_num': 1})
		t07_dct[sheet_name][0].update({'workload_grp_cd': 'TRPT'})
		t07_dct[sheet_name][0].update({'converter_type_cd': 'GENERIC'})
		t07_dct[sheet_name][0].update({'gcp_bucket_nm': 'pl_pkobp_datalake_dev_input_converted_files_sda-swdwz5'})
		t07_dct[sheet_name][0].update({'gcp_project_nm': 'GCP_DTLK_PROJECT_ID'})
		t07_dct[sheet_name][0].update({'extraction_flg': '0'})
		t07_dct[sheet_name][0].update({'transform_flg': '0'})
		t07_dct[sheet_name][0].update({'gcs_load_flg': '0'})
		t07_dct[sheet_name][0].update({'bq_load_flg': '1'})
		t07_dct[sheet_name][0].update({'conversion_cd': f'in_{file_cd}_2_out_{file_cd}'})
		t07_dct[sheet_name][0].update({'file_num': 1})
		t07_dct[sheet_name][0].update({'data_chunk_size': 0})

		t22_dct[sheet_name][0].update({'conversion_cd': f'in_{file_cd}_2_out_{file_cd}'})
		t22_dct[sheet_name][0].update({'conversion_dsc': f'in_{file_cd}_2_out_{file_cd}'})
		t22_dct[sheet_name][0].update({'in_file_cd': f'in_{file_cd}'})
		t22_dct[sheet_name][0].update({'out_file_cd': f'out_{file_cd}'})
		t22_dct[sheet_name][0].update({'program_conversion': ''})
		t22_dct[sheet_name][0].update({'program_path': ''})

		total_row_num = len(main_dct[sheet_name])
		for row_num in range(total_row_num):

			if t21_dct[sheet_name][row_num]['conversion_type'] == '':
				conversion_type = 'none'
			else:
				conversion_type = t21_dct[sheet_name][row_num]['conversion_type']

			t21_dct[sheet_name][row_num].update({'conversion_cd': f'in_{file_cd}_2_out_{file_cd}'})
			t21_dct[sheet_name][row_num].update({'src_field_nm': t21_dct[sheet_name][row_num]['src_field_nm'].upper()})
			t21_dct[sheet_name][row_num].update({'output_field_nm': t21_dct[sheet_name][row_num]['output_field_nm'].upper()})
			t21_dct[sheet_name][row_num].update({'conversion_field_index': 1})
			t21_dct[sheet_name][row_num].update({'conversion_type': conversion_type})
			t21_dct[sheet_name][row_num].update({'output_file_cd': f'out_{file_cd}'})
			t21_dct[sheet_name][row_num].update({'src_file_cd': f'in_{file_cd}'})
			t21_dct[sheet_name][row_num].update({'regex_value': ''})
			t21_dct[sheet_name][row_num].update({'default_value': ''})


		for row in t07_dct[sheet_name]:

			input_row = {
				'table_nm': row['gcp_table_nm'],
				'dataset_nm': row['gcp_dataset_nm'],
				'project_id': 'GCP_DTLK_PROJECT_ID',
				'gcp_etl_pkg_cd': row['gcp_etl_pkg_cd'],
				'sin_ti_sem_nm': f"DTLK_RSC_SEM_TI_DATALAKE_GCP_{row['gcp_dataset_nm'].upper()}_{row['gcp_table_nm'].upper()}_{row['gcp_etl_pkg_cd'].upper()}",
				'sin_ti_sem_mode_cd': 'SINGLE'
			}

			t16_dct.setdefault(sheet_name, []).append(input_row)


		for row in main_dct[sheet_name]:
			file_cd = deepcopy(t18_dct[sheet_name][0]['in_file_cd'].strip().lower())[3:]
			
			if row['Typ danych'].lower() == 'numeric':
				data_type = 'decimal'
			else:
				data_type = row['Typ danych'].lower()

			input_row = {
				'in_out_file_cd': f'in_{file_cd}',
				'in_out_cd': 'in',
				'field_nm': row['Pole interfejsu wejściowego'].upper(),
				'field_index': int(row['Lp.']) - 1,
				'field_type': data_type,
				'fileld_length': row['Długość pola'],
				'field_length_precision': '',
				'field_length_scale': '',
				'filed_format': '',
			}
			
			
			if row['Typ danych_2'].lower() == 'numeric':
				data_type = 'decimal'
			else:
				data_type = row['Typ danych_2'].lower()

			if len(re.split(r'[.,]', row['Długość pola_3'])) > 1 and row['Typ danych_2'].lower() in ['numeric', 'decimal', 'number']:
				scale = re.split(r'[.,]', row['Długość pola_3'])[1]
			elif len(re.split(r'[.,]', row['Długość pola_3'])) > 1 and row['Typ danych_2'].lower() not in ['numeric', 'decimal', 'number']: 
				scale = 0
			else:
				scale = ''

			if len(re.split(r'[.,]', row['Długość pola_3'])) > 1 and row['Typ danych_2'].lower() in ['numeric', 'decimal', 'number']:
				precision = re.split(r'[.,]', row['Długość pola_3'])[0]
			else:
				precision = ''

			output_row = {
				'in_out_file_cd': f'out_{file_cd}',
				'in_out_cd': 'out',
				'field_nm': row['Pole interfejsu wyjściowego/tabeli'].upper(),
				'field_index': int(row['Lp.']) - 1,
				'field_type': data_type,
				'fileld_length': '',
				'field_length_precision': precision,
				'field_length_scale': scale,
				'filed_format': row['Format'],
			}
			
			# Adding the rows to the processed list
			t19_dct.setdefault(sheet_name, []).append(input_row)
			t19_dct.setdefault(sheet_name, []).append(output_row)


		# remove keys
		del t18_dct[sheet_name][0]['']
		
		for row_num in range(total_row_num):
			# del t21_dct[sheet_name][row_num]['Lp.']
			del t21_dct[sheet_name][row_num]['Klucz główny']
			del t21_dct[sheet_name][row_num]['Typ danych']
			del t21_dct[sheet_name][row_num]['Długość pola']
			# del t21_dct[sheet_name][row_num]['Pole interfejsu wejściowego']
			# del t21_dct[sheet_name][row_num]['Pole interfejsu wyjściowego/tabeli']
			del t21_dct[sheet_name][row_num]['Format']
			del t21_dct[sheet_name][row_num]['Słownik dla pola \n(jeżeli wypełnione jest polem słownikowym)']
			del t21_dct[sheet_name][row_num]['Krótki opis pola']
			del t21_dct[sheet_name][row_num]['Standaryzacja - opis biznesowy']
			# del t21_dct[sheet_name][row_num]['Standaryzacja - opis techniczny']
			del t21_dct[sheet_name][row_num]['Długość nazwy pola wystandaryzowanego']
			del t21_dct[sheet_name][row_num]['Uwagi do specyfikacji interfejsów - w trakcie wyjaśniania']
			del t21_dct[sheet_name][row_num]['Wersja']
			del t21_dct[sheet_name][row_num]['Zmiana']
			del t21_dct[sheet_name][row_num]['Komentarze do zmiany']
			del t21_dct[sheet_name][row_num]['Typ danych_2']
			del t21_dct[sheet_name][row_num]['Długość pola_3']


	for sheet_name in sheet_names:
		generate_ddl_files(main_dct[sheet_name],t10_dct[sheet_name], output_package_path)
	generate_metadata_files(main_dct, t16_dct, t18_dct, t19_dct, t20_dct, t21_dct, t22_dct, t10_dct, t07_dct, output_path, output_package_path, xDA, package_name, sheet_names)
	generate_install_files(output_package_path, package_name)

	print(f'\n\n\n\n\n\n{package_name} pacgkage generated!\n\n')

