import os
import numpy as np
import pandas as pd
import re

# add control_panel module by adding grandparent directory into environmental variables
# from pathlib import Path
# import sys
# sys.path.append(Path(__file__).parent.parent.as_posix())
# from excel_functions import *


def generate_ddl_files(dct, t10_dct, output_package_path):

	target_schema = t10_dct[0]['dataset_nm']
	target_table = t10_dct[0]['table_nm']


	pd.options.mode.chained_assignment = None  # default='warn'
	df = pd.DataFrame(dct)
	df['Pole interfejsu wejściowego'] = df['Pole interfejsu wejściowego'].str.lower().str.strip()
	df['Typ danych'] = df['Typ danych'].str.lower().str.strip()
	df['Typ danych'] = df['Typ danych'].replace({'varchar2': 'string', 'char': 'string'})
	df['Typ danych'] = df['Typ danych'].str.replace(r'char(\(\d+\))', r'string\1', regex=True)
	df['Typ danych'] = df['Typ danych'].str.replace(r'varchar(\(\d+\))', r'string\1', regex=True)
	df['Typ danych'] = df['Typ danych'].str.replace(r'varchar2(\(\d+\))', r'string\1', regex=True)


	# escape special characters
	df['Krótki opis pola'] = df['Krótki opis pola'].replace('"', '\'', regex=True)
	df['Krótki opis pola'] = df['Krótki opis pola'].replace(' +', ' ', regex=True)
	df['Krótki opis pola'] = df['Krótki opis pola'].replace('–', '-', regex=True)
	df['Krótki opis pola'] = df['Krótki opis pola'].replace('‘|’', '\'', regex=True)


	# create ddl create body
	df = df.set_index('Pole interfejsu wejściowego')
	df['create_target_fields_logic'] = df.index + ' ' + df['Typ danych'] + ' OPTIONS(description="' + df['Krótki opis pola'] + '")'
	
	create_target_fields_lst =  df['create_target_fields_logic'].values.tolist()
	create_target_fields_lst = [re.sub('\n', r'\\n', elem) for elem in create_target_fields_lst]
	create_target_fields_lst = [re.sub('\n', r'\\t', elem) for elem in create_target_fields_lst]
	create_target_fields_lst = [re.sub(' char', '', elem) for elem in create_target_fields_lst]
	create_target_fields = ',\n\t'.join(create_target_fields_lst)
	create_target_fields = re.sub(r'\t,\n', r'\n', create_target_fields)

	ddl_body_txt = f"""
drop table if exists {target_schema.lower()}.{target_table.lower()};


create table {target_schema.lower()}.{target_table.lower()} (
{create_target_fields}
)
partition by due_dt
cluster by tech_etl_pkg_cd
;

"""

	#%%
	# save procedure into file
	ddl_file = f'{target_table}.sql'
	ddl_file_path = os.path.join(output_package_path, 'BQ/DDL', ddl_file)
	with open(ddl_file_path, 'w', encoding='utf-8') as f:
		f.write(ddl_body_txt)

