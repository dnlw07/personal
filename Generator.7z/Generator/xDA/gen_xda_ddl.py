import os
import numpy as np
from script_templates import ddl_body
from excel_functions_ida import *


def generate_ddl_files(df, output_package_path, target_schema, target_table, target_fields_lst, model_table_type_cd, xDA, target_table_suffix):

		# %%
		# escape special characters
		df['Opis biznesowy'] = df['Opis biznesowy'].replace('"', '\'', regex=True).replace(' +', ' ', regex=True).replace('–', '-', regex=True)

		# create ddl create body
		df = df.set_index('Kolumna')
		df['create_target_fields_logic'] = np.where(df['Not Null'].str.upper() == 'T', df.index + ' ' + df['Typ'] + ' not null OPTIONS(description="' + df['Opis biznesowy'] + '")', '')
		df['create_target_fields_logic'] = np.where(df['Not Null'].str.upper() != 'T', df.index + ' ' + df['Typ'] + ' OPTIONS(description="' + df['Opis biznesowy'] + '")', df['create_target_fields_logic'])
		target_fields = ',\n\t\t\t'.join(target_fields_lst)
		create_target_fields_lst =  df['create_target_fields_logic'].values.tolist()

		# escape special characters
		create_target_fields_lst = [re.sub('\n', r'\\n', elem) for elem in create_target_fields_lst]
		create_target_fields_lst = [re.sub('\n', r'\\t', elem) for elem in create_target_fields_lst]
		create_target_fields_lst = [re.sub(' char', '', elem) for elem in create_target_fields_lst]

		# insert new line after tech_fields
		if model_table_type_cd in ['SCD1_ACT_B', 'SCD2_ACT_B']:
			create_target_fields_lst.insert(3, '')
		elif model_table_type_cd == 'SNAP_OVR_B':
			create_target_fields_lst.insert(6, '')
		else:
			create_target_fields_lst.insert(5, '')

		create_target_fields = ',\n\t'.join(create_target_fields_lst)
		create_target_fields = re.sub(r'\t,\n', r'\n', create_target_fields)
		ddl_body_txt = ddl_body(target_schema, target_table, target_fields, create_target_fields, model_table_type_cd, xDA, target_table_suffix)


		#%%
		# save procedure into file
		ddl_file = f'{target_table}.sql'
		ddl_file_path = os.path.join(output_package_path, 'BQ/DDL', ddl_file)
		with open(ddl_file_path, 'w', encoding='utf-8') as f:
			f.write(ddl_body_txt)

