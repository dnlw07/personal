#%%
import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
from openpyxl import load_workbook, Workbook
import pandas as pd
# from datetime import datetime
# import re
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
# from copy import deepcopy

from gen_proc import generate_procedure_files
from gen_xda_ddl import generate_ddl_files
from gen_xda_metadata import generate_metadata_files
from gen_xda_install import generate_install_files
from gen_tag_list import generate_tag_list_file
from gen_anow import generate_anow_wf_files, generate_anow_proc_files
from gen_object_list import generate_object_list_file

# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
from excel_functions import *
from control_panel import wf_ID, package_id, tgt_schema_name, old_table_codes, new_table_codes, xDA, calendar_flg, table_map, output_stm_file_path, output_ldm_file_path, sem_bin_names, version


# output documentation
# ldm_wb_paths = [rf"C:\Dane\repo\python\Generator\_output\{wf_ID}_IDA_Logiczny_Model_Danych_v1.0.xlsx"]
# stm_wb_paths = [rf"C:\Dane\repo\python\Generator\_output\{wf_ID}_IDA_STM_v1.0.xlsx"] # if None then generates only DDL files

# ldm_wb_paths = [rf"C:\Dane\repo\python\Generator\_output\{input_ldm_file_name}"]
# stm_wb_paths = [rf"C:\Dane\repo\python\Generator\_output\{input_stm_file_name}"] # if None then generates only DDL files


stm_wb_paths = [output_stm_file_path] # if None then generates only DDL files
ldm_wb_paths = [output_ldm_file_path]


# ldm_wb_paths = [rf"C:\Dane\repo\python\Generator\_output\src_IDA_Logiczny_Model_Danych_v1.0.xlsx"]
# stm_wb_paths = [None]
# wb_path_lst = glob('.\\xls\\table_list*.xlsx')  # example of path with a wildcard



########################################################################################################################
# CONTROL PANEL
########################################################################################################################


# xDA = 'EDA'
# wf_ID = 'ACCT_BALANCE'
# package_id = 'ACCB'
# calendar_flg = 'ALL' # ['ALL', 'WORKING', 'CUSTOM', 'OZSI', 'LAST_MONTH_DAY']
# new_table_codes = ['T602204']  # input here sheet_names, table_names or table codes ('txxxxxx')
# stm_wb_paths = [rf"C:\Dane\repo\projects\RPZKB-5887\dokumentacja\STM_EDA_t602204_acct_balance.xlsx"]
# ldm_wb_paths = [rf"C:\Dane\repo\git\specifications\EDA\PZKB\PZKB_BATCH_EDA_Logiczny_Model_Danych_v2.47.xlsx"]


# new_table_codes = [re.sub('T17', f'T{tgt_schema_name[4:7]}', tgt_table_code) for tgt_table_code in old_table_codes]


########################################################################################################################



package_name = f'GCP-{xDA}_{package_id}-{version}'
tag_name = f'GCP_{xDA}_{package_id}_{version}'

# path to executable file
# base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output', package_name)
output_path = rf'C:\Dane\repo\python\Generator\_output'
output_package_path = rf'C:\Dane\repo\python\Generator\_output\{package_name}'


# create missing folders in a package if yet not exist
if not os.path.exists(os.path.join(output_package_path)):
	os.makedirs(os.path.join(output_package_path))
if not os.path.exists(os.path.join(output_package_path, 'BQ')):
	os.makedirs(os.path.join(output_package_path, 'BQ'))
if not os.path.exists(os.path.join(output_package_path, 'BQ', 'DDL')):
	os.makedirs(os.path.join(output_package_path, 'BQ', 'DDL'))
if not os.path.exists(os.path.join(output_package_path, 'BQ', 'ROUTINE')):
	os.makedirs(os.path.join(output_package_path, 'BQ', 'ROUTINE'))
if not os.path.exists(os.path.join(output_package_path, 'POSTGRES')):
	os.makedirs(os.path.join(output_package_path, 'POSTGRES'))
if not os.path.exists(os.path.join(output_package_path, 'POSTGRES', 'DML')):
	os.makedirs(os.path.join(output_package_path, 'POSTGRES', 'DML'))
if not os.path.exists(os.path.join(output_package_path, 'ANOW')):
	os.makedirs(os.path.join(output_package_path, 'ANOW'))
if not os.path.exists(os.path.join(output_package_path, 'ANOW', 'JSON')):
	os.makedirs(os.path.join(output_package_path, 'ANOW', 'JSON'))


# clear output directory
[os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.sql'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany
[os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.json'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany
# [print(file) for file in glob(os.path.join(output_package_path, 'output', '**\*.sql'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany


# loop through workbooks
for stm_wb_path, ldm_wb_path in zip(stm_wb_paths, ldm_wb_paths):

	# filter out sheets by table code (skip T letter but be careful of UPPER/LOWER case)
	if not old_table_codes and new_table_codes:
		pass
	elif old_table_codes and not new_table_codes:
		new_table_codes = [re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', old_sheet_name) for old_sheet_name in old_table_codes]
	else:
		print('ERROR! Table code list with new or old codes not provided.')

	# new_table_codes = [re.findall('t\d+', new_table_name, re.IGNORECASE)[0] for old_sheet_name, new_table_name in table_map.items() if old_sheet_name in old_table_codes]

	ldm_wb = load_workbook(ldm_wb_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	ldm_sheet_names = [string for string in ldm_wb.sheetnames if any((substr[1:7] in string) for substr in new_table_codes)]
	ldm_dct = all_datasets_by_table_name(ldm_wb, ldm_sheet_names, table_name_pattern='Specyfikacja logicznego modelu danych', offset_header_rows=2)
	ldm_main_dct = all_datasets_by_table_name(ldm_wb, ldm_sheet_names, table_name_pattern='Nazwa biznesowa tabeli', offset_header_rows=0)


	if stm_wb_path is not None: 

		# open dm workbook
		try:
			stm_wb = load_workbook(stm_wb_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
			stm_sheet_names = [string for string in stm_wb.sheetnames if any((substr[1:7] in string and 'Walidacje_' not in string) for substr in new_table_codes)]
			validated_sheet_names = [string for string in stm_wb.sheetnames if any(re.findall(f'Walidacje_(t)?{substr[1:7]}', string, re.IGNORECASE) for substr in new_table_codes)]
		except:
			print(f'WARNING! STM file is missing. DDL will be generated only!')
			stm_wb_path = None
			stm_sheet_names =  ldm_sheet_names
			validated_sheet_names = None
		

		# if (not stm_sheet_names) or (not validated_sheet_names) or (not ldm_sheet_names):
		if (not stm_sheet_names) or (not ldm_sheet_names):
			print('ERROR: wrong sheet names provided. In variable \'old_table_codes\' provide tablecode, sheet name or table name')
			break

		# convert excel ranges into nested lists
		stm_main_dct = all_datasets_by_table_name(stm_wb, stm_sheet_names, table_name_pattern='Nazwa biznesowa tabeli docelowej', offset_header_rows=0)
		stm_src_dct = all_datasets_by_table_name(stm_wb, stm_sheet_names, table_name_pattern='System źródłowy', offset_header_rows=0) # Lista Tabel Źródłowych
		stm_tgt_dct = all_datasets_by_table_name(stm_wb, stm_sheet_names, table_name_pattern='Wynikowy zbiór danych', offset_header_rows=0) # Definicja zbiorów danych (join)
		stm_dct = all_datasets_by_table_name(stm_wb, stm_sheet_names, table_name_pattern='(Schemat docelowej tabeli)|(Schemat wynikowego zbioru danych)', offset_header_rows=0) # main STM table
		stm_param_dct = all_datasets_by_table_name(stm_wb, stm_sheet_names, table_name_pattern='^Nazwa parametru$', offset_header_rows=0) # Lista parametrów
		if validated_sheet_names: # validation_sheet is optional
			stm_val_dct = all_datasets_by_table_name(stm_wb, validated_sheet_names, table_name_pattern='RULE_ID', offset_header_rows=0)
		else:
			stm_val_dct = None
	else:
		stm_sheet_names = ldm_sheet_names
		print(f'WARNING! STM file is missing. DDL will be generated only!')

	

	t00001_param_dct = []
	t00010_table_definition_dct = []
	t00012_source_target_map_dct = []
	t00014_process_definition_dct = []
	t00016_etl_pkg_definition_dct = []
	t00017_rule_definition_dct = []
	t00027_export_definition_dct = []
	process_names = []
	sin_publish_sem_names = []
	log_tables_dct = []
	sources_in_proc_dct = {}

	# loop through sheets
	# for stm_sheet_name, val_sheet_name, ldm_sheet_name in zip(stm_sheet_names, stm_val_dct, ldm_sheet_names):
	for stm_sheet_name, ldm_sheet_name in zip(stm_sheet_names, ldm_sheet_names):

		pd.options.mode.chained_assignment = None  # default='warn'
		df_dm = pd.DataFrame(ldm_dct[ldm_sheet_name])
		df_dm['Kolumna'] = df_dm['Kolumna'].str.lower().str.strip()
		df_dm['Typ'] = df_dm['Typ'].str.lower().str.strip()
		df_dm['Typ'] = df_dm['Typ'].replace({'varchar2': 'string', 'char': 'string'})
		df_dm['Typ'] = df_dm['Typ'].str.replace(r'char(\(\d+\))', r'string\1', regex=True)
		df_dm['Typ'] = df_dm['Typ'].str.replace(r'varchar(\(\d+\))', r'string\1', regex=True)
		df_dm['Typ'] = df_dm['Typ'].str.replace(r'varchar2(\(\d+\))', r'string\1', regex=True)

		
		target_schema = ldm_main_dct[ldm_sheet_name][0]['Schemat tabeli']
		target_table = ldm_main_dct[ldm_sheet_name][0]['Nazwa techniczna tabeli']
		table_type_desc = ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych']
		# model_table_type_cd = 'SCD2_ACT_B' if 'SCD2' in ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych'] else 'SCD1_ACT_B' if 'Brak historyzacji (SCD1) przez nadpisanie' in ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych'] else 'FACT_DUEDT_B' if 'fakt' in ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych'] else 'SNAP_OVR_B' if 'Snapshot - stan danych na datę' in ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych'] else None  # TODO add more variands
		
		if 'SCD2' in ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych']: 
			model_table_type_cd = 'SCD2_ACT_B' 
		elif 'Brak historyzacji (SCD1) przez nadpisanie' in ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych']:
			model_table_type_cd = 'SCD1_ACT_B' 
		elif 'fakt' in ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych']:
			model_table_type_cd = 'FACT_DUEDT_B' 
		elif 'Snapshot - stan danych na datę' in ldm_main_dct[ldm_sheet_name][0]['Historyzowanie danych']:
			model_table_type_cd = 'SNAP_OVR_B'
		else:
			model_table_type_cd = None # TODO add more variands
		
		partitioned_by = 'end_dt' if model_table_type_cd == 'SCD2_ACT_B' else 'due_dt'

		# convert target fields into string
		target_fields_lst = df_dm['Kolumna'].values.tolist()
		
		filter = (df_dm['Primary Key'] == 'T' ) & (df_dm['Kolumna'] != 'due_dt') & (df_dm['Kolumna'] != 'end_dt') & (df_dm['Kolumna'] != 'sys_cd') & (df_dm['Kolumna'] != 'extract_version')
		df_ldm_pk = df_dm[filter]
		pk_lst = list(dict.fromkeys(df_ldm_pk['Kolumna'].values.tolist()))
		pk_str = '|'.join(pk_lst)

		if xDA == 'EDA':
			pk_str += '|due_dt|extract_version'
		elif xDA in ['IDA','ADA']:
			if model_table_type_cd == 'SCD2_ACT_B':
				pk_str += '|sys_cd|end_dt'
			else:
				pk_str += '|sys_cd|due_dt'
		if pk_str[0] == '|':
			pk_str = pk_str[1:]

		target_table_prefix = re.findall('t\d+', target_table, re.IGNORECASE)[0]
		target_table_suffix = re.sub('t\d+_', '', target_table, re.IGNORECASE)

		generate_ddl_files(df_dm, output_package_path, target_schema, target_table, target_fields_lst, model_table_type_cd, xDA, target_table_suffix)


		if stm_wb_path is not None: 
			df_stm = pd.DataFrame(stm_dct[stm_sheet_name])
			df_stm_src = pd.DataFrame(stm_src_dct[stm_sheet_name])
			df_stm_tgt = pd.DataFrame(stm_tgt_dct[stm_sheet_name])
			df_stm_param = pd.DataFrame(stm_param_dct[stm_sheet_name])

			# convert to lower case and strip trailing spaces
			df_stm['Wynikowy zbiór danych'] = df_stm['Wynikowy zbiór danych'].str.lower().str.strip()
			df_stm['Schemat wynikowego zbioru danych'] = df_stm['Schemat wynikowego zbioru danych'].str.lower().str.strip()
			df_stm['Nazwa kolumny w wynikowym zbiorze'] = df_stm['Nazwa kolumny w wynikowym zbiorze'].str.lower().str.strip()
			df_stm['Kolumna źródłowa'] = df_stm['Kolumna źródłowa'].str.lower().str.strip()
			df_stm['Źródłowy zbiór danych'] = df_stm['Źródłowy zbiór danych'].str.lower().str.strip()

			# join STM and DM dataframes and filter out empty columns names
			df_joined = df_stm.set_index('Nazwa kolumny w wynikowym zbiorze').join(df_dm.set_index('Kolumna'), how='right', lsuffix='', rsuffix='_right', sort=False)
			df4 = df_joined[['Schemat wynikowego zbioru danych', 'Wynikowy zbiór danych', 'Typ', 'Primary Key', 'Not Null', 'Natural Key', 'Logika transformacji', 'Opis biznesowy', 'Alias źródłowego zbioru danych', 'Źródłowy zbiór danych', 'Kolumna źródłowa', '#', 'Zmiana']]

			# check missing columns
			df_check = df4.loc[df4['Kolumna źródłowa'].isna(), ['Kolumna źródłowa']]
			if len(df_check.index) > 0:
				print(f'\n\nERROR! Missing fields in table \'{target_table}\' while comparing STM comparing to LDM.\n')
				print(df_check)
				exit()

			if 'SCD2' in ldm_main_dct[stm_sheet_name][0]['Historyzowanie danych']: # jeżeli błąd to inna nazwa zakładki w STM inna niż LDM
				filter = (df4.index != '') & (df4.index.str.lower() != 'extract_version') & (df4.index.str.lower() != 'due_dt') & (df4['Zmiana'] != 'D')
			elif 'Brak historyzacji (SCD1) przez nadpisanie' in ldm_main_dct[stm_sheet_name][0]['Historyzowanie danych']:
				filter = (df4.index != '') & (df4.index.str.lower() != 'extract_version') & (df4['Zmiana'] != 'D')
			# elif 'Dopisanie faktów za dowolną datę biznesową' in ldm_main_dct[stm_sheet_name][0]['Historyzowanie danych']:
				# filter = (df4.index != '') & (df4.index.str.lower() != 'extract_version') & (df4['Zmiana'] != 'D')
			# elif 'Dopisanie kompletnego stanu faktów na datę danych' in ldm_main_dct[stm_sheet_name][0]['Historyzowanie danych']:
				# filter = (df4.index != '') & (df4.index.str.lower() != 'extract_version') & (df4['Zmiana'] != 'D')
			elif 'fakt' in ldm_main_dct[stm_sheet_name][0]['Historyzowanie danych']:
				filter = (df4.index != '') & (df4.index.str.lower() != 'extract_version') & (df4['Zmiana'] != 'D')
			elif xDA == 'EDA' and 'Snapshot' in ldm_main_dct[stm_sheet_name][0]['Historyzowanie danych']:
				filter = (df4.index != '') & (df4['Zmiana'] != 'D') # & (df4.index.str.lower() != 'extract_version')
			elif xDA != 'EDA' and 'Snapshot' in ldm_main_dct[stm_sheet_name][0]['Historyzowanie danych']:
				filter = (df4.index != '') & (df4.index.str.lower() != 'extract_version') & (df4['Zmiana'] != 'D')
			
			df5 = df4[filter] # bład związany z polami techicnzymi lub typem historyzacji (brakuje w powyższym if warunku z typem historyzacji)
			df5['#'] = df5['#'].astype(int) # cast to integer before sorting - numbering issue in LDM or missing field in LDM comparing to STM
			df5 = df5.sort_values(by='#', ascending=True) # sort by column number
			# df5.loc[:, '#'] = df5.loc[:, '#'].astype(int) # cast to integer before sorting


			# declare variables
			# tgt_sys_cd = stm_param_dct[stm_sheet_name][2]['Formuła']
			tgt_sys_cd = [elem['Formuła'] for elem in stm_param_dct[stm_sheet_name] if elem['Nazwa parametru'] == '$$ETLPackage'][0]
			tgt_sys_cd = re.sub('\'', '', tgt_sys_cd)
			tgt_sys_cd = re.sub('_0\d$', '', tgt_sys_cd)
			src_sys_cd = list(dict.fromkeys(df_stm_src['System źródłowy'].values.tolist()))[0].upper()  # Remark! Takes only first value
			source_schema = list(dict.fromkeys(df_stm_src['Schemat'].values.tolist()))[0]  # Remark! Takes only first value

			src_table_dct = df_stm_src.set_index('Tabela źródłowa')['Schemat'].to_dict()
			# source_table = [elem for elem in list(dict.fromkeys(df5['Źródłowy zbiór danych'].values.tolist())) if elem and elem.strip().lower() != 'n/a'][0]
			source_table = list(src_table_dct.keys())[0]

			tgt_table_dct = df_stm_tgt.set_index('Wejściowy zbiór danych')[['Alias','Operator','Warunek łączenia tabel']] ## Jeżeli błąd to usunąć pusty rząd pod nagłówkiem podczas definiowania źródeł w STM

			# TODO - tabla źródłowa nie może być indeksem gdyż może być joinowana kilkukrotnie --> zamienić indeks na alias - wtedy zostaną uzględnione wszystkie joiny w procedurze
			tgt_table_dct = tgt_table_dct[tgt_table_dct.index != source_table.upper()].apply(list, axis=1).to_dict() # remove first target table
			
			# target_table_prefix = target_table[0:7]
			# model_table_type_cd = 'SCD2_ACT_B' if 'SCD2' in stm_main_dct[stm_sheet_name][0]['Typ tabeli'] else 'SCD1_ACT_B' if 'Brak historyzacji (SCD1) przez nadpisanie' in stm_main_dct[stm_sheet_name][0]['Typ tabeli'] else 'FACT_DUEDT_B' if 'Dopisanie faktów za dowolną datę biznesową' in stm_main_dct[stm_sheet_name][0]['Typ tabeli'] else 'SNAP_OVR_B' if 'Snapshot - stan danych na datę' in stm_main_dct[stm_sheet_name][0]['Typ tabeli'] else None  # TODO add more variands
			# partitioned_by = 'end_dt' if model_table_type_cd == 'SCD2_ACT_B' else 'due_dt' if model_table_type_cd == 'SCD1_ACT_B' else 'due_dt' if model_table_type_cd == 'FACT_DUEDT_B' else None  # TODO add more variands
			
			where_clause = list(dict.fromkeys(df_stm_tgt['Filtrowanie wejściowego \nzbioru danych'].values.tolist()))[0]  # Remark! Takes only first value; JEŻELI BŁĄD TO NALEŻY USUNĄĆ PUSTY WIERSZ POD NAGŁÓWKIEM!
			where_clause = re.sub(r"DUE_DT *= *TO_DATE\('\$\$DueDt', 'MM/DD/YYYY HH24:MI:SS'\) *AND *EXTRACT_VERSION *= *'\$\$ExtractVersion_T\d+' *(AND *)*", '', where_clause, re.I)
			where_clause = f'\n\tand {where_clause.strip()}' if where_clause.strip() != '' else ''

			wfl_name = f'WFL_GCP_DDP_{xDA.upper()}_{wf_ID}_{tgt_sys_cd}'
			if xDA in ['ADA', 'IDA']:
				stock_name = f'GCP_RSC_STC_{xDA.upper()}_{wf_ID}_DOUBLE_RUN_BLOCK'
				# calendar_name = f'GCP_RSC_CAL_{xDA.upper()}_{wf_ID}_{tgt_sys_cd}_01'
			elif xDA == 'EDA':
				stock_name = f'GCP_RSC_STC_{xDA.upper()}_{target_table.upper()}_{tgt_sys_cd}_01_DOUBLE_RUN_BLOCK'
				# calendar_name = 'OHIO_RSC_CAL_WORKING_DAYS'
			if calendar_flg == 'WORKING':
				calendar_name = 'OHIO_RSC_CAL_WORKING_DAYS'
			elif calendar_flg == 'ALL':
				calendar_name = 'OHIO_RSC_CAL_ALL_DAYS'
			elif calendar_flg == 'OZSI':
				calendar_name = 'GCP_RSC_CAL_CUST_OZSI'
			elif calendar_flg == 'LAST_MONTH_DAY':
				calendar_name = 'OHIO_RSC_CAL_LAST_MONTH_DAY'
			elif calendar_flg == 'CUSTOM':
				calendar_name = f'GCP_RSC_CAL_{xDA.upper()}_{wf_ID}_{tgt_sys_cd}_01'
			# if xDA =='EDA':
				# scheduler_name = f'TS_GCP_RSC_SL_{xDA.upper()}_{wf_ID}'
			# else:
			scheduler_name = f'TS_GCP_RSC_SL_{xDA.upper()}_{wf_ID}_{tgt_sys_cd}_01'
			sin_publish_sem_name = f'DTLK_RSC_SEM_DATALAKE_GCP_{xDA.upper()}_{wf_ID}_{tgt_sys_cd}'
			sin_metric_name = f'DTLK_RSC_MET_DATALAKE_GCP_{xDA.upper()}_{wf_ID}_{tgt_sys_cd}'
			sin_ti_sem_nm_013 = f'DTLK_RSC_SEM_TI_DATALAKE_GCP_{xDA.upper()}_{wf_ID}_{tgt_sys_cd}'
			sin_ti_sem_nm_016 = f'DTLK_RSC_SEM_TI_DATALAKE_GCP_{target_schema.upper()}_{target_table.upper()}_{tgt_sys_cd}_01'
			procedure_name = f'load_{target_table_prefix.lower()}_{tgt_sys_cd.lower()}_01_01_p'  # ex. load_t408005_prkr_01_01_p
			# if stm_val_dct is not None:
			# 	gcp_etl_pkg_cd = stm_val_dct[val_sheet_name][0]['ETL_PKG_CD'].upper()
			# else:
			gcp_etl_pkg_cd = f'{tgt_sys_cd}_01'
			project_id = 'GCP_DTLK_PROJECT_ID'
			process_name = f'WFL_GCP_{xDA.upper()}_{target_table.upper()}_{tgt_sys_cd}_01'
			process_names.append(process_name)
			sin_publish_sem_names.append(sin_publish_sem_name)

			# create metadata dicts
			# for src_table, src_schema in src_table_dct.items():
			# 	t00012_source_target_map_dct.append({'proc_nm': process_name, 'table_nm': src_table.lower(), 'dataset_nm': src_schema.lower(), 'project_id': project_id, 'table_rel_type_cd': 'SRC', 'gcp_etl_pkg_cd': gcp_etl_pkg_cd})
			
			
			# non_null_field_lst = [elem for elem in list(dict.fromkeys(df5['Wynikowy zbiór danych'].values.tolist())) if elem and elem.strip().lower() != 'n/a'][0]

			# business fields logic
			tech_fields = ['due_dt', 'start_dt', 'end_dt', 'sys_cd', 'tech_is_active_flg', 'tech_etl_pkg_cd', 'tech_insert_id', 'tech_insert_ts', 'tech_update_id', 'tech_update_ts', 'tech_close_id', 'tech_close_ts']

			non_null_df = df5[(df5['Not Null'] == 'T') & (~df5.index.str.lower().isin(tech_fields))]
			non_null_lst = non_null_df.index.tolist()

			for src_table, src_schema in src_table_dct.items():
				sources_in_proc_dct.setdefault(process_name, []).append([src_schema, src_table])
			t00012_source_target_map_dct.append({'proc_nm': process_name, 'table_nm': target_table.lower(), 'dataset_nm': target_schema.lower(), 'project_id': project_id, 'table_rel_type_cd': 'TGT', 'gcp_etl_pkg_cd': gcp_etl_pkg_cd})
			t00014_process_definition_dct.append({'proc_nm': process_name, 'proc_dsc': f'Ładowanie {target_table.lower()} z systemu {tgt_sys_cd}', 'wfl_nm': wfl_name, 'comment': None, 'active_flg': '1', 'gcp_etl_pkg_cd': gcp_etl_pkg_cd, 'processing_nm': procedure_name, 'processing_engine_cd': 'BQ'})
			t00016_etl_pkg_definition_dct.append({'table_nm': target_table.lower(), 'dataset_nm': target_schema.lower(), 'project_id': project_id, 'gcp_etl_pkg_cd': gcp_etl_pkg_cd, 'sin_ti_sem_nm': None if xDA in ['ADA', 'IDA'] else sin_ti_sem_nm_016}) # 'sin_ti_sem_nm' dla IDA/ADA powinno być puste w tabeli t00016_etl_pkg_definition ale wypełnione w tabeli t00013_workflow_definition
			t00027_export_definition_dct.append({'export_cd': process_name, 'delivery_type_cd': 'DB', 'default_extract_mode_cd': 'FULL', 'active_flg': '1', 'gcp_etl_pkg_cd': gcp_etl_pkg_cd, 'processing_nm': procedure_name, 'processing_engine_cd': 'BQ', 'export_file_name_mask': None, 'export_file_folder': None, 'simple_flg': '0', 'calendar_nm': calendar_name, 'default_sequent_ver_meaning_cd': 'FIX', 'notification_mail': None})
			
			# ,\"${EXTRACT_VERSION_T208016}\",\"${EXTRACT_VERSION_T208017}
			extract_version_lst = []
			for param_row in stm_param_dct[stm_sheet_name]:
				if '$$ExtractVersion' in param_row['Nazwa parametru']:
					extract_version_var = re.sub('\$\$ExtractVersion', '${EXTRACT_VERSION', param_row['Nazwa parametru'])
					extract_version_var = re.sub('$', '}', extract_version_var)
					extract_version_lst.append(extract_version_var)
				if param_row['Nazwa parametru'] not in ['$$DueDt','$$EndDt','$$SysCd','$$ETLPackage','$$SurogateKeySeparator'] and '$$ExtractVersion' not in param_row['Nazwa parametru']:
					t00001_param_dct.append({'param_nm': param_row['Nazwa parametru'], 'param_val': re.sub("'", '', param_row['Formuła']), 'param_dsc': param_row['Opis'], 'component_nm': 'TABLE', 'db_nm': None, 'dataset_nm': target_schema.lower(), 'table_nm': target_table.lower(), 'etl_pkg_cd': tgt_sys_cd, 'framework_param_flg': '0'})
			
			# if stm_val_dct is not None:
			# 	t00010_table_definition_dct.append({'table_nm': target_table.lower(), 'dataset_nm': target_schema.lower(), 'project_id': project_id, 'model_table_type_cd': model_table_type_cd, 'partitioned_by': partitioned_by, 'pk_column_list': stm_val_dct[val_sheet_name][0]['COLUMN_NM'].lower(), 'default_mode_cd': None, 'sin_publish_sem_nm': None, 'sin_metric_nm': None})
			# 	t00017_rule_definition_dct.append({'rule_id': stm_val_dct[val_sheet_name][0]['RULE_ID'], 'rule_category_cd': stm_val_dct[val_sheet_name][0]['RULE_CATEGORY_CD'], 'table_nm': stm_val_dct[val_sheet_name][0]['TABLE_NM'].lower(), 'dataset_nm': stm_val_dct[val_sheet_name][0]['SCHEMA_NM'].lower(), 'project_id': project_id, 'gcp_etl_pkg_cd': gcp_etl_pkg_cd, 'rule_type_cd': stm_val_dct[val_sheet_name][0]['RULE_TYPE_CD'], 'sys_cd': stm_val_dct[val_sheet_name][0]['SYS_CD'], 'sql_query': stm_val_dct[val_sheet_name][0]['SQL_QUERY'], 'rule_dsc': stm_val_dct[val_sheet_name][0]['RULE_DSC'], 'warn_lvl': stm_val_dct[val_sheet_name][0]['WARN_LVL'], 'error_lvl': stm_val_dct[val_sheet_name][0]['ERROR_LVL'], 'active_flg': stm_val_dct[val_sheet_name][0]['ACTIVE_FLG'], 'eff_st_dt': stm_val_dct[val_sheet_name][0]['EFF_ST_DT'], 'eff_end_dt': stm_val_dct[val_sheet_name][0]['EFF_END_DT'], 'notification_mail': stm_val_dct[val_sheet_name][0]['NOTIFICATION_MAIL'], 'log_limit_rows': None, 'additional_param': None, 'rule_table_nm': None, 'rule_dataset_nm': None, 'rule_project_id': None, 'rule_gcp_etl_pkg_cd': None})
			# else:
			t00010_table_definition_dct.append({'table_nm': target_table.lower(), 'dataset_nm': target_schema.lower(), 'project_id': project_id, 'model_table_type_cd': model_table_type_cd, 'partitioned_by': partitioned_by, 'pk_column_list': pk_str, 'default_mode_cd': None, 'sin_publish_sem_nm': None, 'sin_metric_nm': None})
			t00017_rule_definition_dct.append({'rule_id': f'R{target_table_prefix[1:]}_001', 'rule_category_cd': 'PK', 'table_nm': target_table.lower(), 'dataset_nm': target_schema.lower(), 'project_id': project_id, 'gcp_etl_pkg_cd': gcp_etl_pkg_cd, 'rule_type_cd': 'ETL', 'sys_cd': tgt_sys_cd, 'sql_query': None, 'rule_dsc': 'Walidacja unikalności klucza głównego', 'warn_lvl': '0', 'error_lvl': '0', 'active_flg': '1', 'eff_st_dt': '1900-01-01', 'eff_end_dt': '9999-12-31', 'notification_mail': None, 'log_limit_rows': None, 'additional_param': None, 'rule_table_nm': None, 'rule_dataset_nm': None, 'rule_project_id': None, 'rule_gcp_etl_pkg_cd': None})
			
			log_tables_dct.append({'proc_nm': process_name, 'dataset_nm': target_schema.lower(), 'table_nm': target_table.lower(), 'wfl_nm': wfl_name, 'sys_cd': tgt_sys_cd})

			extract_version_txt = '\",\"'.join(extract_version_lst)
			extract_version_txt = f'\",\"{extract_version_txt}'

			# generate script files (one target table in a file)
			generate_procedure_files(df5, output_package_path, procedure_name, source_schema, src_table_dct, source_table, tgt_table_dct, target_schema, target_table, target_table_prefix, target_fields_lst, where_clause, model_table_type_cd, xDA)
			generate_anow_proc_files(output_package_path, wfl_name, calendar_name, scheduler_name, stock_name, sin_publish_sem_names, sem_bin_names, process_name, tag_name, xDA, extract_version_txt)

	if stm_wb_path is not None: 
		# generate script files (multiple target tables in a file)
		t00013_workflow_definition_dct =[{'wfl_nm': wfl_name, 'wfl_dsc': f'Warstwa {xDA.upper()} - dane {tgt_sys_cd}', 'wfl_grp': f'{xDA.upper()}', 'wfl_type': f'{xDA.upper()}', 'calendar_nm': calendar_name, 'sin_publish_sem_nm': sin_publish_sem_name, 'sin_metric_nm': sin_metric_name, 'sin_ti_sem_nm': sin_ti_sem_nm_013}]
		generate_metadata_files(locals(), output_path, output_package_path, xDA, package_name, sources_in_proc_dct) # all declared metadata dictionaries are passed by 'loacls()' magic dictionary
		generate_install_files(output_package_path, package_name)
		generate_anow_wf_files(output_package_path, wfl_name, calendar_name, scheduler_name, stock_name, sin_publish_sem_name, process_names, tag_name, xDA, calendar_flg, extract_version_txt)
		# generate_tag_list_file(output_path, output_package_path)
		generate_object_list_file(output_path, locals())


	print(f'\n\n\n\n\n\n{package_name} pacgkage generated!\n\n')

