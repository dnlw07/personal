import os
from glob import glob
from excel_functions_ida import *
import json
import uuid

def generate_anow_proc_files(output_package_path, wfl_name, calendar_name, scheduler_name, stock_name, sin_publish_sem_names, sem_bin_names, process_name, tag_name, xDA, extract_version_txt):


	stock_lst = [
		{
			"composite": False,
			"domain": "BANK_D2",
			"domainClass": "Resource",
			"id": f"[BANK_D2]{stock_name}",
			"resourceType": "STOCK",
			"simpleId": f"{stock_name}",
			"tags": [
				"DDP",
				"GCP",
				xDA,
				tag_name
			],
			"totalPermits": 1
		}
	]
	
	if xDA == 'IDA':
		dependency_semaphore_name = f"{process_name}_COMPLETED_{process_name}"
		
		dependency_semaphore_lst = [
			{
				"composite": False,
				"domain": "BANK_D2",
				"domainClass": "Resource",
				"id": f"[BANK_D2]{dependency_semaphore_name}",
				"resourceType": "BINARY_SEMAPHORE",
				"simpleId": f"{dependency_semaphore_name}",
				"tags": [
					"GCP",
					"DDP",
					xDA,
					tag_name
				]
			}
		]

	static_semafore = [
		{
			"composite": False,
			"domain": "BANK_D2",
			"domainClass": "Resource",
			"folder": "MyFolder",
			"id": f"[BANK_D2]{sin_publish_sem_name}",
			"resourceType": "BINARY_SEMAPHORE",
			"simpleId": f"{sin_publish_sem_name}",
			"tags": [
				"DDP",
				"GCP",
				xDA,
				tag_name
			]
		} for sin_publish_sem_name in sin_publish_sem_names
	]

	if xDA == 'IDA':
		process_lst = [
			{
				"autoArchive": False,
				"comment": "dev",
				"customFieldValues": {},
				"dependencies": [
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_VALIDATION_SEM_CHECK",
						"predecessor": "WFL_GCP_VALIDATION_SEM_CHECK",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_VALIDATION_SEM_CHECK",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_VALIDATE_TMP",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_VALIDATE_TMP",
						"predecessor": "WFL_GCP_VALIDATE_TMP",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_VALIDATE_TMP",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_LOAD_IDA",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_IDA_PRE_PROCESS",
						"predecessor": "WFL_GCP_IDA_PRE_PROCESS",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_IDA_PRE_PROCESS",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_RUN_PROC",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_RUN_PROC",
						"predecessor": "WFL_GCP_RUN_PROC",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_RUN_PROC",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_VALIDATION_SEM_CHECK",
						"workflowType": "STANDARD"
					}
				],
				"description": "Proces Datalake, PROC_NM = ${PAR_PROC_NM}",
				"designParameters": [
					{
						"addNewValues": False,
						"addUnknownValues": False,
						"allowExpressions": False,
						"defaultValue": f"{process_name}",
						"designObjectId": f"{process_name}",
						"designObjectType": "PROCESSING",
						"domain": "BANK_D2",
						"domainClass": "DesignParameter",
						"editorType": "TEXT",
						"evaluateExpressions": False,
						"name": "PAR_PROC_NM",
						"required": True,
						"saveValueToResource": False,
						"title": "PAR_PROC_NM"
					},
					{
						"addNewValues": False,
						"addUnknownValues": False,
						"allowExpressions": False,
						# "defaultValue": "${VAL_DUE_DT}\",\"${VAL_GCP_ETL_PKG_CD}\",\"${VAL_KEY_SEPARATOR}\",\"${VAL_REPL_TEXT}\",\"${EXTRACT_VERSION_T208016}\",\"${EXTRACT_VERSION_T208017}",
						"defaultValue":f"${{VAL_DUE_DT}}\",\"${{VAL_GCP_ETL_PKG_CD}}\",\"${{VAL_KEY_SEPARATOR}}\",\"${{VAL_REPL_TEXT}}{extract_version_txt}",
						"designObjectId": f"{process_name}",
						"designObjectType": "PROCESSING",
						"domain": "BANK_D2",
						"domainClass": "DesignParameter",
						"editorType": "TEXT",
						"evaluateExpressions": False,
						"name": "PAR_PROC_PARAM_LIST",
						"required": True,
						"saveValueToResource": False,
						"title": "PAR_PROC_PARAM_LIST"
					}
				],
				"domain": "BANK_D2",
				"domainClass": "ProcessingTemplate",
				"eagerScriptExecution": False,
				"folder": "MyFolder",
				"hasNotes": False,
				"hasPendingNotes": False,
				"highRisk": False,
				"id": f"[BANK_D2]{process_name}",
				"items": [
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_RUN_PROC",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WFL_GCP_RUN_PROC",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 2,
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_VALIDATE_TMP",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WFL_GCP_VALIDATE_TMP",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 4,
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_IDA_PRE_PROCESS",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WFL_GCP_IDA_PRE_PROCESS",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 1,
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_VALIDATION_SEM_CHECK",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_VALIDATION_SEM_CHECK",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 3,
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_LOAD_IDA",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_LOAD_IDA",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 5,
						"templateParameters": {},
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					*[{
						"dependencyType": "RESOURCE",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{sem_bin_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"resource": f"{sem_bin_name}",
						"resourceType": "BINARY_SEMAPHORE",
						"semaphoreState": "OFF",
						"sortKey": f"03.BINARY_SEMAPHORE.{sem_bin_name}",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_RUN_PROC",
						"workflowType": "STANDARD"
					} for proc_nm, sem_bin_name_lst in sem_bin_names.items() for sem_bin_name in sem_bin_name_lst if proc_nm == process_name]
				],
				"keepResourcesOnFailure": False,
				"lazyLoad": False,
				"noteCount": 0,
				"onHold": False,
				"owner": "PZ006369",
				"passActionsToChildren": False,
				"passBy": False,
				"passResourceDependenciesToChildren": False,
				"pendingNoteCount": 0,
				"preloadCounter": 0,
				"priority": "0",
				"processingType": "WORKFLOW",
				"reason": "",
				"sequentialProcessing": False,
				"simpleId": f"{process_name}",
				"tags": [
					"DDP",
					"GCP",
					xDA,
					tag_name
				],
				"turnOffDurationEstimation": False,
				"useScripts": False,
				"weight": "1",
				"workflowType": "STANDARD"
			}
		]
	if xDA == 'ADA':
		process_lst = [
			{
				"autoArchive": False,
				"dependencies": [
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_ADA_PRE_PROCESS",
						"predecessor": "WFL_GCP_ADA_PRE_PROCESS",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_ADA_PRE_PROCESS",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_RUN_PROC",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_VALIDATION_SEM_CHECK",
						"predecessor": "WFL_GCP_VALIDATION_SEM_CHECK",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_VALIDATION_SEM_CHECK",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_VALIDATE_TMP",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_RUN_PROC",
						"predecessor": "WFL_GCP_RUN_PROC",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_RUN_PROC",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_VALIDATION_SEM_CHECK",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_VALIDATE_TMP",
						"predecessor": "WFL_GCP_VALIDATE_TMP",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_VALIDATE_TMP",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_LOAD_IDA",
						"workflowType": "STANDARD"
					},
					*[{
						"dependencyType": "RESOURCE",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{sem_bin_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"resource": f"{sem_bin_name}",
						"resourceType": "BINARY_SEMAPHORE",
						"semaphoreState": "OFF",
						"sortKey": f"03.BINARY_SEMAPHORE.{sem_bin_name}",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_RUN_PROC",
						"workflowType": "STANDARD"
					} for proc_nm, sem_bin_name_lst in sem_bin_names.items() for sem_bin_name in sem_bin_name_lst if proc_nm == process_name]
				],
				"description": "Proces Datalake, PROC_NM = ${PAR_PROC_NM}",
				"designParameters": [
					{
						"addNewValues": False,
						"addUnknownValues": False,
						"allowExpressions": False,
						"defaultValue": f"{process_name}",
						"designObjectId": f"{process_name}",
						"designObjectType": "PROCESSING",
						"domain": "BANK_D2",
						"domainClass": "DesignParameter",
						"editorType": "TEXT",
						"evaluateExpressions": False,
						"name": "PAR_PROC_NM",
						"required": True,
						"saveValueToResource": False,
						"sortOrder": 0,
						"title": "PAR_PROC_NM"
					},
					{
						"addNewValues": False,
						"addUnknownValues": False,
						"allowExpressions": False,
						"defaultValue": f"${{VAL_DUE_DT}}\",\"${{VAL_GCP_ETL_PKG_CD}}\",\"${{VAL_KEY_SEPARATOR}}\",\"${{VAL_REPL_TEXT}}{extract_version_txt}",
						"designObjectId": f"{process_name}",
						"designObjectType": "PROCESSING",
						"domain": "BANK_D2",
						"domainClass": "DesignParameter",
						"editorType": "TEXT",
						"evaluateExpressions": False,
						"name": "PAR_PROC_PARAM_LIST",
						"required": True,
						"saveValueToResource": False,
						"sortOrder": 1,
						"title": "PAR_PROC_PARAM_LIST"
					}
				],
				"domain": "BANK_D2",
				"domainClass": "ProcessingTemplate",
				"folder": "MyFolder",
				"highRisk": False,
				"id": f"[BANK_D2]{process_name}",
				"items": [
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_LOAD_IDA",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_LOAD_IDA",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 4,
						"templateParameters": {},
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_VALIDATION_SEM_CHECK",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_VALIDATION_SEM_CHECK",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 2,
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_ADA_PRE_PROCESS",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WFL_GCP_ADA_PRE_PROCESS",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 0,
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_RUN_PROC",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WFL_GCP_RUN_PROC",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 1,
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_VALIDATE_TMP",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WFL_GCP_VALIDATE_TMP",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 3,
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					}
				],
				"keepResourcesOnFailure": False,
				"lazyLoad": False,
				"onHold": False,
				"owner": "PZ006369",
				"passActionsToChildren": False,
				"passBy": False,
				"passResourceDependenciesToChildren": False,
				"preloadCounter": 0,
				"priority": "0",
				"processingType": "WORKFLOW",
				"sequentialProcessing": False,
				"simpleId": f"{process_name}",
				"tags": [
					"GCP",
					"DDP",
					xDA,
					tag_name
				],
				"turnOffDurationEstimation": False,
				"weight": "1",
				"workflowType": "STANDARD"
			}
		]
	elif xDA == 'EDA':
		process_lst = [
			{
				"actions": [
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateAction",
						"processingActionOrder": 0,
						"processingActionType": "PROCESSING_RUN_NOW",
						"processingCommand": {
							"includeContextVariables": True,
							"processingTemplate": "ES_TGR_WFL_GCP_INSERT_NOTIF_LOG",
							"specificDate": None,
							"timestampSelector": "SAME"
						},
						"processingEventCategory": "PROCESSING",
						"processingEventType": "PROCESSING_FAILED",
						"skip": False,
						"workflow": f"[BANK_D2]{process_name}"
					}
				],
				"autoArchive": False,
				"customFieldValues": {},
				"dependencies": [
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_EDA_VALIDATION_SEM_CHECK",
						"predecessor": "WFL_GCP_EDA_VALIDATION_SEM_CHECK",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_EDA_VALIDATION_SEM_CHECK",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_EDA_VALIDATION_PROC",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_EDA_PRE_PROC",
						"predecessor": "WFL_GCP_EDA_PRE_PROC",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_EDA_PRE_PROC",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_EDA_ETL_PROC",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_EDA_ETL_PROC",
						"predecessor": "WFL_GCP_EDA_ETL_PROC",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_EDA_ETL_PROC",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_EDA_VALIDATION_SEM_CHECK",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_EDA_VALIDATION_PROC",
						"predecessor": "WFL_GCP_EDA_VALIDATION_PROC",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_EDA_VALIDATION_PROC",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_EDA_POST_PROC",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_EDA_POST_PROC",
						"predecessor": "WFL_GCP_EDA_POST_PROC",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_EDA_POST_PROC",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_EDA_EXPORT_TABLE",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "RESOURCE",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{stock_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"resource": f"{stock_name}",
						"resourcePermits": "1",
						"resourceType": "STOCK",
						"sortKey": f"01.STOCK.{stock_name}",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					*[
						{
						"dependencyType": "RESOURCE",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{sem_bin_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"resource": f"{sem_bin_name}",
						"resourceType": "BINARY_SEMAPHORE",
						"semaphoreState": "OFF",
						"sortKey": f"03.BINARY_SEMAPHORE.{sem_bin_name}",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowItem": "WFL_GCP_EDA_ETL_PROC",
						"workflowType": "STANDARD"
					} for sem_bin_name in sem_bin_names]
				],
				"description": "Proces EDA Datalake, EXPORT_CD = ${PAR_EXPORT_CD}",
				"designParameters": [
					{
						"addNewValues": False,
						"addUnknownValues": False,
						"allowExpressions": False,
						"defaultValue": f"{process_name}",
						"designObjectId": f"{process_name}",
						"designObjectType": "PROCESSING",
						"domain": "BANK_D2",
						"domainClass": "DesignParameter",
						"editorType": "TEXT",
						"evaluateExpressions": False,
						"name": "PAR_EXPORT_CD",
						"required": True,
						"saveValueToResource": False,
						"sortOrder": 0,
						"title": "PAR_EXPORT_CD"
					}
				],
				"domain": "BANK_D2",
				"domainClass": "ProcessingTemplate",
				"folder": "MyFolder",
				"highRisk": False,
				"id": f"[BANK_D2]{process_name}",
				"items": [
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_EDA_VALIDATION_PROC",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_EDA_VALIDATION_PROC",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 3,
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_EDA_ETL_PROC",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_EDA_ETL_PROC",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 1,
						"templateParameters": {
							"PAR_PROC_PARAM_LIST": f"${{VAL_DUE_DT}}\",\"${{VAL_EXTRACT_VERSION}}\",\"${{VAL_GCP_ETL_PKG_CD}}\",\"${{LOAD_ID}}{extract_version_txt}"
						},
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_EDA_PRE_PROC",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_EDA_PRE_PROC",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 0,
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_EDA_EXPORT_TABLE",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_EDA_EXPORT_TABLE",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 5,
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_EDA_POST_PROC",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_EDA_POST_PROC",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 4,
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_EDA_VALIDATION_SEM_CHECK",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_EDA_VALIDATION_SEM_CHECK",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 2,
						"weight": "1",
						"workflow": f"[BANK_D2]{process_name}",
						"workflowType": "STANDARD"
					}
				],
				"keepResourcesOnFailure": False,
				"lazyLoad": False,
				"onHold": False,
				"owner": "S1613988",
				"passActionsToChildren": False,
				"passBy": False,
				"passResourceDependenciesToChildren": False,
				"preloadCounter": 0,
				"priority": "0",
				"processingType": "WORKFLOW",
				"sequentialProcessing": False,
				"simpleId": f"{process_name}",
				"tags": [
					"GCP",
					"DDP",
					xDA,
					tag_name
				],
				"turnOffDurationEstimation": False,
				"weight": "1",
				"workflowType": "STANDARD"
			}
		]

	if xDA in ['IDA', 'ADA']:
		anow_objects = stock_lst + static_semafore + process_lst
		anow_object_names = [stock_name, *sin_publish_sem_names, process_name]
	elif xDA == 'EDA':
		anow_objects = stock_lst  + process_lst
		anow_object_names = [stock_name, process_name]
		# anow_objects = stock_lst  + dependency_semaphore_lst + process_lst
		# anow_object_names = [stock_name, dependency_semaphore_name, process_name]

	# save procedure into file
	for dct, object_name in zip(anow_objects, anow_object_names):
		file_name = f'[BANK_D2]{object_name}.json'
		file_path = os.path.join(output_package_path, 'ANOW', 'JSON', file_name)	
		with open(file_path, 'w', encoding='utf-8') as f:
			json.dump([dct], f, indent=4)




def generate_anow_wf_files(output_package_path, wfl_name, calendar_name, scheduler_name, stock_name, sin_publish_sem_name, process_names, tag_name, xDA, calendar_flg, extract_version_txt):
	
	anow_objects = []
	anow_object_names = []

	if calendar_flg == 'CUSTOM':
		calendar_lst = [
			{
				"calendarType": "CAL_SELECT",
				"calendars": "KOMB_RSC_CAL_AGR_D1",
				"composite": False,
				"domain": "BANK_D2",
				"domainClass": "Resource",
				"id": "[BANK_D2]GCP_RSC_CAL_EDA_ENRICHED_TRX_DATA_CHIP",
				"resourceType": "CALENDAR",
				"simpleId": "GCP_RSC_CAL_EDA_ENRICHED_TRX_DATA_CHIP",
				"tags": [
					"GCP",
					"DDP",
					xDA,
					tag_name
				]
			}
		]
		anow_objects = calendar_lst
		anow_object_names = [calendar_name]
	
	if xDA in ['ADA', 'IDA']:
		scheduled_items = [wfl_name]
	elif xDA == 'EDA':
		scheduled_items = process_names

	scheduler_lst = [
		{
			"autoArchive": False,
			"domain": "BANK_D2",
			"domainClass": "ProcessingTemplate",
			"highRisk": False,
			"id": f"[BANK_D2]{scheduler_name}",
			"items": [
				{
					"domain": "BANK_D2",
					"domainClass": "ProcessingTemplateItem",
					"forceLoad": False,
					"highRisk": False,
					"keepResourcesOnFailure": False,
					"lazyLoad": False,
					"name": scheduled_item,
					"onHold": False,
					"optional": False,
					"parentProcessingType": "TRIGGER",
					"parentTriggerType": "SCHEDULE",
					"passBy": False,
					"processingTemplate": scheduled_item,
					"processingType": "WORKFLOW",
					"skipProcessingVariables": False,
					"sortOrder": 1,
					# "templateParameters": {
					# 	"PAR_EXPORT_CD": process_name
					# },
					# "timestampOffset": "-P0Y0M1DT0H0M0S",
					"workflow": f"[BANK_D2]{scheduler_name}",
					"workflowType": "STANDARD"
				} for scheduled_item in scheduled_items
			],
			"keepResourcesOnFailure": False,
			"lazyLoad": False,
			"onHold": False,
			"passActionsToChildren": False,
			"passBy": True,
			"passResourceDependenciesToChildren": False,
			"preloadCounter": 0,
			"processingType": "TRIGGER",
			"sequentialProcessing": False,
			"simpleId": f"{scheduler_name}",
			"tags": [
				"DDP",
				"GCP",
				xDA,
				tag_name
			],
			"timeTriggers": [
				{
					"calculateProcessingTimestampUsingLocalTime": False,
					"calendar": calendar_name,
					"domain": "BANK_D2",
					"domainClass": "ProcessingTimeTrigger",
					"endTime": 86399999,
					"onHold": False,
					"passBy": False,
					"preserveHourOfDayAcrossDaylightSavings": False,
					"processingTemplate": f"[BANK_D2]{scheduler_name}",
					"repeatInterval": 3600000,
					"skipDayIfHourDoesNotExist": False,
					"startTime": 3600000,
					"timeTriggerType": "DAILY",
					"timeZone": "Europe/Warsaw"
				}
			],
			"triggerType": "SCHEDULE",
			"turnOffDurationEstimation": False,
		}
	]

	anow_objects = anow_objects + scheduler_lst
	anow_object_names.append(scheduler_name)

		
	if xDA in ['ADA', 'IDA']:
		dependency_semaphore_name = f"{wfl_name}_COMPLETED_{wfl_name}"
		dependency_semaphore_lst = [
			{
				"composite": False,
				"domain": "BANK_D2",
				"domainClass": "Resource",
				"id": f"[BANK_D2]{dependency_semaphore_name}",
				"resourceType": "BINARY_SEMAPHORE",
				"simpleId": f"{dependency_semaphore_name}",
				"tags": [
					"GCP",
					"DDP",
					xDA,
					tag_name
				]
			}
		]


	if xDA == 'ADA':
		wfl_lst = [
			{
				"actions": [
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateAction",
						"processingActionOrder": 0,
						"processingActionType": "PROCESSING_RUN_NOW",
						"processingCommand": {
							"includeContextVariables": True,
							"processingTemplate": "ES_TGR_WFL_GCP_INSERT_NOTIF_LOG",
							"specificDate": None,
							"timestampSelector": "SAME"
						},
						"processingEventCategory": "PROCESSING",
						"processingEventType": "PROCESSING_FAILED",
						"skip": False,
						"workflow": f"[BANK_D2]{wfl_name}"
					}
				],
				"autoArchive": False,
				"dependencies": [
					{
						"dependencyType": "RESOURCE",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{wfl_name}_COMPLETED_{wfl_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"resource": f"{wfl_name}_COMPLETED_{wfl_name}",
						"resourceType": "BINARY_SEMAPHORE",
						"semaphoreState": "OFF",
						"sortKey": f"03.BINARY_SEMAPHORE.{wfl_name}_COMPLETED_{wfl_name}",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "RESOURCE",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{stock_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"resource": f"{stock_name}",
						"resourcePermits": "1",
						"resourceType": "STOCK",
						"sortKey": f"01.STOCK.{stock_name}",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					},
					*[{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WGL_GCP_PRE_PROCESS",
						"predecessor": "WGL_GCP_PRE_PROCESS",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WGL_GCP_PRE_PROCESS",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowItem": f"{process_name}",
						"workflowType": "STANDARD"
					} for process_name in process_names],
					*[{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{process_name}",
						"predecessor": f"{process_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": f"12.{process_name}",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowItem": "WFL_GCP_PUBLISH_TABLES",
						"workflowType": "STANDARD"
					} for process_name in process_names],
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_PUBLISH_TABLES",
						"predecessor": "WFL_GCP_PUBLISH_TABLES",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_PUBLISH_TABLES",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowItem": "WFL_GCP_POST_PROCESS",
						"workflowType": "STANDARD"
					}
				],
				"description": "Worfklow Datalake, WFL_NM = ${PAR_WFL_NM}",
				"designParameters": [
					{
						"addNewValues": False,
						"addUnknownValues": False,
						"allowExpressions": False,
						"defaultValue": f"{wfl_name}",
						"designObjectId": f"{wfl_name}",
						"designObjectType": "PROCESSING",
						"domain": "BANK_D2",
						"domainClass": "DesignParameter",
						"editorType": "TEXT",
						"evaluateExpressions": False,
						"name": "PAR_WFL_NM",
						"required": True,
						"saveValueToResource": False,
						"sortOrder": 0,
						"title": "PAR_WFL_NM"
					}
				],
				"domain": "BANK_D2",
				"domainClass": "ProcessingTemplate",
				"folder": "MyFolder",
				"highRisk": False,
				"id": f"[BANK_D2]{wfl_name}",
				"items": [
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_POST_PROCESS",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WFL_GCP_POST_PROCESS",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 3,
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_PUBLISH_TABLES",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_PUBLISH_TABLES",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 2,
						"weight": "1",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WGL_GCP_PRE_PROCESS",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WGL_GCP_PRE_PROCESS",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 0,
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					},
					*[{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": f"{process_name}",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": f"{process_name}",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 1,
						"templateParameters": {
							"PAR_PROC_NM": f"{process_name}",
							"PAR_PROC_PARAM_LIST":f"${{VAL_DUE_DT}}\",\"${{VAL_GCP_ETL_PKG_CD}}\",\"${{VAL_KEY_SEPARATOR}}\",\"${{VAL_REPL_TEXT}}{extract_version_txt}"
						},
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					} for process_name in process_names]
				],
				"keepResourcesOnFailure": False,
				"lazyLoad": False,
				"onHold": False,
				"owner": "PZ001622",
				"passActionsToChildren": False,
				"passBy": False,
				"passResourceDependenciesToChildren": False,
				"preloadCounter": 0,
				"priority": "0",
				"processingType": "WORKFLOW",
				"sequentialProcessing": False,
				"simpleId": f"{wfl_name}",
				"tags": [
					"GCP",
					"DDP",
					xDA,
					tag_name
				],
				"turnOffDurationEstimation": False,
				"weight": "1",
				"workflowType": "STANDARD"
			}
		]
	elif xDA == 'IDA':
		wfl_lst = [
			{
				"actions": [
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateAction",
						"processingActionOrder": 0,
						"processingActionType": "PROCESSING_RUN_NOW",
						"processingCommand": {
							"includeContextVariables": True,
							"processingTemplate": "ES_TGR_WFL_GCP_INSERT_NOTIF_LOG",
							"specificDate": None,
							"timestampSelector": "SAME"
						},
						"processingEventCategory": "PROCESSING",
						"processingEventType": "PROCESSING_FAILED",
						"skip": False,
						"workflow": f"[BANK_D2]{wfl_name}"
					}
				],
				"autoArchive": False,
				"comment": "dev",
				"customFieldValues": {},
				"dependencies": [
					{
						"dependencyType": "RESOURCE",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{wfl_name}_COMPLETED_{wfl_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"resource": f"{wfl_name}_COMPLETED_{wfl_name}",
						"resourceType": "BINARY_SEMAPHORE",
						"semaphoreState": "ON",
						"sortKey": f"03.BINARY_SEMAPHORE.{wfl_name}_COMPLETED_{wfl_name}",
						"timestampCalendar": "OHIO_RSC_CAL_LAST_MONTH_DAY",
						"timestampRelation": "EQ",
						"timestampSelector": "PREV_CAL_DAY",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					},
					*[{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WGL_GCP_PRE_PROCESS",
						"predecessor": "WGL_GCP_PRE_PROCESS",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WGL_GCP_PRE_PROCESS",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowItem": f"{process_name}",
						"workflowType": "STANDARD"
					} for process_name in process_names],
					*[{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": f"{process_name}",
						"predecessor": f"{process_name}",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": f"12.{process_name}",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowItem": "WFL_GCP_PUBLISH_TABLES",
						"workflowType": "STANDARD"
					} for process_name in process_names],
					{
						"dependencyType": "PREDECESSOR",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "WFL_GCP_PUBLISH_TABLES",
						"predecessor": "WFL_GCP_PUBLISH_TABLES",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"sortKey": "12.WFL_GCP_PUBLISH_TABLES",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowItem": "WFL_GCP_POST_PROCESS",
						"workflowType": "STANDARD"
					},
					{
						"dependencyType": "RESOURCE",
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateDependency",
						"groupId": str(uuid.uuid4()),
						"name": "GCP_RSC_STC_IDA_DIGITAL_MORTGAGE_DOUBLE_RUN_BLOCK",
						"processingStatus": "COMPLETED",
						"processingType": "WORKFLOW",
						"resource": "GCP_RSC_STC_IDA_DIGITAL_MORTGAGE_DOUBLE_RUN_BLOCK",
						"resourcePermits": "1",
						"resourceType": "STOCK",
						"sortKey": "01.STOCK.GCP_RSC_STC_IDA_DIGITAL_MORTGAGE_DOUBLE_RUN_BLOCK",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					}
				],
				"description": "Worfklow Datalake, WFL_NM = ${PAR_WFL_NM}",
				"designParameters": [
					{
						"addNewValues": False,
						"addUnknownValues": False,
						"allowExpressions": False,
						"defaultValue": f"{wfl_name}",
						"designObjectId": f"{wfl_name}",
						"designObjectType": "PROCESSING",
						"domain": "BANK_D2",
						"domainClass": "DesignParameter",
						"editorType": "TEXT",
						"evaluateExpressions": False,
						"name": "PAR_WFL_NM",
						"required": True,
						"saveValueToResource": False,
						"sortOrder": 0,
						"title": "PAR_WFL_NM"
					}
				],
				"domain": "BANK_D2",
				"domainClass": "ProcessingTemplate",
				"eagerScriptExecution": False,
				"folder": "MyFolder",
				"hasNotes": False,
				"hasPendingNotes": False,
				"highRisk": False,
				"id": f"[BANK_D2]{wfl_name}",
				"items": [
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_POST_PROCESS",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WFL_GCP_POST_PROCESS",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 4,
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					},
					*[{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": f"{process_name}",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": f"{process_name}",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 2,
						"templateParameters": {
							"PAR_PROC_NM": f"{process_name}",
							# "PAR_PROC_PARAM_LIST": "${VAL_DUE_DT}\",\"${VAL_GCP_ETL_PKG_CD}\",\"${VAL_KEY_SEPARATOR}\",\"${VAL_REPL_TEXT}\",\"${EXTRACT_VERSION_T208016}\",\"${EXTRACT_VERSION_T208017}"
							"PAR_PROC_PARAM_LIST": f"${{VAL_DUE_DT}}\",\"${{VAL_GCP_ETL_PKG_CD}}\",\"${{VAL_KEY_SEPARATOR}}\",\"${{VAL_REPL_TEXT}}{extract_version_txt}"
						},
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					} for process_name in process_names],
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WGL_GCP_PRE_PROCESS",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"processingTemplate": "WGL_GCP_PRE_PROCESS",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 1,
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					},
					{
						"domain": "BANK_D2",
						"domainClass": "ProcessingTemplateItem",
						"forceLoad": False,
						"highRisk": False,
						"keepResourcesOnFailure": False,
						"lazyLoad": False,
						"name": "WFL_GCP_PUBLISH_TABLES",
						"onHold": False,
						"optional": False,
						"parentProcessingType": "WORKFLOW",
						"parentWorkflowType": "STANDARD",
						"passBy": False,
						"priority": "0",
						"processingTemplate": "WFL_GCP_PUBLISH_TABLES",
						"processingType": "WORKFLOW",
						"skipProcessingVariables": False,
						"sortOrder": 3,
						"weight": "1",
						"workflow": f"[BANK_D2]{wfl_name}",
						"workflowType": "STANDARD"
					}
				],
				"keepResourcesOnFailure": False,
				"lazyLoad": False,
				"noteCount": 0,
				"onHold": False,
				"owner": "PZ006369",
				"passActionsToChildren": False,
				"passBy": False,
				"passResourceDependenciesToChildren": False,
				"pendingNoteCount": 0,
				"preloadCounter": 0,
				"priority": "0",
				"processingType": "WORKFLOW",
				"reason": "",
				"sequentialProcessing": False,
				"simpleId": f"{wfl_name}",
				"tags": [
					"DDP",
					"GCP",
					xDA,
					tag_name
				],
				"turnOffDurationEstimation": False,
				"useScripts": False,
				"weight": "1",
				"workflowType": "STANDARD"
			}
		]
	

	if xDA in ['ADA', 'IDA']:
		anow_objects = anow_objects + dependency_semaphore_lst + wfl_lst
		anow_object_names.append(dependency_semaphore_name)
		anow_object_names.append(wfl_name)
	elif xDA == 'EDA':
		# anow_objects = anow_objects + wfl_lst
		anow_objects = anow_objects + process_names
		# anow_object_names.append(wfl_name)


	# save procedure into file
	for dct, object_name in zip(anow_objects, anow_object_names):
		file_name = f'[BANK_D2]{object_name}.json'
		file_path = os.path.join(output_package_path, 'ANOW', 'JSON', file_name)
		with open(file_path, 'w', encoding='utf-8') as f:
			json.dump([dct], f, indent=4)


