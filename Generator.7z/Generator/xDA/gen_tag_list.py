import os
import re
from pathlib import Path
from glob import glob
from excel_functions_ida import *


# def generate_tag_list_file(output_package_path, wfl_name, calendar_name, scheduler_name, stock_name, sin_publish_sem_name, process_names, calendar_flg):
def generate_tag_list_file(output_package_path):

	# # %%
	# process_names_txt = '\n^\[BANK_D2\]'.join(process_names)
	# if calendar_flg == 'CUSTOM':
	# 	tag_body_txt = f'^\[BANK_D2\]{sin_publish_sem_name}\n^\[BANK_D2\]{calendar_name}\n^\[BANK_D2\]{stock_name}\n^\[BANK_D2\]{process_names_txt}\n^\[BANK_D2\]{wfl_name}\n^\[BANK_D2\]{scheduler_name}'
	# else:
	# 	tag_body_txt = f'^\[BANK_D2\]{sin_publish_sem_name}\n^\[BANK_D2\]{stock_name}\n^\[BANK_D2\]{process_names_txt}\n^\[BANK_D2\]{wfl_name}\n^\[BANK_D2\]{scheduler_name}'


	directory = Path(output_package_path)
	directory = directory.joinpath('ANOW', 'JSON')
	file_list = [file.name for file in directory.iterdir() if file.is_file()]
	regex_patterns = ['^\[BANK_D2\]DTLK_RSC_SEM_DATALAKE_GCP_[AEI]DA_\w+.json$','^\[BANK_D2\]GCP_RSC_CAL_[AEI]DA_\w+.json$','^\[BANK_D2\]GCP_RSC_STC_[AEI]DA_T\d+?_\w+_DOUBLE_RUN_BLOCK.json$','^\[BANK_D2\]WFL_GCP_[AEI]DA_T\d+?_\w+?.json$','^\[BANK_D2\]WFL_GCP_[AEI]DA_T\d+?_\w+_COMPLETED_WFL_GCP_[AEI]DA_T\d+?_\w+.json$','^\[BANK_D2\]WFL_GCP_DDP_[AEI]DA_\w+.json$','^\[BANK_D2\]TS_GCP_RSC_SL_[AEI]DA_\w+.json$']
	
	# Define a custom sorting function
	def custom_sort(item):
		for pattern in regex_patterns:
			if re.match(pattern, item):
				return regex_patterns.index(pattern)
		return len(regex_patterns)

	# Sort the list using the custom sorting function
	sorted_list = sorted(file_list, key=custom_sort)

	# Display the sorted list
	# print(sorted_list)

	list_txt = '\n'.join(sorted_list)
	list_txt = re.sub('\.json', '', list_txt)

	# save procedure into file
	install_file = 'LIST.txt'
	install_file_path = os.path.join(output_package_path, 'ANOW', install_file)
	with open(install_file_path, 'w', encoding='utf-8') as f:
		f.write(list_txt)

