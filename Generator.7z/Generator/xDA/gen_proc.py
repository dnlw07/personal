import os
import numpy as np
from script_templates import procedure_body
from excel_functions_ida import *


def generate_procedure_files(df, package_path, procedure_name, source_schema, src_table_dct, source_table, tgt_table_dct, target_schema, target_table, target_table_prefix, target_fields_lst, where_clause, model_table_type_cd, xDA):
	source_table_alias = [elem for elem in list(dict.fromkeys(df['Alias źródłowego zbioru danych'].values.tolist())) if elem and elem.strip().lower() != 'n/a'][0]
	# source_table_prefix = source_table[0:7]
	source_table_prefix = re.findall('t\d+', source_table, re.IGNORECASE)[0]

	join_str = ''
	for src_table, lst in tgt_table_dct.items():
		if lst[1].strip().lower().strip() != 'n/a': # pomija tabelę master
			try:
				table_num = re.findall('\d+', src_table)[0]
				join_str += f'{lst[1].upper()} {src_table.lower()} {lst[0].lower()}\nON {lst[2].lower()}\nAND {lst[0].lower()}.due_dt = v_due_dt\nAND {lst[0].lower()}.extract_version = in_extract_version_t{table_num}\n\n'
			except:
				print('WARNING! Cannot generate joins scripts in procedure file.')
				pass
	join_str = join_str[:-1]

	extract_version_str = ''
	for src_table, src_chema in src_table_dct.items():
		if 'sda' in src_chema.lower():
			table_num = re.findall('\d+', src_table)[0]
			# extract_version_str += f'\tIN in_extract_version_t{src_table[1:7]} STRING,\n'
			extract_version_str += f'\tIN in_extract_version_t{table_num} STRING,\n'
	extract_version_str = f'{extract_version_str[1:-1]}'

	# tech field logic
	df['cast_logic'] = np.where(df.index.str.lower() == 'start_dt', 'CAST(v_due_dt AS DATE) AS start_dt', '')
	df['cast_logic'] = np.where(df.index.str.lower() == 'end_dt', 'CAST(v_end_dt AS DATE) AS end_dt', df['cast_logic'])
	df['cast_logic'] = np.where(df.index.str.lower() == 'sys_cd', 'CAST(sys_cd AS STRING) AS sys_cd', df['cast_logic'])
	df['cast_logic'] = np.where(df.index.str.lower() == 'tech_is_active_flg', 'CAST(\'1\' AS STRING) AS tech_is_active_flg', df['cast_logic'])
	df['cast_logic'] = np.where(df.index.str.lower() == 'tech_etl_pkg_cd', 'CAST(in_etl_package_cd AS STRING) AS tech_etl_pkg_cd', df['cast_logic'])
	
	if xDA in ['ADA', 'IDA']:
		df['cast_logic'] = np.where(df.index.str.lower() == 'tech_insert_id', 'CAST(0 AS INT64) AS tech_insert_id', df['cast_logic'])
	elif xDA == 'EDA':
		df['cast_logic'] = np.where(df.index.str.lower() == 'tech_insert_id', 'CAST(in_load_id AS INT64) AS tech_insert_id', df['cast_logic'])
	
	df['cast_logic'] = np.where(df.index.str.lower() == 'tech_insert_ts', 'CAST(CURRENT_DATETIME(\'Europe/Warsaw\') AS TIMESTAMP) AS tech_insert_ts', df['cast_logic'])
	df['cast_logic'] = np.where(df.index.str.lower() == 'tech_update_id', 'CAST(NULL as INT64) AS tech_update_id', df['cast_logic'])
	df['cast_logic'] = np.where(df.index.str.lower() == 'tech_update_ts', 'CAST(NULL as TIMESTAMP) AS tech_update_ts', df['cast_logic'])
	df['cast_logic'] = np.where(df.index.str.lower() == 'tech_close_id', 'CAST(NULL as INT64) AS tech_close_id', df['cast_logic'])
	df['cast_logic'] = np.where(df.index.str.lower() == 'tech_close_ts', 'CAST(NULL as TIMESTAMP) AS tech_close_ts', df['cast_logic'])
	df['cast_logic'] = np.where(df.index.str.lower() == 'due_dt', 'CAST(v_due_dt AS DATE) AS due_dt', df['cast_logic'])
	

	# add new line after technical fields (differnt field name for SCD2 and fact)
	target_fields = ',\n\t'.join(target_fields_lst)
	if 'tech_close_ts' in target_fields:
		target_fields = target_fields.replace('tech_close_ts,', 'tech_close_ts,\n')
	else:
		target_fields = target_fields.replace('tech_insert_ts,', 'tech_insert_ts,\n')

	#%%
	# business fields logic
	tech_fields = ['due_dt', 'start_dt', 'end_dt', 'sys_cd', 'tech_is_active_flg', 'tech_etl_pkg_cd', 'tech_insert_id', 'tech_insert_ts', 'tech_update_id', 'tech_update_ts', 'tech_close_id', 'tech_close_ts']
	df['cast_logic'] = np.where(~df.index.str.lower().isin(tech_fields), 'CAST(' + df['Kolumna źródłowa'].str.strip() + ' AS ' + df['Typ'].str.upper().str.strip().replace(r'\(.*\)', '', regex=True) + ') AS ' + df.index.str.strip(), df['cast_logic'])
	# print(df)


	# #%%
	# get PK name
	filter = (df['Primary Key'].str.upper() == 'T') & (df.index.str.lower() != 'end_dt')
	pk_names = np.where(filter, df.index, '')
	try:
		pk_name_str = [pk_name for pk_name in pk_names if pk_name][0]
	except:
		pk_name_str = ""
		if xDA != 'ADA':
			print('WARING! No PK found!')

	# print(pk_name_str)

	if xDA == 'IDA':
		#%%
		# get NK fields
		filter = (df['Natural Key'].str.upper() == 'T') & (df.index.str.lower() != 'sys_cd')
		nk_fields = get_filtered_values_list(df=df, out_column_name='Kolumna źródłowa', filter=filter)
		# print(nk_fields)


		#%%
		# get cast NK field logic
		filter = (df['Primary Key'].str.upper() != 'T') & (df['Kolumna źródłowa'].isin(nk_fields))
		nk_cast_fields = np.where(filter, df['cast_logic'], '')
		nk_cast_fields = get_filtered_values_list(df=df, out_column_name='cast_logic', filter=filter)
		# nk_cast_fields = nk_cast_fields.repalce('CAST(', f'CAST({source_table_alias.lower()}') # add alias
		# print(nk_cast_fields)


		#%%
		# get sys_cd logic
		filter = (df.index.str.lower() == 'sys_cd')
		sys_cd_cast = get_filtered_values_list(df=df, out_column_name='cast_logic', filter=filter)[0]
		# sys_cd_cast = get_filtered_values_list(df=df, out_column_name='cast_logic', filter=filter)[0][:-1] # dlaczego [:-1]??
		# print(sys_cd_cast)

		nk_cast_fields.append(sys_cd_cast)
		

		#%%
		# usuń aliasy ' AS field_name'
		nk_cast_fields_2 = []
		for nk_cast_field in nk_cast_fields:
			nk_cast_fields_2.append(re.sub('\) AS \w+?,?$', ')', nk_cast_field, re.IGNORECASE))

		#%%
		# zamień typ danych z docelowego na STRING (tylko w przypadku generowania klucza sztucznego)
		nk_cast_fields_3 = []
		for nk_cast_field in nk_cast_fields_2:
			nk_cast_fields_3.append(re.sub('AS \w+', 'AS STRING', nk_cast_field, re.IGNORECASE))


		#%%
		# create NK logic for PK
		pk_cast_nk = ''
		for i, nk_cast_field in enumerate(nk_cast_fields_3):
			nk_cast_field = nk_cast_field.replace('CAST(', f'CAST({source_table_alias.lower()}.')
			if i == len(nk_cast_fields_3) - 1:
				pk_cast_nk += f'COALESCE({nk_cast_field[:-1]}), in_missing_val_replacement_text)'
			else: 
				pk_cast_nk += f'COALESCE({nk_cast_field[:-1]}), in_missing_val_replacement_text) || in_surrogate_key_separator || \n\t\t'


		#%%
		# create full PK logic
		pk_logic = f'CAST(UPPER(TO_HEX(MD5(\n\t\t{pk_cast_nk}\n\t\t))) AS STRING\n\t) AS {pk_name_str}'
		# print(pk_logic)


		#%%
		# update PK record with PK logic
		filter = (df['Primary Key'].str.upper() == 'T') & (df.index.str.lower() != 'due_dt') & (df.index.str.lower() != 'end_dt') & (df.index.str.lower() != 'extract_version') & (df['Natural Key'].str.lower() != 'T')
		df['cast_logic'] = np.where(filter, pk_logic, df['cast_logic'])
		# print(df)
	
	if xDA == 'EDA':
		filter = (df.index.str.lower() == 'extract_version')
		df['cast_logic'] = np.where(filter, 'CAST(in_extract_version AS STRING) AS extract_version', df['cast_logic'])


	#%%
	# convert cast_logic list into string
	df6 = df[['cast_logic']]
	cast_logic_lst = df6['cast_logic'].values.tolist()
	cast_logic = ',\n\t'.join(cast_logic_lst)

	# add new line after technical fields (differnt field name for SCD2 and fact)
	if 'tech_close_ts' in cast_logic:
		cast_logic = cast_logic.replace('tech_close_ts,', 'tech_close_ts,\n')
	else:
		cast_logic = cast_logic.replace('tech_insert_ts,', 'tech_insert_ts,\n')


	#%%
	# procedure_name = f'load_{target_table_prefix}_{src_sys_cd}_01_01_p'.lower() # ex. load_t408005_prkr_01_01_p
	procedure_body_txt = procedure_body(procedure_name, source_schema, source_table, source_table_alias, extract_version_str, join_str, target_fields, target_schema, target_table, source_table_prefix, cast_logic, where_clause, model_table_type_cd, xDA)


	#%%
	# save procedure into file
	proc_file = f'{procedure_name}.sql'
	proc_file_path = os.path.join(package_path, 'BQ/ROUTINE', proc_file)
	with open(proc_file_path, 'w', encoding='utf-8') as f:
		f.write(procedure_body_txt)

