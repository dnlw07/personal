# General
generor_mode = 'IDA' # ['Spec', 'STM', 'LDM', 'I', 'IDA', 'ADA', 'EDA', 'xDA']
xDA = 'IDA'
calendar_flg = 'LAST_MONTH_DAY' # ['ALL', 'WORKING', 'CUSTOM', 'OZSI', 'LAST_MONTH_DAY']
wf_ID = 'DIGITAL_MORTGAGE' # dla EDA analogicznie jak dla IDA/ADA (nazwa potrzebna np. dla wspólnego scheulera dla kilku tabel)
package_id = 'DIGM'  # max 8 letters
version = '01.00'


# input here sheet_names, table_names or table codes ('txxxxxx')
# EXAMPLES:
# old_table_codes = ['T60108','T60999','T60001']
# old_table_codes = ['T60102_FCTD_ACTION_STATUS', 'T60103_FCTD_LEAD_STATUS', 'T60008_DIM_MARKETING_CAMPAIGN', 'T60911_ODD_RAP_CTL_CLOSE_TO_LOOP']


old_table_codes = []  # to generate DOCUMENTATION and SCRIPTS
new_table_codes = ['t406012'] # to generate SCRIPTS or STM only!


output_ldm_file_path = rf"C:\Dane\repo\git\specifications\IDA\406_account_IDA_Logiczny_Model_Danych_v1.10.xlsx"
output_stm_file_path = rf"C:\Users\PZ006369\Desktop\406_account_IDA_STM_v1.10.xlsx"  # if None then generates DDL scripts only!


################################################################################################
# xDA
################################################################################################

# filled or empty - wyciągnąć z metadanych
sem_bin_names = {
	'WFL_GCP_EDA_T602011_DEBT_RECOVE_PZKB_01': [
		'DTLK_RSC_SEM_DATALAKE_GCP_ADA_CUST_PZKB',
		'DTLK_RSC_SEM_DATALAKE_GCP_RDA_102_OHIO_DATA_IDA_02_HST_T02341_GARNISHMENT',
		'DTLK_RSC_SEM_DATALAKE_GCP_RDA_102_OHIO_DATA_IDA_02_HST_T02343_GARNISHMENT_CUST_REL'
	]
}

################################################################################################
# SDA
################################################################################################
tech_spec_file_path = rf"C:\Users\PZ006369\Desktop\Specyfikacje_Interfejsow_OZSI_v0.14.xlsx"
# sda_sheet_names = ['BGDTMDF','BGDTIAF']
sda_sheet_names = ['BGDTMDF']


################################################################################################
# Tech Spec generator
################################################################################################
sda_schema_name = 'ADA_516_PZKB_WR_DATA'
sda_table_codes = ['T60102_FCTD_ACTION_STATUS','T60103_FCTD_LEAD_STATUS','T60008_DIM_MARKETING_CAMPAIGN']


# wyciągnięte z bazy oracle - użyj F5
# @"C:\Dane\repo\python\Generator\STM\sql\tech_spec.sql"
# UWAGA! keep table_name proper order! 
sda_atc = [

]

################################################################################################
# STM generator
################################################################################################
input_stm_file_path = rf'' # if empty or None then generates a new STM


# fill in if input_stm_file_path is empty or None
stm_source_lst = {
	# 't516003_dim_dist_network': [
	# 	'ada_516_pzkb_wr_data.test',
	# ],
	# 't996001_mm_fctd_sales_cpy_tmp': [
	# 	'tda_996_sandbox_dad_data.t60999_fctd_sales_cpy_oryg2',
	# 	'ada_516_pzkb_wr_data.t516001_fctd_sales',
	# 	'rda_102_ohio_data_ida_01_act.t01119_acct_mapping',
	# 	'rda_102_ohio_data_ida_02_hst.t02103_depo_acct_act',
	# 	'rda_102_ohio_data_ida_02_hst.t02025_cust_acct_rel_act',
	# 	'ida_418_camp_history_data.t418001_lead_char_history_act',
	# 	'ida_418_camp_history_data.t418003_action_char_history_act',
	# 	'ida_418_camp_history_data.t418104_dict_offer',
	# 	'ida_498_dictionaries_data.t498084_pzkb_prod_hrchy_dct_act'
	# ],
	# 't996002_mm_fctd_sales_cpy_src':  [
	# 	'tda_996_sandbox_dad_data.t996001_mm_fctd_sales_cpy_tmp',
	# 	'ida_418_camp_history_data.t418004_action_stat_history',
	# 	'ida_418_camp_history_data.t418104_dict_offer',
	# 	'ida_418_camp_history_data.t418112_dict_combo_offer',
	# 	'ida_498_dictionaries_data.t498084_pzkb_prod_hrchy_dct',
	# 	'ida_418_camp_history_data.t418902_action_response_history',
	# 	'ida_418_camp_history_data.t418102_dict_response',
	# 	'tda_996_sandbox_dad_data.IGNORED_OFFERS'
	# ],
	# 't996003_fctd_sales_cpy_final':  [
	# 	'tda_996_sandbox_dad_data.t996001_mm_fctd_sales_cpy_tmp',
	# 	'ida_418_camp_history_data.t418004_action_stat_history',
	# 	'ida_418_camp_history_data.t418104_dict_offer',
	# 	'ida_418_camp_history_data.t418112_dict_combo_offer',
	# 	'ida_498_dictionaries_data.t498084_pzkb_prod_hrchy_dct',
	# 	'ida_418_camp_history_data.t418902_action_response_history',
	# 	'ida_418_camp_history_data.t418102_dict_response',
	# 	'tda_996_sandbox_dad_data.IGNORED_OFFERS'
	# ],
	# 't516108_fctd_sales_contr': [
	# 	'tda_996_sandbox_dad_data.t996002_mm_fctd_sales_cpy_src',
	# 	'tda_996_sandbox_dad_data.t996002_mm_fctd_sales_cpy_src',
	# 	'tda_996_sandbox_dad_data.fctd_sales_cpy_final'
	# ],
	# 't516002_fctd_sales_add': [
	# 	'ida_418_camp_history_data.t418001_lead_char_history',
	# 	'ida_418_camp_history_data.t418003_action_char_history',
	# 	'ida_418_camp_history_data.t418004_action_stat_history',
	# 	'ada_502_pzkb_common_data.t502001_cust',
	# 	'ida_406_account_data.t406008_eservice_pos',
	# 	'ada_516_pzkb_wr_data.t516002_fctd_sales_add',
	# 	'ida_404_customer_data.t404016_ekantor_cust',
	# 	'eda_602_pzkb_data.t602214_acct_trx',
	# 	'ida_404_customer_data.t404003_auth_type',
	# 	'ada_516_pzkb_wr_data.t516001_fctd_sales',
	# 	'rda_102_ohio_data_ida_02_hst.t02025_cust_acct_rel',
	# 	'ida_498_dictionaries_data.t498084_pzkb_prod_hrchy_dct'
	# ]


}

sys_cd = 'PZKB'
tgt_schema_name = 'EDA_602_PZKB_DATA'


stm_sys_map = {
'Batch DB': 'SCI1',
'Oper DB': 'RTM1',
'MDM': 'MDM',
}


schema_map = {
'DB_STAGE': 'SDA_226_SCI1_DATA',
'DB10_MDM_COMMON': 'IDA_408_CRED_APPL_DATA',
'DB11_MDM_CUSTOMER': 'ADA_502_PZKB_COMMON_DATA',
'DB15_CAMPAIGN_MGMT': 'IDA_418_CAMP_HISTORY_DATA',
'DB17_MDM_EVENT': 'IDA_420_COMMON_DATA',
'DB60_REPORTING_DM': 'ADA_516_PZKB_WR_DATA',
}


table_map = {
'T11001_CUST': 'T502001_CUST',
'T10008_DRK_LIMITS_KMB': 'T408016_BDK_LIMIT_IND',
'T10008_DRK_LIMITS_KMB_FT': 'T408017_FAST_TRACK_IND',
'T10008_DRK_INVL_INSECURE': 'T408015_UNSECURED_INVOLVEMENT',
'T10008_DRK_PKOPAY_BNPL': 'T408018_PKOPAY_LIMIT_IND',

# RDDKM
'T15001_LEAD_CHAR_HISTORY': 'T418001_LEAD_CHAR_HISTORY',
'T15002_LEAD_STAT_HISTORY': 'T418002_LEAD_STAT_HISTORY',
'T15003_ACTION_CHAR_HISTORY': 'T418003_ACTION_CHAR_HISTORY',
'T15004_ACTION_STAT_HISTORY': 'T418004_ACTION_STAT_HISTORY',
'T15007_CAMPAIGN_BIZ_CATALOG': 'T418007_CAMPAIGN_BIZ_CATALOG',
'T15008_CAMPAIGN_CATALOG': 'T418008_CAMPAIGN_CATALOG',
'T15105_DICT_CAMP_TYPE': 'T418105_DICT_CAMP_TYPE',
'T15106_DICT_CAMP_SUBGROUP': 'T418106_DICT_CAMP_SUBGROUP',
'T15107_DICT_CAMP_CLASS': 'T418107_DICT_CAMP_CLASS',

# WR
'T60008_DIM_MARKETING_CAMPAIGN': 'T516008_DIM_MARKETING_CAMPAIGN',
'T60102_FCTD_ACTION_STATUS': 'T516102_FCTD_ACTION_STATUS',
'T60103_FCTD_LEAD_STATUS': 'T516103_FCTD_LEAD_STATUS',
'T60911_ODD_RAP_CTL_CLOSE_TO_LOOP': 'T516911_ODD_RAP_CTL_CLOSE_TO_LOOP',
'T60108_FCTD_SALES_CONTR': 'T516103_FCTD_SALES_CONTR',
'T60999_FCTD_SALES_CPY': 'T516001_FCTD_SALES',
'T99001_FCTD_SALES': 'T516002_FCTD_SALES_ADD',
}


# wyciągnięte z bazy oracle - użyj F5
# @"C:\Dane\repo\python\Generator\STM\sql\return_PK.sql"
ida_pk = [
# {'TABLE_NAME': 'T15001_LEAD_CHAR_HISTORY', 'COLUMN_NAME': 'LEAD_ID'},
{"table_name":"T60103_FCTD_LEAD_STATUS","column_name":"LEAD_ID"}
,{"table_name":"T60102_FCTD_ACTION_STATUS","column_name":"ACTION_ID"}
]



################################################################################################
# LDM  generator
################################################################################################
input_ldm_file_name = rf"C:\Dane\repo\git\specifications\ADA\PZKB\PZKB_ADA_LDM_v1.23.xlsx"

# wyciągnięte z bazy oracle - użyj F5
# @"C:\Dane\repo\python\Generator\STM\sql\tech_spec.sql"
# UWAGA! keep table_name proper order!
ldm_atc = [
{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"TOUCHEDCOUNT","type":"NUMERIC(,)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"CONTACTCOUNT","type":"NUMERIC(,)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"TASKCOMMENT","type":"STRING(4000)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"ACTION_ID","type":"NUMERIC(12,0)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"CAMPAIGN_BUSINESS_CD","type":"STRING(48)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"FORMTYPE","type":"STRING(800)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"FORMCHANNEL","type":"STRING(800)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"FORMDATE","type":"STRING(64)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"PRODUCTTYPE","type":"STRING(800)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"PID","type":"STRING(32)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"NPSRATE","type":"STRING(64)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"NPSCOMMENT","type":"STRING(1604)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"TASKACTION","type":"STRING(9)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"TASKRESULT","type":"STRING(160)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"TASKRESULTNAME","type":"STRING(4000)","wersja":"1.0","zmiana":"I"}
,{"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"TASKSTATUS","type":"STRING(5)","wersja":"1.0","zmiana":"I"}
]




################################################################################################
# MAIN
################################################################################################
from pathlib import Path
import sys


if __name__ == "__main__":
	if generor_mode == 'Spec':
		sys.path.append(Path(__file__).parent.joinpath('STM').as_posix())
		from STM import _generator_Tech_spec
	elif generor_mode == 'LDM':
		sys.path.append(Path(__file__).parent.joinpath('STM').as_posix())
		# from STM import _generator_LDM_v1  # STM and LDM are in the same file
		from STM import _generator_LDM_v2  # STM and LDM are in separate files
	elif generor_mode == 'STM':
		sys.path.append(Path(__file__).parent.joinpath('STM').as_posix())
		from STM import _generator_STM
	elif generor_mode == 'SDA':
		sys.path.append(Path(__file__).parent.joinpath('SDA').as_posix())
		from SDA import _generator_SDA
	elif generor_mode in ['IDA', 'ADA', 'EDA', 'xDA']:
		sys.path.append(Path(__file__).parent.joinpath('xDA').as_posix())
		from xDA import _generator_xDA


# # Manually generate/update INSTALL.txt file
# package_path = Path(r'C:\Dane\repo\git\INSTALL\GCP\GCP-IDA_INS-06.00')
# generate_install_files(package_path, package_path.name)



