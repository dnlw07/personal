import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
from openpyxl import load_workbook, Workbook
# import pandas as pd
# from datetime import datetime
# import re
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from copy import deepcopy
from excel_functions_stm import *

# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
from control_panel import wf_ID, sda_table_codes, sys_cd, sda_schema_name, sda_atc, stm_sda_table_map



# wf_ID = 'ESF'
# sda_table_codes = ['T226001','T226002','T226003','T226004']

tmp_wb_paths = [r'C:\Dane\repo\projects\_templates\tmp_SDA.xlsx']


# path to executable file
base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output')
output_package_path = rf'C:\Dane\repo\python\Generator\_output'
output_file_path = os.path.join(output_package_path, f'Specyfikacja_interfejsów_{wf_ID}_v0.1.xlsx')


# [os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.xls'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany


# replace 'null' with an empty string
for dct in sda_atc:
	for k,v in dct.items():
		dct[k] = '' if v == 'null' else v


sda_dct = {}
for item in sda_atc:
    table_name = item['table_name']
    column_name = item['column_name']
    if table_name not in sda_dct:
        sda_dct[table_name] = [{**{k: v for k, v in item.items() if k != 'table_name'}}]
    else:
        sda_dct[table_name].append({**{k: v for k, v in item.items() if k != 'table_name'}})

# TODO - sort dict by keys in another dict
# stm_sda_table_map

# loop through workbooks
for tmp_wb_path in tmp_wb_paths:

	# open STM workbook
	tmp_wb = load_workbook(tmp_wb_path, read_only=False, data_only=False) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again

	row = 3
	for src_table_name, table_body in sda_dct.items():
		tgt_table_name = stm_sda_table_map[src_table_name].lower() if src_table_name in stm_sda_table_map.keys() else src_table_name.lower()
		table_prefix = stm_sda_table_map[src_table_name][0:7].lower() if src_table_name in stm_sda_table_map.keys() else src_table_name[0:7].lower()

		if table_prefix.upper() in sda_table_codes:
			# create new sheet
			sheet_name = copy_and_move_sheet(tmp_wb, 'tmp', table_prefix, dest_pos=None)
			
			# set zoom
			tmp_wb[sheet_name].sheet_view.zoomScale = 85

			################################
			# HEADER TABLE
			tmp_wb[sheet_name]['D2'].value = src_table_name.lower()
			tmp_wb[sheet_name]['D4'].value = sys_cd
			tmp_wb[sheet_name]['D5'].value = sys_cd
			tmp_wb[sheet_name]['G2'].value = src_table_name.lower()
			tmp_wb[sheet_name]['G4'].value = sys_cd
			tmp_wb[sheet_name]['J2'].value = stm_sda_table_map[src_table_name].lower() if src_table_name in stm_sda_table_map.keys() else src_table_name.lower()
			tmp_wb[sheet_name]['J3'].value = sda_schema_name.lower()
			tmp_wb[sheet_name]['J7'].value = ''
			tmp_wb[sheet_name]['J8'].value = 'FULL' # INCR or FULL
			tmp_wb[sheet_name]['J19'].value = f'{sys_cd}_01'
			tmp_wb[sheet_name]['J20'].value = 'FULL' # INCR or FULL
			tmp_wb[sheet_name]['J25'].value = stm_sda_table_map[src_table_name].lower() if src_table_name in stm_sda_table_map.keys() else src_table_name.lower()
			tmp_wb[sheet_name]['J26'].value = sda_schema_name.lower()
			tmp_wb[sheet_name]['J30'].value = src_table_name.upper()

			################################
			# MAIN TABLE
			row_num = dict_to_range(table_body, tmp_wb[sheet_name], start_cell='A34', table_name=None, orientation='H', formatting_type=None)

			################################
			# Index sheet
			tmp_wb['Index'][f'A{row}'].value = table_prefix
			row+=1


	# remove tmp sheet
	del tmp_wb['tmp']
	del tmp_wb['example']


	# save workbook
	tmp_wb.save(output_file_path)  # jeżeli błąd to zainstalować starszą wersję: pip install openpyxl-2.6.2
	
	# open file
	os.system(output_file_path) # development purpose only

