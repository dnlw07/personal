import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
from openpyxl import load_workbook, Workbook
import pandas as pd

# from datetime import datetime
# import re
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from copy import deepcopy
from excel_functions_stm import *

# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
from control_panel import wf_ID, jira, tgt_schema_name, table_codes, input_ldm_file_name, ida_pk, ldm_atc
from const import ldm_pk_field, ldm_tech_fields_scd1_ovr, ldm_tech_fields_scd1_act, ldm_tech_fields_scd2, ldm_tech_fields_fact, ldm_tech_fields_snap_ovr



# table_codes = ['T17101', 'T17102']
# input_ldm_file_name = 'CRM3.0_Model_Danych_MDM_-_Zdarzenia_i_Sygnały_v0.1.xlsx'
# jira = '8296'
# wf_ID = 'ESF'
# tgt_schema_name = 'IDA_420_COMMON_DATA'

# src_paths = [rf'C:\Dane\repo\projects\RPZKB-{jira}\dokumentacja\{input_ldm_file_name}']
src_paths = [rf'{input_ldm_file_name}']
tmp_wb_paths = [r'C:\Dane\repo\projects\_templates\tmp_LDM.xlsx']





# path to executable file
base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output')
output_package_path = rf'C:\Dane\repo\python\Generator\_output'
output_file_path = os.path.join(output_package_path, f'{wf_ID.lower()}_IDA_Logiczny_Model_Danych_v1.0.xlsx')

# [os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.xls'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany



pk_dct = {}
for item in ida_pk:
	table_name = item['TABLE_NAME']
	column_name = item['COLUMN_NAME']
	if column_name.upper() not in ['EFFECTIVE_ST_DT', 'EFFECTIVE_END_DT', 'LOAD_ID', 'UPDATE_ID', 'SRC_SYS_ID', 'SYS_ID']:
		if table_name not in pk_dct:
			pk_dct[table_name] = [column_name]
		else:
			pk_dct[table_name].append(column_name)


# loop through workbooks
for src_wb_path, tmp_wb_path in zip(src_paths, tmp_wb_paths):

	# open STM workbook
	if src_wb_path is not None:
		src_wb = load_workbook(src_wb_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	tmp_wb = load_workbook(tmp_wb_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	
	# print(src_wb.sheetnames) # for development purpose only

	old_sheet_names = [string for string in src_wb.sheetnames if any((substr[1:6] in string) for substr in table_codes)]
	# ldm_sheet_names = [re.sub('T17', 'T420', src_sheet_name[0:6]) for src_sheet_name in old_sheet_names]  # input here sheet_names, table_names or table codes ('txxxxxx')
	ldm_sheet_names = [re.sub(f'T{src_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', src_sheet_name[0:6]) for src_sheet_name in old_sheet_names]  # input here sheet_names, table_names or table codes ('txxxxxx')
	# ldm_sheet_names = [re.sub('HIST P', 'HST P', ldm_sheet_name) if len(ldm_sheet_name) > 31 else ldm_sheet_name for ldm_sheet_name in ldm_sheet_names]  # rename if sheetname is longer than 31s


	tgt_table_names = [re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', old_sheet_name) for old_sheet_name in old_sheet_names]  # input here sheet_names, table_names or table codes ('txxxxxx')

	################################
	# LISTA TABEL
	row = 4
	for tgt_table in tgt_table_names:
		tmp_wb['Lista tabel'][f'B{row}'].value = f'=HYPERLINK("#{tgt_table[0:7]}!B1","{tgt_table}")'
		tmp_wb['Lista tabel'][f'C{row}'].value = 'Daniel Wiśniewski'
		tmp_wb['Lista tabel'][f'E{row}'].value = '1.0'
		tmp_wb['Lista tabel'][f'F{row}'].value = 'I'
		tmp_wb['Lista tabel'][f'G{row}'].value = 'Wersja inicjalna'
		row+=1


	# convert excel ranges into nested lists
	# header_main_dct = all_datasets_by_table_name(src_wb, old_sheet_names, table_name_pattern='Tabela docelowa', offset_header_rows=1, orientation='H')
	ldm_main_dct = all_datasets_by_table_name(src_wb, old_sheet_names, table_name_regex_pattern='^Lp$', offset_header_rows=0, orientation='H')


	# remove deleted rows with 'D' flag
	new_dct = {}
	for table_name, lst in ldm_main_dct.items():
		new_lst = []
		tech_num = 0
		for num, dct in enumerate(lst):
			if dct['Ostatnia zmiana'] != 'D':
				new_lst.append(dct)
		new_dct.setdefault(table_name, []).extend(new_lst)


 	# remove deleted rows with 'D' flag
	new_dct_2 = {}
	for table_name, lst in new_dct.items():
		new_lst = []
		tech_num = 0
		for num, dct in enumerate(lst):
			if dct['Nazwa kolumny'].upper() not in ['EFFECTIVE_ST_DT', 'EFFECTIVE_END_DT', 'LOAD_ID', 'UPDATE_ID', 'SRC_SYS_ID', 'SYS_ID']:
				new_lst.append(dct)
		new_dct_2.setdefault(table_name, []).extend(new_lst)
	
	# remove merged rows
	new_dct_3 = {}
	for table_name, lst in new_dct_2.items():
		new_lst = []
		tech_num = 0
		for num, dct in enumerate(lst):
			if dct['Nazwa kolumny'] != '':
				new_lst.append(dct)
		new_dct_3.setdefault(table_name, []).extend(new_lst)

	# enrich dictionary
	new_dct_4 = {}
	for src_sheet_name, (table_name, lst) in zip(old_sheet_names, new_dct_3.items()):
		new_lst = []
		tech_num = 0
		pk_num = 0
		for num, dct in enumerate(lst):
			if num == 0:
				ldm_pk_field[0]['Kolumna'] = f'{table_name[7:]}_KEY'
				new_lst.extend(deepcopy(ldm_pk_field))
				pk_num = len(ldm_pk_field)
				if 'SCD1' in src_wb[src_sheet_name]['C5'].value.upper():
					new_lst.extend(ldm_tech_fields_scd1_act)
					tech_num = len(ldm_tech_fields_scd1_act)
				elif 'SCD2' in src_wb[src_sheet_name]['C5'].value.upper():
					new_lst.extend(ldm_tech_fields_scd2)
					tech_num = len(ldm_tech_fields_scd2)
				elif 'fakt' in src_wb[src_sheet_name]['C5'].value.lower():
					new_lst.extend(ldm_tech_fields_fact)
					tech_num = len(ldm_tech_fields_fact)
				elif 'snapshot' in src_wb[src_sheet_name]['C5'].value.lower():
					new_lst.extend(ldm_tech_fields_snap_ovr)
					tech_num = len(ldm_tech_fields_snap_ovr)
				else:
					new_lst.extend(ldm_tech_fields_scd2)
					tech_num = len(ldm_tech_fields_scd2)
					print(f'WARNING! Nie rozpoznano typu tabeli dla tabeli: {table_name}. Przyjęto SCD2 jako domyślny typ tabeli.')

			if 'VARCHAR2' in dct['Typ danych']:
				data_type = re.sub('VARCHAR2', 'STRING', dct['Typ danych'])
				data_type = re.sub(' CHAR', '', data_type)
			elif 'VARSTRING' in dct['Typ danych']:
				data_type = re.sub('VARSTRING\(', 'STRING(', dct['Typ danych'])
			elif 'CHAR' in dct['Typ danych']:
				data_type = re.sub('CHAR\(', 'STRING(', dct['Typ danych'])
			elif 'NUMBER' in dct['Typ danych']:
				data_type = re.sub('NUMBER', 'NUMERIC', dct['Typ danych'])
			elif 'TIMESTAMP' in dct['Typ danych']:
				data_type = 'TIMESTAMP'
			elif dct['Typ danych'] == 'INTEGER':
				data_type = 'INT64'
			else:
				data_type = dct['Typ danych']

			# natural key
			if table_name in pk_dct.keys():
				if dct['Nazwa kolumny'].upper() in pk_dct[table_name]:
					natural_key = 'T'
			else:
				natural_key = ''

			elem = {'#': num + pk_num + tech_num + 1, 'Kolumna': dct['Nazwa kolumny'].upper(), 'Typ': data_type, 'Primary Key': '', 'Not Null': f"{'T' if dct['Not Null'] == 'N' else ''}", 'Natural Key': natural_key, 'Foreign Key': '', 'FK - Tabela referencyjna': '', 'Opis biznesowy': '', 'Dane wrażliwe': '', 'Release': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
			# elem = {'#': num + pk_num + tech_num + 1, 'Kolumna': dct['Nazwa kolumny'].upper(), 'Typ': data_type, 'Primary Key': f"{'T' if num == 0 else ''}", 'Not Null': f"{'T' if dct['Not Null'] == 'N' else ''}", 'Natural Key': '', 'Foreign Key': '', 'FK - Tabela referencyjna': '', 'Opis biznesowy': '', 'Dane wrażliwe': '', 'Release': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
			new_lst.append(elem)

		new_dct_4.setdefault(table_name, []).extend(new_lst)


	for src_sheet_name, ldm_sheet_name in zip(old_sheet_names, ldm_sheet_names):
		# row_num = dict_to_range(header_main_dct[src_sheet_name], tmp_wb[ldm_sheet_name], start_cell='B4', table_name='test', orientation='V')
		ldm_sheet_name = copy_and_move_sheet(tmp_wb, 'tmp', ldm_sheet_name, dest_pos=None)

		# set zoom
		tmp_wb[ldm_sheet_name].sheet_view.zoomScale = 85

		tmp_wb[ldm_sheet_name]['C6'].value = re.sub('T17', 'T420', src_wb[src_sheet_name]['C3'].value)
		tmp_wb[ldm_sheet_name]['C7'].value = ''
		tmp_wb[ldm_sheet_name]['C8'].value = tgt_schema_name
		tmp_wb[ldm_sheet_name]['C9'].value = tgt_schema_name

		if 'SCD1' in src_wb[src_sheet_name]['C5'].value.upper():
			table_type = 'Brak historyzacji (SCD1) przez nadpisanie'
		elif 'SCD2' in src_wb[src_sheet_name]['C5'].value.upper():
			table_type = 'Historyzacja datami od - do (SCD2)'
		elif 'fakt' in src_wb[src_sheet_name]['C5'].value.lower():
			table_type = 'Dopisanie faktów za dowolną datę biznesową'
		elif 'snapshot' in src_wb[src_sheet_name]['C5'].value.lower():
			table_type = 'Snapshot - stan danych na datę'
		else:
			table_type = 'Historyzacja datami od - do (SCD2)'


		tmp_wb[ldm_sheet_name]['C11'].value = table_type

		row_num = dict_to_range(new_dct_4[src_sheet_name], tmp_wb[ldm_sheet_name], start_cell='B15', table_name=None, orientation='H', formatting_type='LDM')

	# remove tmp sheet
	del tmp_wb['tmp']

	# save workbook
	tmp_wb.save(output_file_path)  # jeżeli błąd to zainstalować starszą wersję: pip install openpyxl-2.6.2
	
	# open file
	os.system(output_file_path) # development purpose only

