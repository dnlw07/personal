import sys    
import os    

from openpyxl import load_workbook, Workbook
from openpyxl.utils import get_column_letter as letter # convert number to letter
from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
from datetime import datetime
import re # regex
import numpy as np
import subprocess
from pprint import pprint
# import pyperclip
# import os # manipulacje ścieżkami
# from shutil import copy
# from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
# from copy import deepcopy


#################################################################
# pandas functions
#################################################################
def get_filtered_values_list(df, out_column_name, filter):
	"""Returns list with filtered values for chosen output column

	Args:
		`df (dataframe)`: dataframe
		`out_column_name (_type_)`: output column name
		`filter (_type_)`: filtering condition

	Returns:
		`lst`: list with filtered values for chosen column
	"""
	result_lst = np.where(filter, df[out_column_name], '')
	result_lst = [elem for elem in result_lst if elem] 	# removes empty strings from list
	return result_lst


def generate_insert_sripts(dct, target_schema, target_table):
	# generate SQL INSERT INTO scripts based on the nested dictionary list
	insert_scripts = []
	for row in dct:
		columns = ", ".join(row.keys())
		values = ", ".join([f"'{str(val)}'" if val is not None and val != '' else 'null' for val in row.values()])
		insert_script = f'INSERT INTO {target_schema}.{target_table} ({columns}) VALUES ({values});' if target_schema is not None else f'INSERT INTO {target_table} ({columns}) VALUES ({values});'
		insert_scripts.append(insert_script)
	insert_scripts_txt = '\n'.join(insert_scripts)
	insert_scripts_txt += '\n'
	return insert_scripts_txt


#################################################################
# read Excel
#################################################################

# rozbija adres komórki na literę kolumny oraz number wiersza
def split_cell_address(cell):
	"""Rozbija adres komórki na literę kolumny oraz number wiersza

	Args:
		`cell (str)`: adres komórki

	Returns:
		`str`, `int`: zwraca dwie zmienne - litera kolumny oraz numer wiersza rozdzielone przecinkiem
	"""
	col = re.findall('[A-Z]+', cell, re.I)[0]
	row = int(re.findall('\d+|:', cell, re.I)[0])
	return col, row


def check_if_cell_is_merged(sheet_obj, col, row):
	"""Verify if excel cell is merged or not.

	Args:
		sheet_obj (class): workbook sheet object (`ex. wb[sheet_name]`)
		col (int): column number (ex. number(col))
		row (int): row number

	Returns:
		boolean: True if cell is merged or False when cell is not merged.
	"""
	
	cell = sheet_obj.cell(row=row, column=col)
	for merged_cell in sheet_obj.merged_cells.ranges:
		if (cell.coordinate in merged_cell):
			return True
	return False


# zwraca adres komórki lub listę adresów komórek dla wybranego słowa
def find_cell_addres_by_value(sheet_obj, regex_phrase, partial_match=False, all_results=False):
	"""Zwraca adres komórki zawierącej formatiowanie `Bold` oraz `Italic`.\n
	
	Args:\n
		`sheet`: obiekt np. workbook('sheet_name')\n
		`regex_phrase`: regex pattern (bez '.*' na początku oraz na końcu)\n
		`partial_match`: flaga oznaczająca ma szukać substringa czy całego wyrażenia w komurce\n
		`all_results`: flaga oznaczająca czy zwracać pierwszy znalezioną nazwę czy wszystkie nazwy\n
	"""
	found_lst = []
	for row in sheet_obj.rows:
		for cell in row:
			cell_value = str(cell.value) if cell.value is not None else ''
			cell_address = cell.coordinate
			if partial_match:
				if re.search('.*'+ regex_phrase +'.*', cell_value): 
					found_lst.append(cell_address)
			else:
				if cell_value == regex_phrase:
					found_lst.append(cell_address)
			if not all_results and len(found_lst) > 0:
				break
		if not all_results and len(found_lst) > 0:
			break

	if all_results and len(found_lst) > 0:
		return found_lst
	elif not all_results and len(found_lst) > 0:
		return [found_lst[0]]
	else:
		print('ERROR: Cell value not found')
		return None


def find_cell_addres_by_formatting(sheet_obj, all_results=False):
	"""Zwraca adres komórki zawierącej formatiowanie `Bold` oraz `Italic`.\n

	Args:\n
		`sheet_obj`: obiekt np. workbook('sheet_name')\n
		`all_results`: flaga oznaczająca czy zwracać pierwszy znalezioną nazwę czy wszystkie nazwy\n
	"""
	found_lst = []
	for row in sheet_obj.rows:
		for cell in row:
			if cell.font.b and cell.font.i: # HARDCODED! Check if cell is BOLD and is ITALIC
				found_lst.append(cell.coordinate)

	if all_results and len(found_lst) > 0:
		return found_lst
	elif not all_results and len(found_lst) > 0:
		return found_lst[0]
	else:
		return None


def table_orietation(sheet_obj, start_cell, offset_header_rows=0):
	"""Wykrywa orientację tabeli zależnie od formatowania nagłówka.\n
	Funkcja zaklada, że format nagłóweka jest `Bold`. Funkcja sprawdza czy pogrubiona jest komórka po prawje stronie czy na dole i na tej podstawie wyznacza orientację tabeli.\n
	Funkcja nie zadziała poprawnie jeżeli wartości tabeli są również pogrubione.

	Args:
		`sheet_obj` (class): workbook sheet object (`ex. wb[sheet_name]`)
		`start_cell` (str): Adres pierwszej komórki nagówka w tabeli.
		`offset_header_rows` (int, optional): Wskazuje ile rzędów pod nazwą tabeli znajduje się nagłówek. Defaults to 0.

	Returns:
		`str`: Zależenie od orientacji zwraca literę 'H' jeżeli nagłowek tabeli jest poziomo lub 'V' jeżeli nagłówek tabeli jest pionowo
	"""

	start_col, start_row = split_cell_address(start_cell)
	start_row = start_row + offset_header_rows

	cell_right = sheet_obj[f'{letter(number(start_col) + 1)}{start_row}'] # orientacja pozioma
	cell_down = sheet_obj[f'{start_col}{start_row + 1}'] # orientacja pionowa
	
	if cell_right.font.b and cell_right.value is not None:
		return 'H'
	elif cell_down.font.b and cell_down.value is not None:
		return 'V'
	elif cell_down.value is None and (not cell_right.font.b and cell_right is not None):
		return 'V'
	elif cell_right.value is None and (not cell_down.font.b and cell_down.value is not None):
		return 'H'
	else:
		print('Could not infer proper table orientation.')
		raise ValueError
		# return 'H'



# zwraca rzeczywysty adres ostatniej używanej komórki w akruszu
def sheet_last_cell_address(sheet_obj):
	"""Zwraca RZECZYWISTY adres ostatniej używanej komórki w arkuszu

	Args:
		`sheet_obj (class)`: workbook sheet object (`ex. wb[sheet_name]`)

	Returns:
		`str`: zwraca adres ostatniej używanej komórki w arkuszu
	"""

	end_row = sheet_obj.max_row
	end_col = sheet_obj.max_column

	# wyznacza ostatni rząd
	row = end_row
	entire_row_lst = [cell.value for cell in sheet_obj[end_row]]
	while len(set(entire_row_lst)) == 1 and None in set(entire_row_lst):
		row = row - 1
		entire_row_lst = [cell.value for cell in sheet_obj[row]]
	row = row - 1

	# wyznacza ostatnią kolumnę
	col = end_col
	entire_row_lst = [cell.value for cell in sheet_obj[letter(end_col)]]
	while len(set(entire_row_lst)) == 1 and 'None' in set(entire_row_lst):
		col = col - 1
		entire_row_lst = [cell.value for cell in sheet_obj[letter(col)]]
	end_col = letter(col - 1)

	return f'{end_col}{end_row}'


# zwraca adres ostniej komórki tabeli
def table_last_cell(sheet_obj, orientation, start_cell, offset_header_rows=None, max_row_num=None, max_col_num=None):
	"""Zwraca adres ostatniej używanej komórki w tabeli

	Args:
		`sheet_obj (class)`: workbook sheet object (`ex. wb[sheet_name]`)
		`orientation (str)`: _description_
		`start_cell (str)`: _description_
		`offset_header_rows (int, optional)`: Wskazuje ile rzędów pod nazwą tabeli znajduje się nagłówek. Defaults to None.
		`max_row_num (str, optional)`: Wskazuje maksymalną liczbę rzędów do wczytania
		`max_col_num (str, optional)`: Wskazuje maksymalną liczbę kolumn do wczytania


	Returns:
		`str`: Adres ostatniej używanej komórki w tabeli.
	"""

	start_col, start_row = split_cell_address(start_cell)
	header_start_col = start_col
	header_start_row_num = start_row + offset_header_rows

	if orientation.upper() == 'H': # pozioma orientacja nagłówka tabeli
		flg_cell_is_merged = check_if_cell_is_merged(sheet_obj, col=number(header_start_col), row=header_start_row_num)
		col_num = number(start_col)
		row_num = header_start_row_num

		# wyznacza ostatnią kolumnę nagłówka
		if max_col_num is None:
			while sheet_obj[f'{letter(col_num)}{header_start_row_num}'].value is not None or flg_cell_is_merged:
				col_num = col_num + 1
				flg_cell_is_merged = check_if_cell_is_merged(sheet_obj, col=col_num, row=header_start_row_num)
			end_col_num = col_num - 1
		else:
			end_col_num = col_num + max_col_num

		# wyznacza ostatni rząd danych tabeli
		if max_row_num is None:
			entire_row_lst = ['D','U','M','M','Y']
			flg_cell_is_merged = check_if_cell_is_merged(sheet_obj, col=number(header_start_col), row=header_start_row_num)
			while not (len(set(entire_row_lst)) == 1 and 'None' in set(entire_row_lst)) or flg_cell_is_merged:
				row_num = row_num + 1
				# iteruje przez całą kolumnę a nie tylko po pierwszym rzędzie - dzięki temu zabezpieczamy się na wypadek, gdy w pierwszej kolumnie będą występować null'e
				entire_row_lst = [str(sheet_obj[f'{letter(col_num)}{row_num}'].value) for col_num in range(number(header_start_col), end_col_num + 1)] 
				flg_cell_is_merged = check_if_cell_is_merged(sheet_obj, col=number(header_start_col), row=row_num)
			end_row_num = row_num - 1
		else:
			end_row_num = row_num + max_row_num

	elif orientation.upper() == 'V': # pionowa orientacja nagłówka tabeli
		row_num = start_row
		col_num = number(header_start_col)

		# wyznacza ostatnią rząd nagłówka
		if max_row_num is None:
			while sheet_obj[f'{header_start_col}{row_num}'].value is not None or flg_cell_is_merged:
				row_num = row_num + 1
				flg_cell_is_merged = check_if_cell_is_merged(sheet_obj, col=number(header_start_col), row=row_num)
			end_row_num = row_num - 1
		else:
			end_row_num = row_num + max_row_num

		# wyznacza ostatnią kolumnę danych tabeli
		entire_col_lst = ['D','U','M','M','Y']
		if max_col_num is None:
			while not (len(set(entire_col_lst)) == 1 and 'None' in set(entire_col_lst)) or flg_cell_is_merged: # jeżeli infinite loop to sam nagłówek bez tabeli w excelu
				col_num = col_num + 1
				# iteruje przez całą kolumnę a nie tylko po pierwszym rzędzie - dzięki temu zabezpieczamy się na wypadek, gdy w pierwszej kolumnie będą występować null'e
				entire_col_lst = [str(sheet_obj[f'{letter(col_num)}{row_num}'].value) for row_num in range(header_start_row_num, end_row_num + 1)]
				flg_cell_is_merged = check_if_cell_is_merged(sheet_obj, col=col_num, row=header_start_row_num)
			end_col_num = col_num - 1
		else:
			end_col_num = col_num + max_col_num

	return f'{letter(end_col_num)}{end_row_num}'


# def infer_excel_table_range(sheet_obj, table_name_cell, end_cell=None, offset_header_rows=1):
def infer_excel_table_range(sheet_obj, table_name_pattern, offset_header_rows=1, orientation=None, all_results=False, max_row_num=None, max_col_num=None):
	"""Zwraca zakres tabeli bazując na podanej nazwie tabeli.

	Args:
		`sheet_obj (class)`: workbook sheet object (`ex. wb[sheet_name]`)
		`table_name_pattern (str)`: Nazwa tabeli lub jej fragment.
		`offset_header_rows (int, optional)`: Wskazuje ile rzędów pod nazwą tabeli znajduje się nagłówek. Defaults to 1.
		`all_results (bool, optional)`: Flaga wskazująca czy ma zwracać jedynie pierwszy wynik czy wszystkie znalezione wyniki wyszukiwania. Defaults to False.
		`orientation (str, optional)`: Wskazuje orientację tabeli - H (pozioma) lub V (pionowa)
		`max_row_num (str, optional)`: Wskazuje maksymalną liczbę rzędów do wczytania
		`max_col_num (str, optional)`: Wskazuje maksymalną liczbę kolumn do wczytania


	Returns:
		`str`: Zakres komórek jakich znajduje się szukana tabela.
	"""
	
	table_name_cells = find_cell_addres_by_value(sheet_obj, regex_phrase=table_name_pattern, partial_match=True, all_results=False)

	table_ranges = []
	for table_name_cell in table_name_cells:
		if orientation is None:
			orientation = table_orietation(sheet_obj, table_name_cell, offset_header_rows)

		# find first header cell addres
		start_col, start_row = split_cell_address(table_name_cell)
		header_start_row = start_row + offset_header_rows
		header_col = start_col
		start_cell = f'{header_col}{header_start_row}' # pierwsza komórka nagłówka tabeli (zwiera nazwę pierwszej kolumy tabeli)

		# wskazuje adres ostatniej komórki tabeli
		end_cell = table_last_cell(sheet_obj, orientation, table_name_cell, offset_header_rows, max_row_num=max_row_num, max_col_num=max_col_num)

		table_ranges.append(f'{start_cell}:{end_cell}')

	if all_results:
		return table_ranges
	else:
		return table_ranges[0], orientation


# kowerntuje range do listy zawierającej słowniki
def range_to_dataset_by_address(sheet_obj, table_range, orientation=None, xml_tag=None):
	"""Konwertuje wskazany zakres komórek na listę słowników.

	Args:
		`sheet_obj (class)`: Workbook sheet object (ex. `wb[sheet_name]`).
		`table_range (str)`: Zakres komórek wskazujący tabelę w Exelu.
		`orientation (str, optional)`: Wskazuje orientację tabeli - H (pozioma) lub V (pionowa)
		`xml_tag (str, optional)`: Jeżeli funkcja ma wygenerować słownik, który bedzie konwertowany na xml'a, to @ oznacza, że atrybut będzie znajdować się wewnątrz taga (np. `<element attribut="value">` zamiast `<element><attribute="value"></element>`). Defaults to None.

	Returns:
		`lst`: Zwraca listę słowników
	"""
	start_cell, end_cell = table_range.split(':')
	start_col, start_row = split_cell_address(start_cell)
	end_col, end_row = split_cell_address(end_cell)

	if orientation is None: 
		orientation = table_orietation(sheet_obj, start_cell)

	xml_tag = '@' if xml_tag is not None else ''

	if orientation.upper() == 'H': # pozioma orientacja tabeli
		first_data_col, first_data_row = (letter(number(start_col)), start_row + 1)
		dataset = []
		dct = dict()
		for row in range(first_data_row, end_row + 1):
			column_names = []
			for col in range(number(start_col), number(end_col) + 1):
				key = str(sheet_obj[f'{letter(col)}{start_row}'].value)
				val = str(sheet_obj[f'{letter(col)}{row}'].value) 
				val = val if val != 'None' else '' # konweruje string o wartości 'None' na pusty string

				# jeżeli kolumny w tabeli nazwyają się tak samo to zmienia nazwę
				column_name = xml_tag + key
				if column_name in column_names:
					column_name = f'{column_name}_2'
				column_names.append(column_name)

				dct[column_name] = val # @ - oznacza, że atrybuty jest znajdują się wewnątrz taga
			dataset.append(dct)
			dct = dict() # czyści tymczasowy słownik przed kolejną iteracją

	elif orientation.upper() == 'V': # pionowa orientacja tabeli
		first_data_col, first_data_row = (letter(number(start_col) + 1), start_row)
		dataset = []
		dct = dict()
		for col in range(number(first_data_col), number(end_col) + 1):
			for row in range(start_row, end_row + 1):
				key = str(sheet_obj[f'{start_col}{row}'].value)
				val = str(sheet_obj[f'{letter(col)}{row}'].value)
				val = val if val != 'None' else '' # konweruje string o wartości 'None' na pusty string
				
				# jeżeli kolumny w tabeli nazwyają się tak samo to zmienia nazwę
				column_name = xml_tag + key
				if column_name in column_names:
					column_name = f'{column_name}_2'
				column_names.append(column_name)

				dct[column_name] = val # @ - oznacza, że atrybuty jest znajdują się wewnątrz taga
			dataset.append(dct)
			dct = dict() # czyści tymczasowy słownik przed kolejną iteracją
	return dataset, orientation


def range_to_dataset_by_table_name(sheet_obj, table_name_pattern, offset_header_rows=1, orientation=None, max_row_num=None, max_col_num=None):
	"""Szuka tabel we wskazanych arkuszach w workbook'u po wskazanym fragmencie nazwy tabeli oraz zwraca słownik ze wszystkimi znalezionymi tabeliami posortowanymi po nazwach arkusza.

	Args:
		`sheet_obj (class)`: Workbook sheet object (`ex. wb[sheet_name]`).
		`table_name_pattern (str)`: Nazwa tabeli lub jej fragment.
		`offset_header_rows (int, optional)`: Wskazuje ile rzędów pod nazwą tabeli znajduje się nagłówek. Defaults to 1.
		`orientation (str, optional)`: Wskazuje orientację tabeli - H (pozioma) lub V (pionowa)
		`max_row_num (str, optional)`: Wskazuje maksymalną liczbę rzędów do wczytania
		`max_col_num (str, optional)`: Wskazuje maksymalną liczbę kolumn do wczytania


	Returns:
		`dict`: Zwraca słownik ze wszystkimi znalezionymi tabeliami posortowanymi po nazwach arkusza
	"""

	table_range, orientation = infer_excel_table_range(sheet_obj, table_name_pattern, offset_header_rows=offset_header_rows, orientation=orientation, max_row_num=max_row_num, max_col_num=max_col_num)
	row_lst, orientation = range_to_dataset_by_address(sheet_obj, table_range, orientation=orientation)
	return row_lst, orientation



def all_datasets_by_table_name(wb, sheet_names, table_name_regex_pattern, offset_header_rows=1, orientation=None, max_row_num=None, max_col_num=None):
	"""Szuka tabel we wskazanych arkuszach w workbook'u po wskazanym fragmencie nazwy tabeli oraz zwraca słownik ze wszystkimi znalezionymi tabelami posortowanymi po nazwach arkusza.

	Args:
		`wb (object)`: excel workbook object.
		`sheet_names (lst)`: list of sheets in excel.
		`table_name_regex_pattern (str)`: Regex pattern. Nazwa tabeli lub jej fragment.
		`offset_header_rows (int, optional)`: Wskazuje ile rzędów pod nazwą tabeli znajduje się nagłówek. Defaults to 1.
		`orientation (str, optional)`: Wskazuje orientację tabeli - H (pozioma) lub V (pionowa)
		`max_row_num (str, optional)`: Wskazuje maksymalną liczbę rzędów do wczytania
		`max_col_num (str, optional)`: Wskazuje maksymalną liczbę kolumn do wczytania

	Returns:
		`dict`: Zwraca słownik ze wszystkimi znalezionymi tabelami posortowanymi po nazwach arkusza
	"""

	wb_dct = {}
	wb_lst = []
	for sheet_name in sheet_names:
		found_lst = find_cell_addres_by_value(wb[sheet_name], regex_phrase=table_name_regex_pattern, partial_match=True, all_results=True)
		for cell_address in found_lst:
			# table_name = wb[sheet_name]['C4'].value
			table_name = wb[sheet_name][cell_address].value
			dataset, orientation = range_to_dataset_by_table_name(wb[sheet_name], table_name_regex_pattern, offset_header_rows=offset_header_rows, orientation=orientation, max_row_num=max_row_num, max_col_num=max_col_num)
			# wb_dct.setdefault(sheet_name, {}).setdefault(table_name, dataset)
			wb_dct.setdefault(sheet_name, dataset)
	return wb_dct




#################################################################
# Excel manipulation
#################################################################

def move_sheet(wb, sheet_obj, dest_pos=None):
	sheet_list = []
	sheet_list = wb.sheetnames
	start_pos = wb.index(sheet_obj)
	lst = []
	if dest_pos is None: # jeżeli None to ostatnia pozycja
		dest_pos = (len(sheet_list) - 1)
	for x in range(len(sheet_list)):
		if x > (dest_pos - 1) and x != dest_pos:
			lst.append(x-1)
		elif x == dest_pos:
			lst.append(start_pos)
		else:
			lst.append(x)
	wb._sheets = [wb._sheets[i] for i in lst]


def insert_delete_rows(lst, sheet_obj, current_table_name, next_table_name=None):
	"""
	Description:
	\tWstawia lub usuwa wiersze pomiędzy tabelami.\n
	\tWstawia puste wiersze za tabelą jeżeli rekordy aktualnej tabeli pokryją rekordy z tabeli poniżej, bądź usuwa rekordy jeżeli tabela w szablonie jest większa od wstawianej.\n\n
	Args:
	\t`sheet_obj`: obj (np. output_xls['mapping'])\n
	\t`current_table_name`: str string (np. 'CONNECTOR_MANUAL')\n
	\t`next_table_name`: str (np. 'MAPPINGVARIABLE') - pole opcjonalne, jeżeli None to jedynie usuwa zbędne rekordy \n
	\t`returns`: cell_address - adres komórki do której zostanie wsatwiona tabela
	"""
	cell_address_curr = find_cell_addres_by_value(sheet_obj, current_table_name)
	cell_col_curr, cell_row_curr = split_cell_address(cell_address_curr)
	if next_table_name is not None:
		cell_address_next = find_cell_addres_by_value(sheet_obj, next_table_name)
		cell_col, cell_row_next = split_cell_address(cell_address_next)
		row_diff = cell_row_next - cell_row_curr - len(lst) - 3 - 2
		if row_diff < 0: # wstawia puste rzędy, w przypadku gdy tabele się miałyby się pokrywać
			sheet_obj.insert_rows(cell_row_next, amount=abs(row_diff))
			cell_address = find_cell_addres_by_value(sheet_obj, current_table_name)
		elif row_diff > 0: # usuwa rzędy, aby nie zostały rekordy tabeli templatki
			sheet_obj.delete_rows(cell_row_curr + 1, amount=abs(row_diff)) # +1 aby nie usuwało tytułu tabeli
	else:
		# zlicza ilość rekordów w tabeli
		cell_row = cell_row_curr
		while (sheet_obj[f'{cell_col_curr}{cell_row}'].value is not None):
			cell_row += 1
		cell_row_curr_end = cell_row
		row_diff = (cell_row_curr_end - cell_row_curr - 2) - len(lst) # -2 uwzględnia tytuł oraz nagłówek tabeli
		if row_diff > 0:
			sheet_obj.delete_rows(cell_row_curr + 1, amount=abs(row_diff))
	return cell_address_curr


def update_table_value(sheet_obj, search_table_title, dct):
	"""
	Description: 
	\tAktualizuje wartość w tabeli dla wskazanej nazwy kolumny\n\n
	Args:
	\t`sheet_obj`: obj\n
	\t`search_table_title`: str - table title\n
	\t`dct`: dict - (input_column_name: input_value_name, target_column_name: replace_value)
	"""
	key_lst = [key for key in dct.keys()]
	search_col = key_lst[0]
	search_value = dct[search_col]
	target_col = key_lst[1]
	new_value = dct[target_col]

	# wyszukję nazwę tabeli
	table_title_address = find_cell_addres_by_value(sheet_obj, search_table_title)
	cell_col, cell_row = split_cell_address(table_title_address)
	header_row = cell_row + 1

	# wyszukuje adres kolumny
	while (sheet_obj[f'{cell_col}{header_row}'].value != search_col):
		cell_col = letter(number(cell_col) + 1)
		if sheet_obj[f'{cell_col}{header_row}'].value is None:
			print('Brak wskazanej kolumny w tabeli!')
			raise ValueError
			break
	cell_col_search = cell_col

	# wartość we docelowej kolumnie
	while (sheet_obj[f'{cell_col_search}{cell_row}'].value != search_value):
		cell_row += 1
		if sheet_obj[f'{cell_col_search}{cell_row}'].value is None:
			print('Brak wskazanej warości do wyszukania w kolumnie tabeli!')
			raise ValueError
			break
	cell_row_search = cell_row

	# wyszukuje adres kolumny docelowej
	while (sheet_obj[f'{cell_col}{header_row}'].value != target_col):
		cell_col = letter(number(cell_col) + 1)
		if sheet_obj[f'{cell_col}{header_row}'].value is None:
			print('Brak wskazanej kolumny w tabeli!')
			raise ValueError
			break
	cell_col_target = cell_col

	sheet_obj[f'{cell_col_target}{cell_row_search}'].value = new_value



def dict_to_range(lst, sheet, start_cell, table_name=None, orientation='V', formatting_type=None): # h - horizontal, v - vertical
	if lst is not None: 
		if isinstance(lst, dict): lst = [lst] # jeżeli na jeściu jest słownik wrzuca go w listę

		start_col, start_row = split_cell_address(start_cell)

		# text formatting
		no_bold = Font(bold=False)
		bold = Font(bold=True)
		bold_italic = Font(bold=True, italic=True)
		no_bold_italic = Font(bold=False, italic=False)
		italic = Font(italic=True)
		no_italic = Font(italic=False)

		# font color
		font_white = Font(color='ffffff')
		font_black = Font(color='000000')

		font_white_bold = Font(bold=True, color='ffffff')
		font_black_bold = Font(bold=True, color='000000')

		# text align
		center = Alignment(horizontal='center')
		left = Alignment(horizontal='left')

		no_fill = PatternFill(fill_type=None)
		fill_light_grey = PatternFill(fill_type='solid', fgColor='f2f2f2')

		# STM color set
		fill_stm_dark_grey = PatternFill(fill_type='solid', fgColor='595959')
		fill_stm_light_green = PatternFill(fill_type='solid', fgColor='0f9575')
		fill_stm_dark_green = PatternFill(fill_type='solid', fgColor='0b6f56')
		fill_stm_light_blue = PatternFill(fill_type='solid', fgColor='03a1af')
		fill_stm_dark_blue = PatternFill(fill_type='solid', fgColor='027a84')

		borders = Border(left=Side(border_style='thin', color='808080'),
						right=Side(border_style='thin', color='808080'), 
						top=Side(border_style='thin', color='808080'),
						bottom=Side(border_style='thin', color='808080'))

		# Wstawia nazwę tabeli
		if len(lst) > 0: # jeżeli tabela NIE jest pusta
			if table_name is not None:
				sheet[start_cell].value = table_name
				# sheet[start_cell].font = bold_italic
				sheet[start_cell].font = Font(bold=True, size=12)
				start_row = start_row + 1

			if orientation.upper() == 'V':
				col_num, row = number(start_col), start_row
				# header (first row)
				for cell_value in lst[0].keys():
					cell = sheet[f'{start_col}{row}']
					# cell.value, cell.border, cell.fill, cell.font = (cell_value, borders, fill, bold)
					cell.value, cell.border = (cell_value, borders)
					row = row + 1
				# data - (from second row)
				col_num, row = (number(start_col) + 1, start_row)
				for dct in lst:
					for key, val in dct.items():
						cell = sheet[f'{letter(col_num)}{row}']
						# cell.value, cell.border, cell.fill, cell.font = (val, borders, no_fill, no_bold)
						cell.value, cell.border = (val, borders)
						row = row + 1
					col_num = col_num + 1

			elif orientation.upper() == 'H':
				# header
				col, row = number(start_col), start_row
				for cell_value in lst[0].keys():
					cell = sheet[f'{letter(col)}{row}']
					
					if formatting_type is None:
						# cell.value = cell_value
						pass
					
					elif formatting_type == 'Basic':
						cell.value, cell.border, cell.fill, cell.font = (cell_value, borders, fill_light_grey, bold)
					
					##########################################################################################################################
					# CUSTOM FORMATTING
					elif formatting_type == 'LDM':
						cell.value, cell.border, cell.fill, cell.font = (cell_value, borders, fill_stm_dark_blue, font_white_bold)
					
					elif formatting_type == 'STM_main_header':
						try:
							cell.value = cell_value
						except:
							pass
						if cell_value in ['CEL', '1', '2', '3']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_light_green, center, font_white_bold)
						elif cell_value in ['ŹRÓDŁO', '4', '5', '6', '7', '8', '9']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_light_blue, center, font_white_bold)
						sheet.merge_cells(start_row=row, start_column=2, end_row=row, end_column=5)
						sheet.merge_cells(start_row=row, start_column=6, end_row=row, end_column=12)

					elif formatting_type == 'STM_main':
						try:
							cell.value = cell_value
						except:
							pass
						if cell_value in ['Wersja', 'Zmiana', 'Komentarze do zmiany']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_grey, center, font_white_bold)
						elif cell_value in ['Wersja', 'Zmiana', 'Komentarze do zmiany']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_green, center, font_white_bold)
						else:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_blue, center, font_white_bold)

						sheet.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)
						sheet.merge_cells(start_row=row, start_column=9, end_row=row, end_column=10)

					elif formatting_type == 'STM_src_areas':
						try:
							cell.value = cell_value
						except:
							pass
						if cell_value in ['Wersja', 'Zmiana', 'Komentarze do zmiany']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_grey, center, font_white_bold)
						else:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_blue, center, font_white_bold)
						
						sheet.merge_cells(start_row=row, start_column=2, end_row=row, end_column=3)

					elif formatting_type == 'STM_src_tables':
						try:
							cell.value = cell_value
						except:
							pass
						if cell_value in ['Wersja', 'Zmiana', 'Komentarze do zmiany']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_grey, center, font_white_bold)
						else:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_blue, center, font_white_bold)
						sheet.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)

					elif formatting_type == 'STM_src_definition':
						try:
							cell.value = cell_value
						except:
							pass
						if cell_value in ['Wersja', 'Zmiana', 'Komentarze do zmiany']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_grey, center, font_white_bold)
						else:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_blue, center, font_white_bold)
					
					elif formatting_type == 'STM_parameters':
						try:
							cell.value = cell_value
						except:
							pass
						if cell_value in ['Wersja', 'Zmiana', 'Komentarze do zmiany']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_grey, center, font_white_bold)
						else:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_blue, center, font_white_bold)
						sheet.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)
					
					elif formatting_type == 'STM_validation':
						try:
							cell.value = cell_value
						except:
							pass
						if cell_value in ['Wersja', 'Zmiana', 'Komentarze do zmiany']:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_grey, center, font_white_bold)
						else:
							cell.border, cell.fill, cell.alignment, cell.font = (borders, fill_stm_dark_blue, center, font_white_bold)
					##########################################################################################################################

					col = col + 1

				# data
				row = start_row + 1
				for dct in lst:
					col = number(start_col)
					for key, val in dct.items():
						cell = sheet[f'{letter(col)}{row}']

						if formatting_type is None:
							cell.value, cell.border = (val, borders)
						
						elif formatting_type == 'Basic':
							cell.value, cell.border, cell.fill, cell.font = (val, borders, no_fill, no_bold)
							cell.value, cell.border = (val, borders)
						
						##########################################################################################################################
						# CUSTOM FORMATTING
						# file_name =  os.path.basename(sys.argv[0])

						# formatting for LDM only
						elif formatting_type == 'LDM':
							if letter(col) in ['E', 'F', 'G', 'N', 'O']:
								cell.value, cell.border, cell.alignment = (val, borders, center)
							else:
								cell.value, cell.border, cell.alignment = (val, borders, left)

							if cell.value in ['SYS_CD', 'TECH_IS_ACTIVE_FLG', 'TECH_ACTUAL_END_DT', 'TECH_ETL_PKG_CD', 'TECH_INSERT_ID', 'TECH_UPDATE_ID', 'TECH_INSERT_TS', 'TECH_UPDATE_TS', 'TECH_CLOSE_ID', 'TECH_CLOSE_TS', 'START_DT', 'END_DT', 'DUE_DT', 'TECH_INSERT_TS']:
								for col_1 in range(2,17):
									cell_1 = sheet[f'{letter(col_1)}{row}']
									cell_1.border, cell_1.fill = (borders, fill_light_grey)

						elif formatting_type == 'STM_src_areas':
							try:
								cell.value = val
							except:
								pass
							if letter(col) in ['E', 'F']:
								cell.border, cell.alignment = (borders, center)
							else:
								cell.border, cell.alignment = (borders, left)
							
							sheet.merge_cells(start_row=row, start_column=2, end_row=row, end_column=3)

						elif formatting_type == 'STM_src_tables':
							try:
								cell.value = val
							except:
								pass
							if letter(col) in ['G', 'H']:
								cell.border, cell.alignment = (borders, center)
							else:
								cell.border, cell.alignment = (borders, left)
							
							sheet.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)

						elif formatting_type == 'STM_src_definition':	
							if letter(col) in ['F', 'G', 'M', 'N']:
								cell.value, cell.border, cell.alignment = (val, borders, center)
							else:
								cell.value, cell.border, cell.alignment = (val, borders, left)
							
							if val == 'n/a':
								cell.fill = fill_light_grey
								cell.alignment = Alignment(horizontal='center')

							if 'AND EXTRACT_VERSION' in val:
								cell.alignment = Alignment(wrap_text=True)
						
						elif formatting_type == 'STM_main':
							try:
								cell.value = val
							except:
								pass
							if letter(col) in ['B', 'C', 'F', 'G', 'M', 'N']:
								cell.border, cell.alignment = (borders, center)
							else:
								cell.border, cell.alignment = (borders, left)

							if cell.value in ['SYS_CD', 'TECH_IS_ACTIVE_FLG', 'TECH_ACTUAL_END_DT', 'TECH_ETL_PKG_CD', 'TECH_INSERT_ID', 'TECH_UPDATE_ID', 'TECH_INSERT_TS', 'TECH_UPDATE_TS', 'TECH_CLOSE_ID', 'TECH_CLOSE_TS', 'START_DT', 'END_DT', 'DUE_DT', 'TECH_INSERT_TS']:
								for col_1 in range(2,16,1):
									cell_1 = sheet[f'{letter(col_1)}{row}']
									cell_1.border, cell_1.fill = (borders, fill_light_grey)

						elif formatting_type == 'STM_parameters':	
							try:
								cell.value = val
							except:
								pass
							if letter(col) in ['F', 'H', 'I']:
								cell.border, cell.alignment = (borders, center)
							else:
								cell.border, cell.alignment = (borders, left)
							
							sheet.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)

						elif formatting_type == 'STM_validation':	
							try:
								cell.value = val
							except:
								pass
							if letter(col) in ['F', 'H', 'I']:
								cell.border, cell.alignment = (borders, center)
							else:
								cell.border, cell.alignment = (borders, left)

						##########################################################################################################################

						col = col + 1
					row = row + 1

				##########################################################################################################################
				# CUSTOM FORMATTING
				row = start_row + 1
				for dct in lst:
					cell = sheet[f'C{row}']
					if formatting_type == 'STM_main':
						if cell.value == '':
							row_2 = row
							cell_2 = sheet[f'C{row_2}']
							while cell_2.value == '':
								row_2 += 1
								cell_2 = sheet[f'C{row_2}']
							sheet.merge_cells(start_row=row-1, start_column=2, end_row=row_2-1, end_column=2)
							sheet.merge_cells(start_row=row-1, start_column=3, end_row=row_2-1, end_column=3)
							sheet.merge_cells(start_row=row-1, start_column=4, end_row=row_2-1, end_column=5)
							sheet.merge_cells(start_row=row-1, start_column=9, end_row=row_2-1, end_column=10)
							sheet.merge_cells(start_row=row-1, start_column=11, end_row=row_2-1, end_column=11)
							sheet.merge_cells(start_row=row-1, start_column=12, end_row=row_2-1, end_column=12)
							sheet.merge_cells(start_row=row-1, start_column=13, end_row=row_2-1, end_column=13)
							sheet.merge_cells(start_row=row-1, start_column=14, end_row=row_2-1, end_column=14)
							sheet.merge_cells(start_row=row-1, start_column=15, end_row=row_2-1, end_column=15)
					row = row + 1

				row = start_row + 1
				for dct in lst:
					cell = sheet[f'C{row}']
					if formatting_type == 'STM_main':
						flg_cell_is_merged = check_if_cell_is_merged(sheet, col=4, row=row)
						if not flg_cell_is_merged:
							sheet.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)
							sheet.merge_cells(start_row=row, start_column=9, end_row=row, end_column=10)
					row = row + 1
				##########################################################################################################################
		else:
			row = start_row

		return row + 3 # +3 - uwzględnia odstęp pomiędzy tabelami


def copy_and_move_sheet(wb, tmp_sheet_name, output_sheet_name, dest_pos=None):
	sheet_copy = wb.copy_worksheet(wb[tmp_sheet_name])
	# sheet_name = re.sub('^tmp ?', '', sheet_copy.title) # usuwa z nazwy słowo tmp
	# sheet_name = re.sub(' ?Copy', ' ', sheet_name).strip() # usuwa z nazwy słowo ' Copy'
	
	# ustawia odpowiedni numer suffixu jeżeli nazwa zakładki się powtarza
	sheet_suffix = 1
	if output_sheet_name in wb.sheetnames: # jeżeli zakładka już istnieje to dodaje suffix z numerem
		regex = re.compile(f'^{output_sheet_name}.*$')
		sheets_same_type = list(filter(regex.search, wb.sheetnames))
		last_sheet_char = [elem[-1] for elem in sheets_same_type if elem[-1].isdigit()]
		if len(last_sheet_char) > 0:
			max_last_sheet_char = max(last_sheet_char)
		if len(last_sheet_char) > 0: # jeżeli ostanią literą zakładki jest cyfra
			sheet_suffix = int(max_last_sheet_char) + 1
		else:
			sheet_suffix = '2'
		sheet_copy.title = f'{output_sheet_name} {sheet_suffix}'
	else:
		sheet_copy.title = output_sheet_name
	
	# usatwia zakładkę w odpowiednim miejscu
	move_sheet(wb, sheet_copy, dest_pos=dest_pos)
	return sheet_copy.title


# def create_sheet(wb, object_type, object_name=None, xml_high_dct=None):
# 	"""
# 	Description:
# 	\tCreate new sheet and move it into a proper location.\n
# 	Parameters:\n
# 	\t`wb` - current workbook\n
# 	\t`object_type` - ex. 'source', 'target', 'sc', 'mapping', 'worklet', 'session' etc.\n
# 	\t`object_name` - parameter is only required for source and target\n
# 	"""

# 	# calculate current sheet index
# 	shared_folder_sh_idx = [num for num, sheeet_name in enumerate(wb.sheetnames) if sheeet_name == 'tmp folder shared'][0]
# 	non_shared_sh_idx = [num for num, sheeet_name in enumerate(wb.sheetnames) if sheeet_name == 'folder (2)'][0]
# 	tgt_sh_idx = [num for num, sheeet_name in enumerate(wb.sheetnames) if sheeet_name == 'tmp target'][0]
# 	workflow_sh_idx = [num for num, sheeet_name in enumerate(wb.sheetnames) if sheeet_name == 'workflow'][0]
# 	session_sh_idx = [num for num, sheeet_name in enumerate(wb.sheetnames) if sheeet_name == 'tmp session'][0]

# 	sheet_exist_flg = False

# 	# set proper position by object type
# 	if object_type in ['folder']:
# 		tmp_sheet_name = f'tmp {object_type} shared'
# 		sheet_idx = tgt_sh_idx
# 	elif object_type in ['source']:
# 		tmp_sheet_name = f'tmp {object_type} ff' if re.search('^ff_.*$', object_name) else f'tmp {object_type}'
# 		shared_folder_name = xml_high_dct['SOURCE'][object_name]['SHARED_FOLDER_NAME']
# 		sheet_idx = [num for num, sheet_name in enumerate(wb.sheetnames) if 'folder shared' in sheet_name and wb[sheet_name]['C2'].value == shared_folder_name][0]
# 		sheet_idx = sheet_idx + 1
# 	elif object_type in ['target']:
# 		tmp_sheet_name = f'tmp {object_type} ff' if re.search('^ff_.*$', object_name) else f'tmp {object_type}'
# 		shared_folder_name = xml_high_dct['TARGET'][object_name]['SHARED_FOLDER_NAME']
# 		sheet_idx = [num for num, sheet_name in enumerate(wb.sheetnames) if 'folder shared' in sheet_name and wb[sheet_name]['C2'].value == shared_folder_name][0]
# 		sheet_idx = sheet_idx + 1
# 	elif object_type in ['sc','mapping','agg','asq','ct','exp','ext','fil','http','mi','jv','jnr','lkp','lkpu','mplt','nrm','mo','rnk','rtr','seq','srt','sql','sq','sp','tct','un','upd','xmg','xmp','xmsq']:
# 		tmp_sheet_name = f'tmp {object_type}'
# 		sheet_idx = workflow_sh_idx
# 	elif object_type in ['worklet','session']:
# 		tmp_sheet_name = f'tmp {object_type}'
# 		sheet_idx = session_sh_idx

# 	# check if sheet with object_name arleady exists
# 	for sheet_name in wb.sheetnames:
# 		if wb[sheet_name]['C2'].value == object_name and object_type in ['folder']:
# 			sheet_exist_flg = True

# 	if not sheet_exist_flg:
# 		# copy and rename sheet
# 		sheet_copy = wb.copy_worksheet(wb[tmp_sheet_name])
# 		sheet_name = re.sub('^tmp ', '', sheet_copy.title) # usuwa z nazwy słowo tmp
# 		sheet_name = re.sub(' Copy', ' ', sheet_name).strip() # usuwa z nazwy słowo ' Copy'

# 		# set proper suffix number if sheet is duplicated
# 		sheet_suffix = 1
# 		if not sheet_name in wb.sheetnames: # if sheet not exist
# 			sheet_copy.title = sheet_name
# 		else: # if sheet already exists
# 			regex = re.compile(f'^{sheet_name}.*$')
# 			sheets_same_type = list(filter(regex.search, wb.sheetnames))
# 			last_sheet_char = [elem[-1] for elem in sheets_same_type if elem[-1].isdigit()]
# 			if len(last_sheet_char) > 0:
# 				max_last_sheet_char = max(last_sheet_char)
# 			if len(last_sheet_char) > 0: # jeżeli ostanią literą zakładki jest cyfra
# 				sheet_suffix = int(max_last_sheet_char) + 1
# 			else:
# 				sheet_suffix = '2'
# 			sheet_copy.title = f'{sheet_name} {sheet_suffix}'

# 		# usatwia zakładkę w odpowiednim miejscu
# 		move_sheet(wb, sheet_copy, sheet_idx)
# 		return sheet_copy.title
# 	else:
# 		return None


#################################################################
# Run python functions in excel
#################################################################

# umożliwia uruchomienie dowolnej funkcji z poziomu excela
def run_python_function_from_excel(workbook_path, sheet_name, function_name, *args):
	wb = load_workbook(workbook_path, read_only=False, data_only=True) # data_only - odczytuje jedynie wyniki formuł
	sheet = wb[sheet_name]
	function = eval(function_name)
	result = function(sheet, *args)
	return result


# # kopiuje range_to_list_by_title do słownika
# # def excel_table_to_dct_by_table_name(workbook_path, sheet_name, *args):
# def table_to_dct(workbook_path, sheet_name, *args):
# 	"""Umożliwia uruchominie funkcji python'owej bezpośrednio w Excel'u.\n
# 	Aby odpalić funkcję pythonową, należy uruchomić w exelu macro o  nazwie `Table_to_DCT`. 

# 	Args:
# 		workbook_path (_type_): Ścieżka do workbook'a.
# 		sheet_name (_type_): Nazwa zakładki.
# 	"""

# 	function_name = 'range_to_dataset_by_table_name'
# 	result = run_python_function_from_excel(workbook_path, sheet_name, function_name, *args)
# 	result = str(result)
# 	result = re.sub('\}, \{', '},`r`n{', result).strip() # add new lines between nexte element of the list
# 	print(result)
# 	copy2clip(result)


# kopiuje range_to_list_by_title do słownika
# def excel_table_to_dct_by_table_name(workbook_path, sheet_name, *args):
def table_to_dct(workbook_path, sheet_name, *args):
	"""Umożliwia uruchominie funkcji python'owej bezpośrednio w Excel'u.\n
	Aby odpalić funkcję pythonową, należy uruchomić w exelu macro o  nazwie `Table_to_DCT`.

	Args:
		workbook_path (_type_): Ścieżka do workbook'a.
		sheet_name (_type_): Nazwa zakładki.
	"""
	# table_to_dct(workbook_path=r'C:\Dane\repo\git\specifications\IDA\mobile_activity_IDA_Logiczny_Model_Danych_v1.3.xlsx', sheet_name='T400005_MOB_ACT', '$B$15:$C$30')
	# range_to_dataset_by_table_name(sheet_obj, table_name_pattern, offset_header_rows=1, orientation=None, max_row_num=None, max_col_num=None)
	# range_to_dataset_by_address(sheet_obj, table_range, orientation=orientation)
	function_name='range_to_dataset_by_address'
	result = run_python_function_from_excel(workbook_path, sheet_name, function_name, *args)
	result = result[0]
	result_str = str(result)
	result_print = re.sub('\}, \{', '},\n{', result_str).strip() # add new lines between nexte element of the list
	print(result_print)
	
	# result_clipboard = re.sub('\}, \{', '},`r`n{', result_str).strip() # add new lines between nexte element of the list
	# copy2clip(result_clipboard)


def copy2clip(txt):
	# cmd = f'echo {txt}| clip' # cmd
	# return subprocess.run(cmd, shell=True)
	cmd = f'"{txt}" | clip' # powershell
	return subprocess.run(["powershell", "-Command", cmd])


# example use of table_to_dct function:
# table_to_dct(r'C:\Dane\repo\projects\RPZKB-2356\tech_spec\meta_data.xlsx', 'Meta tables', 't00012_source_target_map')