import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
from openpyxl import load_workbook, Workbook
# import pandas as pd
# from datetime import datetime
# import re
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from copy import deepcopy
from excel_functions_stm import *

# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())

from const import tech_fields_scd2, tech_fields_scd1_act, tech_fields_scd1_ovr, tech_fields_snap_ovr, tech_fields_fact, stm_const_parameteres, stm_main_header  #, stm_src_areas_header, stm_src_tables_dct_header, stm_src_definition_header, stm_parameters_header
from control_panel import wf_ID, tgt_schema_name, old_table_codes, new_table_codes, input_stm_file_path, output_ldm_file_path, sys_cd, table_map, ida_pk, schema_map, stm_sys_map, xDA, stm_source_lst


# def generate_stm():
# table codes only
# old_table_codes = ['T17101','T17102'] # input here sheet_names, table_names or table codes ('txxxxxx')

# input_stm_file_name = rf'CRM3.0_STM_MDM_-_Zdarzenia_i_Sygnały_v0.1.xlsx'
# sys_cd = 'PZKB'
# wf_ID = 'ESF'
# input_stm_file_path = rf''
# input_ldm_file_name = rf''


# src_paths = [rf'C:\Dane\repo\projects\RPZKB-{jira}\dokumentacja\{input_stm_file_name}']
input_stm_wb_paths = [rf'{input_stm_file_path}']
tmp_wb_paths = [rf'C:\Dane\repo\notebook\projects\_templates\tmp_STM.xlsx']


# path to executable file
base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output')
output_package_path = rf'C:\Dane\repo\python\Generator\_output'
output_file_path = os.path.join(output_package_path, f'{wf_ID.lower()}_IDA_STM_v1.0.xlsx')


# [os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.xls'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany


pk_dct = {}
for item in ida_pk:
	table_name = item['table_name']
	column_name = item['column_name']
	if column_name.upper() not in ['EFFECTIVE_ST_DT', 'EFFECTIVE_END_DT', 'LOAD_ID', 'UPDATE_ID', 'SRC_SYS_ID', 'SYS_ID']:
		if table_name not in pk_dct:
			pk_dct[table_name] = [column_name]
		else:
			pk_dct[table_name].append(column_name)


# loop through workbooks
for input_stm_wb_path, tmp_wb_path in zip(input_stm_wb_paths, tmp_wb_paths):

	################################################################################################################################
	# READ INPUT
	################################################################################################################################

	# open STM workbook
	if input_stm_wb_path is None or input_stm_wb_path != '':
		src_wb = load_workbook(input_stm_wb_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	else:
		src_wb = None
		ldm_wb = load_workbook(output_ldm_file_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
		ldm_sheet_names = [string for string in ldm_wb.sheetnames if any((substr[1:7] in string) for substr in new_table_codes)]
		ldm_main_dct = all_datasets_by_table_name(ldm_wb, ldm_sheet_names, table_name_regex_pattern='Specyfikacja logicznego modelu danych', offset_header_rows=2, orientation='H')
	
	tmp_wb = load_workbook(tmp_wb_path, read_only=False, data_only=False) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	
	# print(src_wb.sheetnames) # for development purpose only
	# ['T226001_CI_LEAD_STATUS_HIST', 'T226002_CI_COMMUNICATION_HIST', 'T226003_CI_CELL_PACKAGE_HIST', 'T226004_CI_CAMPAIGN_HIST', 'T226005_CI_COMMUNICATION_EXT_HIST', 'T226006_CI_ACTION_STATUS_HIST', 'T226007_UDICT_CI_RESPONSE_HIST', 'T226008_TBT401_EVENT_HIST', 'T226009_CI_CAMPAIGN_GROUP_HIST', 'T226010_UDICT_CI_CAMP_BIZ_CODE_HIST', 'T226011_CI_CAMPAIGN_EXT_HIST', 'T226012_UDICT_CI_COMM_BIZ_CODE_HIST', 'T226013_UDICT_CI_EVENT_HIST', 'T226014_UDICT_CD_CHANNEL_HIST', 'T226015_UDICT_CI_OFFER_HIST', 'T226016_UDICT_CI_CAMP_TYPE_HIST', 'T226017_UDICT_CI_CAMP_GROUP_HIST', 'T226018_UDICT_CI_CAMP_SUBTYPE_HIST', 'T226019_UDICT_CI_CREDIT_OFFER_HIST', 'T226020_UDICT_CI_COMBO_OFFER_HIST', 'T226021_SCENARIO_GROUP_HIST', 'T226022_SCEN_X_SCEN_GRP_HIST', 'T226023_UDICT_CI_BR_CAMP_PRIOR_HIST', 'T226024_UDICT_CI_BR_CAMP_SCH_TP_HIST', 'T226025_UDICT_CI_BR_CAMP_STATUS_HIST', 'T226026_UDICT_CI_CAMPAIGN_USERS_HIST', 'T226027_UDICT_CI_CRED_OFFER_PROC_HIST', 'T226028_UDICT_CI_HTML_ID_HIST', 'T226029_UDICT_CI_JSON_TYPE_HIST', 'T226030_UDICT_CI_TREATMENT_HIST', 'T226031_UDICT_ACTION_SRC_CD_HIST', 'T227001_DCT_CHANNEL_CONTENT_HIST', 'T227002_TRT010_OFFER_HIST', 'T227003_BRANCH_CHANNEL_PARAMS_HIST', 'T226032_CI_ACTION_LEAD_OUT_HIST', 'T226033_CI_ACTION_RESPONSE_HIST', 'T226034_CI_ACTION_LEAD_CLOSE_HIST', 'T226035_CI_ACTION_PROSP_OUT_HIST', 'T227004_CI_DECISION_RTM_HIST']

	if src_wb is not None:
		old_sheet_names = [string for string in src_wb.sheetnames if any((substr[1:6] in string) for substr in old_table_codes)]
		stm_sheet_names = [re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', old_sheet_name[0:6]) for old_sheet_name in old_sheet_names]  # input here sheet_names, table_names or table codes ('txxxxxx')
		# stm_sheet_names = [re.sub('HIST P', 'HST P', stm_sheet_name) if len(stm_sheet_name) > 31 else stm_sheet_name for stm_sheet_name in stm_sheet_names]  # rename if sheetname is longer than 31 chars
		tgt_table_names = [re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', old_sheet_name) for old_sheet_name in old_sheet_names]  # input here sheet_names, table_names or table codes ('txxxxxx')
		
		old_table_names = [re.sub(' .*$', '', old_table_name) for old_table_name in  old_sheet_names] # remove additional info if table has more than one partition 
		tgt_table_names = [re.sub(' .*$', '', tgt_table_name) for tgt_table_name in  tgt_table_names] # remove additional info if table has more than one partition 

		# convert excel ranges into nested lists
		stm_src_dct = all_datasets_by_table_name(src_wb, old_sheet_names, table_name_regex_pattern='Lista tabel źródłowych', offset_header_rows=1, orientation='H')
		stm_main_dct = all_datasets_by_table_name(src_wb, old_sheet_names, table_name_regex_pattern='^Cel$', offset_header_rows=1, orientation='H')


		stm_src_dct = []
		for table, sources in stm_source_lst.items():
			for source in sources:
				schema, table_name = source.split('.')
				stm_src_dct.append({'Schemat': schema, 'Tabela źródłowa': table_name})
	else:
		ldm_sheet_names = [string for string in ldm_wb.sheetnames if any((substr[1:7] in string) for substr in new_table_codes)]
		stm_sheet_names = ldm_sheet_names
		# stm_sheet_names = [string[0:7] for string in ldm_sheet_names]
		# old_sheet_names = [string for string in ldm_sheet_names]
		old_sheet_names = ldm_sheet_names
		tgt_table_names = list(stm_source_lst.keys())


	################################################################################################################################
	# GENERATE DICTS
	################################################################################################################################


	################################
	# SRC AREAS TABLE
	stm_src_areas = [{'Nazwa obszaru': '', 'None': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}]

	################################
	# SRC LIST TABLE
	stm_src_tables_dct = {}
	if src_wb is not None:
		for old_sheet_name, (table_name, lst) in zip(old_sheet_names, stm_src_dct.items()):
			tgt_schema_name = src_wb[old_sheet_name]['C4'].value
			tgt_schema_name = schema_map[tgt_schema_name] if tgt_schema_name in schema_map.keys() else tgt_schema_name

			src_table_names = []
			new_lst = []
			for num, dct in enumerate(lst):
				# src_schema_name = 'SDA_226_SCI1_DATA' if dct['Schemat'] == 'BTIFACE' else 'SDA_227_RTM1_DATA' if dct['Schemat'] == 'RTIFACE' else 'IDA_420_COMMON_DATA' if dct['Schemat'] == 'DB15_CAMPAIGN_MGMT' else dct['Schemat']
				src_schema_name = schema_map[dct['Schemat']] if dct['Schemat'] in schema_map.keys() else dct['Schemat']
				src_table_name = re.sub(r'(\w+) +(as)? ?(.+) ?$', r'\1', dct['Nazwa tabeli'], re.I)
				src_table_name = re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', src_table_name).upper()
				src_table_name = table_map[src_table_name] if src_table_name in table_map.keys() else src_table_name
				# src_sys_name = 'SCI1' if dct['System'] == 'Batch DB' else 'RTM1' if dct['System'] == 'Oper DB' else 'MDM' if dct['System'] == 'MDM' else dct['System']
				src_sys_name = stm_sys_map[dct['System']] if dct['System'] in stm_sys_map.keys() else dct['System']
				src_sys_name = src_schema_name[8:12] if src_sys_name == 'MDM' else src_sys_name # custom modification if system is marked as MDM but tables are from BATCH or OPER system
				if src_table_name not in src_table_names:
					elem = {'System źródłowy': src_sys_name, 'Schemat': src_schema_name, 'Tabela źródłowa': src_table_name, 'None': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
					new_lst.append(elem)
					src_table_names.append(src_table_name)
			stm_src_tables_dct.setdefault(table_name, []).extend(new_lst)
	else:
		for tgt_table_name, sources in stm_source_lst.items():
			new_lst = []
			for source in sources:
				src_schema_name, src_table_name = source.split('.')
				elem = {'System źródłowy': 'DDP', 'Schemat': src_schema_name, 'Tabela źródłowa': src_table_name, 'None': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
				new_lst.append(elem)
			table_prefix = tgt_table_name[0:7]
			stm_src_tables_dct.setdefault(table_prefix, []).extend(new_lst)

	################################
	# SRC DEFINITION TABLE
	stm_src_definition = {}
	if src_wb is not None:
		for old_sheet_name, (table_name, new_lst) in zip(old_sheet_names, stm_src_dct.items()):
			new_lst = []
			for num, dct in enumerate(lst):
				src_table_name = dct['Nazwa tabeli']
				src_table_name = re.sub(r'(\w+) +(as)? ?(.+) ?$', r'\1', dct['Nazwa tabeli'], re.I)
				src_table_name = re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', src_table_name).upper()
				src_table_name = table_map[src_table_name] if src_table_name in table_map.keys() else src_table_name
				src_alias = re.sub(r'(\w+) +(as)? ?(.+) ?$', r'\3', dct['Nazwa tabeli'], re.I)
				src_alias = re.sub(r'T\d+_', '', src_alias, re.I)
				src_alias = re.sub(r'E_EXP_', '', src_alias, re.I)
				src_alias = re.sub(r'E_IMP_', '', src_alias, re.I)
				src_prefix = src_table_name[0:7]
				# tgt_table_name = re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', src_wb[old_sheet_name]['D4'].value).upper() if dct['Sposób użycia'] == 'Wiodąca' else f'tmp{num}'
				tgt_table_name = re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', src_wb[old_sheet_name]['D4'].value).upper()
				table_role = 'Master' if dct['Sposób użycia'] == 'Wiodąca' else 'Additional'
				join_type = 'n/a' if dct['Sposób użycia'] == 'Wiodąca' else dct['Sposób łączenia']
				join_condition = 'n/a' if dct['Sposób użycia'] == 'Wiodąca' else dct['Warunki złaczenia']
				filter_condition = f"DUE_DT = TO_DATE('$$DueDt', 'MM/DD/YYYY HH24:MI:SS') AND EXTRACT_VERSION = '$$ExtractVersion_{src_prefix}'" if dct['Sposób użycia'] == 'Wiodąca' else dct['Warunki filtrowania']

				elem = {'Wynikowy zbiór danych': tgt_table_name, 'Wejściowy zbiór danych': src_table_name, 'Alias': src_alias, 'Filtrowanie wejściowego \nzbioru danych': filter_condition, 'Rola wejściowego zbioru danych': table_role, 'Operator': join_type, 'Warunek łączenia tabel': join_condition, 'Filtrowanie wynikowego \nzbioru danych': '', 'Agregacja \nwynikowego zbioru danych': '', 'Kolumny wynikowe': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
				new_lst.append(elem)
			stm_src_definition.setdefault(table_name, []).extend(new_lst)
	else:
		for tgt_table_name, sources in stm_source_lst.items():
			new_lst = []
			for source in sources:
				src_schema_name, src_table_name = source.split('.')
				elem = {'Wynikowy zbiór danych': tgt_table_name, 'Wejściowy zbiór danych': src_table_name, 'Alias': 'X', 'Filtrowanie wejściowego \nzbioru danych': 'xxx = xxx', 'Rola wejściowego zbioru danych': 'Master', 'Operator': 'xxx', 'Warunek łączenia tabel': 'xxxx', 'Filtrowanie wynikowego \nzbioru danych': '', 'Agregacja \nwynikowego zbioru danych': '', 'Kolumny wynikowe': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
				new_lst.append(elem)
			table_prefix = tgt_table_name[0:7]
			stm_src_definition.setdefault(table_prefix, []).extend(new_lst)

	################################
	# MAIN STM TABLE
	# remove deleted rows with 'D' flag
	if src_wb is not None:
		new_dct = {}
		for table_name, lst in stm_main_dct.items():
			new_lst = []
			tech_num = 0
			for num, dct in enumerate(lst):
				if dct['Rodzaj zmiany'] != 'D':
					new_lst.append(dct)
			new_dct.setdefault(table_name, []).extend(new_lst)

		# remove src technical fields
		new_dct_2 = {}
		for table_name, lst in new_dct.items():
			new_lst = []
			tech_num = 0
			for num, dct in enumerate(lst):
				if dct['Kolumna'].upper() not in ['EFFECTIVE_ST_DT', 'EFFECTIVE_END_DT', 'LOAD_ID', 'UPDATE_ID', 'SRC_SYS_ID', 'SYS_ID']:
					new_lst.append(dct)
			new_dct_2.setdefault(table_name, []).extend(new_lst)

		# # remove merged rows
		# new_dct_3 = {}
		# for table_name, lst in new_dct_2.items():
		# 	new_lst = []
		# 	tech_num = 0
		# 	for num, dct in enumerate(lst):
		# 		if dct['Kolumna'] != '':
		# 			new_lst.append(dct)
		# 	new_dct_3.setdefault(table_name, []).extend(new_lst)

		new_dct_3 = {}
		for old_sheet_name, (table_name, lst) in zip(old_sheet_names, new_dct_2.items()):
			new_lst = []
			tech_num = 0
			# table_name = re.sub(' .*$', '', table_name)
			for num, dct in enumerate(lst):
				if dct['Rodzaj zmiany'] != 'D':
					new_lst.append(dct)
			new_dct_3.setdefault(table_name, []).extend(new_lst)

		# enrich dictionary
		new_dct_4 = {}
		stm_validation = {}
		for (old_sheet_name, table_rows), old_table_name, tgt_table_name in zip(new_dct_3.items(), old_table_names, tgt_table_names):
			new_lst = []
			pk_field = []
			tech_num = 0
			pk_num = 0
			

			for num, table_row in enumerate(table_rows):
				# add PK and its NK
				if xDA == 'IDA':
					if num == 0:
						nk_list = ''
						if old_table_name in pk_dct.keys():
							for nk_num, nk_field_name in enumerate(pk_dct[old_table_name]):
								for table_row_2 in table_rows:
									if table_row_2['Kolumna'].upper() == nk_field_name.upper():
										src_table_name = table_row_2['Nazwa tabeli_2']
										src_table_name = re.sub(r'(\w+) +(as)? ?(\w+) ?$', r'\1', table_row_2['Nazwa tabeli_2'], re.I)
										src_table_name = table_map[src_table_name] if src_table_name in table_map.keys() else src_table_name
										src_alias = re.sub(r'(\w+) +(as)? ?(\w+) ?$', r'\3', table_row_2['Nazwa tabeli_2'], re.I)
										src_alias = re.sub(r'T\d+_', '', src_alias, re.I)
										src_alias = re.sub(r'E_EXP_', '', src_alias, re.I)
										src_alias = re.sub(r'E_IMP_', '', src_alias, re.I)
										src_column_name = table_row_2['Kolumna_2']
										nk_list += f'\n{nk_num+1}. {src_column_name}'
										if nk_num+1 == len(pk_dct[old_table_name]):
											nk_list += f'\n{nk_num+2}. SYS_CD'
								if nk_num == 0:
									# pk_field.append({'Schemat wynikowego zbioru danych': tgt_schema_name, 'Wynikowy zbiór danych': re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', table_name).upper(), 'Nazwa kolumny w wynikowym zbiorze': f'{table_name[7:]}_KEY', 'None': '', 'Źródłowy zbiór danych': src_table_name, 'Alias źródłowego zbioru danych': src_alias, 'Kolumna źródłowa': src_column_name, 'Logika transformacji': '', 'None2': '', 'Wartość domyślna': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''})
									pk_field.append({'Schemat wynikowego zbioru danych': tgt_schema_name, 'Wynikowy zbiór danych': tgt_table_name, 'Nazwa kolumny w wynikowym zbiorze': f'{table_name[7:]}_KEY', 'None': '', 'Źródłowy zbiór danych': src_table_name, 'Alias źródłowego zbioru danych': src_alias, 'Kolumna źródłowa': src_column_name, 'Logika transformacji': '', 'None2': '', 'Wartość domyślna': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''})
								else:
									pk_field.append({'Schemat wynikowego zbioru danych': tgt_schema_name, 'Wynikowy zbiór danych': '', 'Nazwa kolumny w wynikowym zbiorze': '', 'None': '', 'Źródłowy zbiór danych': src_table_name, 'Alias źródłowego zbioru danych': src_alias, 'Kolumna źródłowa': src_column_name, 'Logika transformacji': None, 'None2': '', 'Wartość domyślna': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''})
							pk_field[0]['Logika transformacji'] = f'Wyznaczenie wartości klucza sztucznego na wartościach z poniższych kolumn. Złączenie wartości w kolejności:{nk_list}'
							new_lst.extend(deepcopy(pk_field))

				# if 'VARCHAR2' in table_row['Typ danych']:
				# 	data_type = re.sub('VARCHAR2', 'STRING', table_row['Typ danych'])
				# elif 'CHAR' in table_row['Typ danych']:
				# 	data_type = re.sub('CHAR\(', 'STRING(', table_row['Typ danych'])
				# elif 'NUMBER' in table_row['Typ danych']:
				# 	data_type = re.sub('NUMBER', 'NUMERIC', table_row['Typ danych'])
				# elif 'TIMESTAMP' in table_row['Typ danych']:
				# 	data_type = 'TIMESTAMP'
				# elif table_row['Typ danych'] == 'INTEGER':
				# 	data_type = 'INT64'
				# else:
				# 	data_type = table_row['Typ danych']
				
				src_column_name = table_row['Kolumna_2'].upper()
				src_table_name = re.sub(r'(\w+) +(as)? ?(\w+) ?$', r'\1', table_row['Nazwa tabeli_2'], re.I)
				src_table_name = table_map[src_table_name] if src_table_name in table_map.keys() else src_table_name
				src_alias = re.sub(r'(\w+) +(as)? ?(\w+) ?$', r'\3', table_row['Nazwa tabeli_2'], re.I)
				src_alias = re.sub(r'T\d+_', '', src_alias, re.I)
				src_alias = re.sub(r'E_EXP_', '', src_alias, re.I)
				src_alias = re.sub(r'E_IMP_', '', src_alias, re.I)
				# tgt_schema_name = 'IDA_420_COMMON_DATA'
				# tgt_table_name = re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', table_row['Nazwa tabeli']).upper()
				tgt_column_name = table_row['Kolumna'].upper()
				
				elem = {'Schemat wynikowego zbioru danych': tgt_schema_name, 'Wynikowy zbiór danych': tgt_table_name, 'Nazwa kolumny w wynikowym zbiorze': tgt_column_name, 'None': '', 'Źródłowy zbiór danych': src_table_name, 'Alias źródłowego zbioru danych': src_alias, 'Kolumna źródłowa': src_column_name, 'Logika transformacji': table_row['Opis transformacji'], 'None2': '', 'Wartość domyślna': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
				new_lst.append(elem)

			# add technical fields at the end of the table
			if 'SCD1' in src_wb[old_sheet_name]['E4'].value.upper():
				new_lst.extend(tech_fields_scd1_act)
				tech_num = len(tech_fields_scd1_act)
			elif 'SCD2' in src_wb[old_sheet_name]['E4'].value.upper():
				new_lst.extend(tech_fields_scd2)
				tech_num = len(tech_fields_scd2)
			elif 'fakt' in src_wb[old_sheet_name]['E4'].value.lower():
				new_lst.extend(tech_fields_fact)
				tech_num = len(tech_fields_fact)
			elif 'nadpisywana' in src_wb[old_sheet_name]['E4'].value.lower():
				new_lst.extend(tech_fields_fact)
				tech_num = len(tech_fields_fact)
			elif 'snapshot' in src_wb[old_sheet_name]['E4'].value.lower():
				new_lst.extend(tech_fields_snap_ovr)
				tech_num = len(tech_fields_snap_ovr)

			new_dct_4.setdefault(old_sheet_name, []).extend(new_lst)

			# validation dct
			stm_validation.setdefault(f'Walidacje_{tgt_table_name[0:7]}', []).extend([{'RULE_ID': f'R{tgt_table_name[1:7]}_001', 'RULE_CATEGORY_CD': 'PK', 'MODEL_AREA_CD': sys_cd, 'LOAD_PHASE_CD': 'PROC', 'RULE_TYPE_CD': 'ETL', 'RULE_GROUP_CD': '', 'SCHEMA_NM': tgt_schema_name, 'TABLE_NM': tgt_table_name, 'ETL_PKG_CD': f'{sys_cd}_01', 'COLUMN_NM': f'{table_name[7:]}_KEY', 'SYS_CD': sys_cd, 'SQL_QUERY': '', 'RULE_DSC': 'Walidacja unikalności klucza głównego', 'WARN_LVL': '0', 'ERROR_LVL': '0', 'RULE_WEIGHT_CD': 'LOW', 'RULE_PRIORITY_CD': 'LOW', 'ACTIVE_FLG': '1', 'EFF_ST_DT': '1900-01-01 00:00:00', 'EFF_END_DT': '9999-12-31 00:00:00', 'NOTIFICATION_MAIL': '', 'NOTIFICATION_SMS': '', 'RULE_OWNER_NM': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}])


		# rename attributes for technical fields
		new_dct_5 = {}
		for (table_name, lst), tgt_table_name in zip(new_dct_4.items(), tgt_table_names):
			new_lst = []
			tech_num = 0
			for num, dct in enumerate(lst):
				if dct['Nazwa kolumny w wynikowym zbiorze'] in ['SYS_CD', 'TECH_IS_ACTIVE_FLG', 'TECH_ACTUAL_END_DT', 'TECH_ETL_PKG_CD', 'TECH_INSERT_ID', 'TECH_UPDATE_ID', 'TECH_INSERT_TS', 'TECH_UPDATE_TS', 'TECH_CLOSE_ID', 'TECH_CLOSE_TS', 'START_DT', 'END_DT', 'DUE_DT', 'TECH_INSERT_TS']:
					dct['Schemat wynikowego zbioru danych'] = tgt_schema_name
					# dct['Wynikowy zbiór danych'] = re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', table_name).upper()
					dct['Wynikowy zbiór danych'] = tgt_table_name
					dct['Źródłowy zbiór danych'] = ''
					dct['Alias źródłowego zbioru danych'] = ''
				new_lst.append(deepcopy(dct))
			new_dct_5.setdefault(table_name, []).extend(new_lst)
	else:
		new_dct_5 = {}
		for tgt_table_name, (tgt_table_code, rows) in zip(tgt_table_names, ldm_main_dct.items()): # TODO - upewnij się że w zip jest taka sama ilość elementów
			new_lst = []
			for row in rows:
				tgt_field_name = row['Kolumna']
				src_field_name = tgt_field_name
				src_schema_name, src_table_name = stm_source_lst[tgt_table_name][0].split('.')
				elem = {'Schemat wynikowego zbioru danych': tgt_schema_name.upper(), 'Wynikowy zbiór danych': tgt_table_name.upper(), 'Nazwa kolumny w wynikowym zbiorze': tgt_field_name.upper(), 'None': '', 'Źródłowy zbiór danych': src_table_name.upper(), 'Alias źródłowego zbioru danych': 'X', 'Kolumna źródłowa': src_field_name.upper(), 'Logika transformacji': '1-1', 'None_2': '', 'Wartość domyślna': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
				new_lst.append(elem)
			table_prefix = tgt_table_name[0:7]
			new_dct_5.setdefault(table_prefix, []).extend(new_lst)

	################################
	# PARAMETERS TABLE
	for item in stm_const_parameteres:
		if item['Nazwa parametru'] == '$$ETLPackage':
			item['Formuła'] = rf"''{sys_cd}_01'"

	stm_parameters = {}
	if src_wb is not None:
		for old_sheet_name, (table_name, lst) in zip(old_sheet_names, stm_src_dct.items()):
			new_lst = []
			for num, dct in enumerate(lst):
				# src_table_name = re.sub(r'(\w+) +(as)? ?(\w+) ?$', r'\1', dct['Nazwa tabeli'], re.I)
				# src_table_name = re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', src_table_name).upper()
				src_table_name = table_map[src_table_name] if src_table_name in table_map.keys() else src_table_name
				src_prefix = re.findall('^t\d+', src_table_name, re.I)[0]
				elem = {'Nazwa parametru': f'$$ExtractVersion_{src_prefix}', 'Typ': '', 'Opis': f'Wersja ekstraktu {src_table_name}', 'None': '', 'Formuła': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
				new_lst.append(elem)
			stm_parameters.setdefault(table_name, []).extend(stm_const_parameteres)
			stm_parameters.setdefault(table_name, []).extend(new_lst)
	else:
		new_lst = []
		for tgt_table_name, sources in stm_source_lst.items():
			for source in sources:
				src_schema_name, src_table_name = source.split('.')
				try:
					src_prefix = re.findall('^t\d+', src_table_name, re.I)[0]
				except:
					src_prefix = 't000000'

				if 'sda_' in src_schema_name:
					elem = {'Nazwa parametru': f'$$ExtractVersion_{src_prefix}', 'Typ': '', 'Opis': f'Wersja ekstraktu {src_table_name}', 'None': '', 'Formuła': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
					new_lst.append(elem)
			table_prefix = tgt_table_name[0:7]
			stm_parameters.setdefault(table_prefix, []).extend(stm_const_parameteres)
			stm_parameters.setdefault(table_prefix, []).extend(new_lst)

	################################################################################################################################
	# WRITE dicts into excel
	################################################################################################################################

	################################
	# LISTA TABEL
	row = 4
	for tgt_table in tgt_table_names:
		tmp_wb['Lista tabel'][f'B{row}'].value = f'=HYPERLINK("#{tgt_table[0:7]}!B1","{tgt_table}")'
		tmp_wb['Lista tabel'][f'D{row}'].value = f'=HYPERLINK("#Walidacje_{tgt_table[0:7]}!B1","link")'
		tmp_wb['Lista tabel'][f'E{row}'].value = tgt_table
		tmp_wb['Lista tabel'][f'F{row}'].value = 'Daniel Wiśniewski'
		tmp_wb['Lista tabel'][f'H{row}'].value = '1.0'
		tmp_wb['Lista tabel'][f'I{row}'].value = 'I'
		row+=1

	for old_sheet_name, stm_sheet_name, tgt_table_name in zip(old_sheet_names, stm_sheet_names, tgt_table_names):
		
		# create new sheet
		stm_sheet_name = copy_and_move_sheet(tmp_wb, 'tmp', stm_sheet_name, dest_pos=None)
		
		# set zoom
		tmp_wb[stm_sheet_name].sheet_view.zoomScale = 85

		################################
		# HEADER TABLE
		# tmp_wb[stm_sheet_name]['C4'].value = re.sub(f'T{old_sheet_name[1:3]}', f'T{tgt_schema_name[4:7]}', src_wb[old_sheet_name]['D4'].value)
		tmp_wb[stm_sheet_name]['C4'].value = tgt_table_name
		tmp_wb[stm_sheet_name]['C5'].value = tgt_schema_name

		if src_wb is not None:
			if 'SCD1' in src_wb[old_sheet_name]['E4'].value.upper():
				table_type = 'Brak historyzacji (SCD1) przez nadpisanie'
			elif 'SCD2' in src_wb[old_sheet_name]['E4'].value.upper():
				table_type = 'Historyzacja datami od - do (SCD2)'
			elif 'fakt' in src_wb[old_sheet_name]['E4'].value.lower():
				table_type = 'Dopisanie faktów za dowolną datę biznesową'
			elif 'nadpisywana' in src_wb[old_sheet_name]['E4'].value.lower():
				table_type = 'Dopisanie faktów za dowolną datę biznesową'
			elif 'snapshot' in src_wb[old_sheet_name]['E4'].value.lower():
				table_type = 'Snapshot - stan danych na datę'
		else:
			table_type = ldm_wb[old_sheet_name]['C11'].value.lower()

		tmp_wb[stm_sheet_name]['C6'].value = table_type


		# leave table prefix only in sheen_name
		stm_dct_keys = list(stm_src_definition.keys())
		if old_sheet_name not in stm_dct_keys:
			old_sheet_name = re.findall('^t\d+', old_sheet_name, re.I)[0].lower()


		################################
		# SRC AREAS TABLE
		row_num = 15
		# row_num = dict_to_range(stm_src_areas_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Źródło do Tabeli docelowej', orientation='H', formatting_type=None)
		row_num = dict_to_range(stm_src_areas, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Lista Powiązanych obszarów', orientation='H', formatting_type='STM_src_areas')
		
		################################
		# SRC LIST TABLE
		# row_num = dict_to_range(stm_src_tables_dct_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Lista Tabel Źródłowych', orientation='H', formatting_type=None)
		row_num = dict_to_range(stm_src_tables_dct[old_sheet_name], tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Lista Tabel Źródłowych', orientation='H', formatting_type='STM_src_tables')


		################################
		# SRC DEFINITION TABLE
		# row_num = dict_to_range(stm_src_definition_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Źródło do Tabeli docelowej', orientation='H', formatting_type=None)
		row_num = dict_to_range(stm_src_definition[old_sheet_name], tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Definicja zbiorów danych (join)', orientation='H', formatting_type='STM_src_definition')
		
		################################
		# MAIN STM TABLE
		row_num = dict_to_range(stm_main_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Źródło do Tabeli docelowej', orientation='H', formatting_type='STM_main_header')
		row_num = dict_to_range(new_dct_5[old_sheet_name], tmp_wb[stm_sheet_name], start_cell=f'B{row_num-4}', table_name=None, orientation='H', formatting_type='STM_main')

		################################
		# PARAMETERS TABLE
		# row_num = dict_to_range(stm_parameters_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Źródło do Tabeli docelowej', orientation='H', formatting_type=None)
		row_num = dict_to_range(stm_parameters[old_sheet_name], tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Lista parametrów', orientation='H', formatting_type='STM_parameters')

		################################
		# create validation sheet
		# stm_val_sheet_name = f'Walidacje_{stm_sheet_name}'
		# stm_sheet_name = copy_and_move_sheet(tmp_wb, 'tmp_validation', stm_val_sheet_name, dest_pos=None)
		# tmp_wb[stm_val_sheet_name].sheet_view.zoomScale = 85
		# row_num = dict_to_range(stm_validation[stm_sheet_name], tmp_wb[stm_val_sheet_name], start_cell='B3', table_name=None, orientation='H', formatting_type='STM_validation')


	# remove tmp sheet
	del tmp_wb['tmp']
	del tmp_wb['tmp_validation']
	del tmp_wb['helper']
	del tmp_wb['Txxxxxx']
	del tmp_wb['Walidacje_Txxxxx']
	del tmp_wb['template']

	# activate cell
	# tmp_wb["Lista tabel"].views.sheetView[0].selection[0].sqref = "B4"

	# save workbook
	tmp_wb.save(output_file_path)  # jeżeli błąd to zainstalować starszą wersję: pip install openpyxl-2.6.2
	
	# open file
	os.system(output_file_path) # development purpose only

# if __name__ == "__main__":
# 	generate_stm()
