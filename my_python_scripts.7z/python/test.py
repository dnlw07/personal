import pandas as pd

df = pd.read_csv(r"C:\Users\PZ006369\Desktop\bquxjob_7f2b5147_19229247e62.csv", delimiter=',', quoting=1, encoding='utf-8')
nested_list = df.values.tolist()

print(df)
print(nested_list)