import csv

# Input and output file paths
input_file = r"C:\Dane\Downloads\CH\CH_02_Wnioskowanie_20240802_02.csv"
output_file = r'C:\Dane\repo\python\Read_CSV\transposed_rows.csv'
row_num = 10
delimiter='|'



flie_path = Path(input_file)
file_name = flie_path.name

# Read the CSV file and extract the first 3 rows
with open(input_file, mode='r') as infile:
    reader = csv.reader(infile, delimiter=delimiter)
    rows = [next(reader) for _ in range(row_num)]

# Transpose the rows
transposed_rows = list(zip(*rows))

# Write the transposed rows to the output CSV file
with open(rf'C:\Dane\repo\python\parse_CSV\_output\transposed_rows_{file_name}.csv', mode='w', newline='') as outfile:
    writer = csv.writer(outfile)
    writer.writerows(transposed_rows)

print('\n\nDone!\n')
