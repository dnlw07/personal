import csv
import re
from datetime import datetime
import pandas as pd
from pathlib import Path
from unidecode import unidecode


def determine_data_type(value):
		try:
			if value[0] == '0' and not re.match(value, '.|,'): # handle leading zeros in strings
				raise ValueError
			else:
				int(value.strip())
				precision, scale = len(value), 0
				# return "integer", (precision, scale)
				return "integer", None
		except ValueError:
			try:
				if value[0] == '0' and not re.match(value, '.|,'): # handle leading zeros in strings
					raise ValueError
				else:
					float(value.replace(digit_separator, '.').strip())
					if digit_separator in value:
						precision, scale = len(value.replace(digit_separator, '').strip()), len(value.split(digit_separator)[1])
						return "decimal", (precision, scale)
					else:
						precision, scale = len(value.replace(digit_separator, '')), 0
						return "integer", None
			except ValueError:
				try:
					datetime.strptime(value.strip(), '%Y-%m-%d %H:%M:%S.%f %Z') # 2023-08-05 07:46:45.000000 UTC
					return "timestamp", "%Y-%m-%d %H.%M.%S.%f %Z"
				except ValueError:
					try:
						datetime.strptime(value.strip(), '%Y-%m-%d %H.%M.%S.%f')
						return "timestamp", "%Y-%m-%d %H.%M.%S.%f"
					except ValueError:
						try:
							datetime.strptime(value.strip(), '%Y-%m-%d %H:%M:%S:%f')
							return "timestamp", "%Y-%m-%d %H:%M:%S:%f"
						except ValueError:
							try:
								datetime.strptime(value.strip(), '%Y-%m-%d %H.%M.%S')
								return "timestamp", "%Y-%m-%d %H.%M.%S"
							except ValueError:
								try:
									datetime.strptime(value.strip(), '%Y-%m-%d %H:%M:%S')
									return "timestamp", "%Y-%m-%d %H:%M:%S"
								except ValueError:
									try:
										datetime.strptime(value.strip(), '%m/%d/%Y %I:%M:%S %p')
										return "timestamp", "%m/%d/%Y %I:%M %p"
									except ValueError:
										try:
											datetime.strptime(value.strip(), '%Y-%m-%d')
											return "date", "%Y-%m-%d"
										except ValueError:
											return "string", None


def analyze_sample_data(file_name):

	df = pd.read_csv(file_name, delimiter=column_separator, quoting=1, encoding=encoding)
	df = df.fillna('')
	header = df.columns.tolist()
	header = [unidecode(re.sub('_$','', colum_name)).replace('__', '_').strip().lower() for colum_name in header] # remove polish signs
	data_rows = df.values.tolist()

	# data_rows_2 = [str(value) for row in data_rows for value in row]
	# rows = sample_data.strip().split('\n') ## TODO: uwaga na pliki które zawierają nowe linie w stringach!
	# header = rows[0].split(column_separator)
	# data_rows = [row.split(column_separator) for row in rows[1:]]


	# check if each row has the same number of columns
	header_len = len(header)
	row_len_lst = [len(row) for row in data_rows]
	incorrect_row_num = [i + 2 for i, val in enumerate(row_len_lst) if val != header_len] # 2 --> header + index starting from 0
	incorrect_row_num_str = ', '.join(map(str, incorrect_row_num))
	if any(row_len != header_len for row_len in row_len_lst):
		print(f'WARNING! Plik ma różne ilości kolumn w rzędach: {incorrect_row_num_str}')


	column_analysis = []
	for col_idx, col_name in enumerate(header):
		column_data = [row[col_idx] for i, row in enumerate(data_rows) if len(row) == header_len]  # pomiń rzędy które mają inną liczbę kolumn niż nagłówek
		column_data_not_null = [value for value in column_data if value != '']
			
		if len(column_data_not_null) > 0:  # jeżeli kolumna z wartościami nie jest pusta
			input_max_length = max(len(str(item)) for item in column_data_not_null)
			# input_max_value = max(column_data_not_null)
			input_max_value = max(map(str, column_data_not_null), key=len)
			example_value = input_max_value

			col_type, col_detail = determine_data_type(str(input_max_value))

			if col_type == "decimal" and col_detail:
				precision, scale = col_detail
				if any(re.match(rf'\d+.\d+', str(value)) for value in column_data_not_null):
					input_max_scale = len(max([re.sub(rf'\d+\.', '', str(value)) for value in column_data_not_null]))
				else:
					input_max_scale = scale
				output_max_length = f'{precision},{input_max_scale}'
			else:
				precision, scale = None, None
				output_max_length = ''

			if col_type in ["date", "timestamp"]:
				date_mask = col_detail
			else:
				date_mask = None

			if output_max_length == '':
				output_max_length = input_max_length
		else:
			col_type = 'string'
			input_max_length = 'empty'
			output_max_length = 'empty'
			date_mask = ''
			example_value = 'empty'
			precision, scale = None, None

		column_analysis.append({
			"table_name": str(file_name.stem),
			"lp": col_idx + 1,
			"pk": "NIE",
			"column_name": col_name.lower(),
			"data_type": col_type.lower(),
			"data_length": input_max_length,
			"data_precision": precision,
			"data_scale": scale,
			"format": date_mask,
			"description": example_value,
			# "output_column_name": col_name.lower(),
			# "output_data_type": col_type.lower(),
			# "output_length": output_max_length,
			# "output_precision": precision,
			# "output_scale": scale,
			# "output_date_mask": date_mask,
			# TODO - add used values for analysis
		})

	return column_analysis


def write_analysis_to_csv(analysis, output_file):
	with open(output_file, 'w', newline='', encoding='utf8') as csvfile:
		# fieldnames = ['num', 'empty_col', 'input_column_name', 'input_data_type', 'input_length', 'output_column_name', 'output_data_type', 'output_length', 'output_date_mask']
		fieldnames = analysis[0].keys()
		writer = csv.DictWriter(csvfile, fieldnames=fieldnames, delimiter='\t')

		writer.writeheader()
		for col_analysis in analysis:
			writer.writerow(col_analysis)
		writer.writerow({'lp': ''})
		writer.writerow({'lp': ''})
		writer.writerow({'lp': ''})
		
		analysis_str = str(analysis).replace("[", "[\n").replace("]", "\n]").replace("}, ", "},\n")
		writer.writerow({'table_name': analysis_str})


# sample_data = """COS_ENTIDAD|COS_CENTRO_ALTA|COS_CUENTA|COS_COUNT|COS_AMOUNT_COS|COS_CURRENCY_COS|COS_RATE|COS_AMOUNT_ACC|COS_CURRENCY_ACC|COS_SUBPRODU_ACC|COS_CORASU_ACC|COS_STATUS|COS_REG_DATE|COS_OPER_CODE|COS_NUMER_MOV|COS_REG_DATE_ANU|COS_OPER_CODE_ANU|COS_NUMER_MOV_ANU|COS_ENTIDAD_AC|COS_CENTRO_ALTA_AC|COS_CUENTA_AC|COS_IND_AMORT|COS_IND1|COS_IND2|COS_IND_ACC_DEB|COS_AMOUNT1|COS_AMOUNT2|COS_AMOUNT3|COS_DATE1|COS_DATE2|COS_IND3|COS_IND4|COS_IND5|COS_IND6|COS_IND7|COS_IND8|COD_ENTIDAD_UMO|COS_CENTRO_UMO|COS_USERID_UMO|COS_NETNAME_UMO|COS_TIMEST_UMO
# 1020|1013|0200859280|00004| 0000000000015,56|PLN|001,000000| 0000000000015,56|PLN|1011|R2D|A|2023-02-13|986|000794184|0001-01-01|   |000000000|1020|1853|0202973345|N|U| |S| 0000000000477,00|0000001,00000000| 0000000000000,00|0001-01-01|0001-01-01|S|0|3|N| | |ZW09|ZW09|C0300369|P153    |2023-02-13-13.00.43.967780
# 1020|1013|0200859280|00001| 0000000000030,00|PLN|001,000000| 0000000000030,00|PLN|1011|R2D|N|2022-04-28|980|000650513|2022-05-23|600|000664214|1020|1853|0202973345|N|U| |S| 0000000000274,00|0000001,00000000| 0000000000000,00|0001-01-01|0001-01-01|W|0|7|N| | |ZW09|ZW09|XRPAUSR0|&R13    |2022-05-23-16.02.40.286656
# """



input_file = rf"C:\Dane\Downloads\sample_fiels\NEMO\zawieszenia_PG_20241030_01.csv"
column_separator = "|"
digit_separator = "."
encoding = 'cp1250'  # ['iso-8859-2','cp1250', 'utf-8']

flie_path = Path(input_file)
file_name = flie_path.stem

# with open(input_file, mode='r', encoding='utf-8') as file:
#     sample_data = file.read()

analysis = analyze_sample_data(flie_path)
write_analysis_to_csv(analysis, rf'C:\Dane\repo\python\parse_CSV\_output\inferred_schema_{file_name}.csv')
print('\n\nDone!\n')




