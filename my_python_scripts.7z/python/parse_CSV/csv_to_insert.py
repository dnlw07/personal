import pandas as pd
import numpy as np
from pathlib import Path
import chardet



########################################################################################################################
# CONTROL PANEL
########################################################################################################################

file_path = rf"C:\Users\PZ006369\Desktop\bquxjob_4aa04bd_192d766fc0b.csv"
schema_name = 'ada_516_pzkb_wr_data'
table_name = 't516002_fctd_sales_add'
add_tech_fields_flg = False
table_type = 'NON_SCD2'  # ['SDA', 'SCD2', 'NON_SCD2', 'EDA']
########################################################################################################################


# Tech fields values
due_dt = '2024-08-30'
start_dt = due_dt
end_dt = '9999-12-31'
sys_cd = 'CHIP'
tech_etl_pkg_cd = f'{sys_cd}_01'
extract_version = '01'
tech_is_active_flg = '1'
tech_insert_id = 0
tech_insert_ts = "CAST(CURRENT_DATETIME('Europe/Warsaw') AS TIMESTAMP)"

# Tech fields lists
sda_tech_fields_lst = ['due_dt', 'extract_version', 'sys_cd',  'tech_insert_id', 'tech_insert_ts']
nonscd2_tech_fields_lst = ['due_dt', 'sys_cd', 'tech_etl_pkg_cd', 'tech_insert_id', 'tech_insert_ts']
scd2_tech_fields_lst = ['start_dt', 'end_dt', 'sys_cd', 'tech_is_active_flg', 'tech_etl_pkg_cd', 'tech_insert_id', 'tech_insert_ts']
eda_tech_fields_lst = ['due_dt', 'extract_version', 'sys_cd', 'tech_etl_pkg_cd','tech_insert_id', 'tech_insert_ts']

# Select tech fields list based on table type
if table_type == 'SDA':
    tech_fields_lst = sda_tech_fields_lst
elif table_type == 'NON_SCD2':
    tech_fields_lst = nonscd2_tech_fields_lst
elif table_type == 'SCD2':
    tech_fields_lst = scd2_tech_fields_lst
elif table_type == 'EDA':
    tech_fields_lst = eda_tech_fields_lst
else:
    tech_fields_lst = []



# Detect encoding
with open(file_path, 'rb') as rawdata:
    result = chardet.detect(rawdata.read(10000))
corrected_encoding = 'ISO-8859-2' if result['encoding'] == 'ISO-8859-1' else result['encoding']

# Open file
df = pd.read_csv(file_path, delimiter=',', encoding=corrected_encoding)

# Add technical fields to DataFrame if the flag is True
if add_tech_fields_flg:
    tech_values = {
        'due_dt': due_dt,
        'start_dt': start_dt,
        'end_dt': end_dt,
        'sys_cd': sys_cd,
        'tech_etl_pkg_cd': tech_etl_pkg_cd,
        'tech_is_active_flg': tech_is_active_flg,
        'tech_insert_id': tech_insert_id,
        'tech_insert_ts': tech_insert_ts,
        'extract_version': extract_version 
    }
    # Insert technical fields as new columns at the start of the DataFrame
    for field in reversed(tech_fields_lst):
        df.insert(0, field, tech_values[field])

# Initialize a list to store insert statements
insert_statements = []

# Loop through each row in the DataFrame
for index, row in df.iterrows():
    value_lst = ["'{}'".format(str(value).replace("'", "''").replace("\\", "\\\\").replace("\r\n", "\\n")) if not (isinstance(value, int) or isinstance(value, float)) else str(value) for value in row.values]
    value_lst = ['null' if value == 'nan' else value for value in value_lst]
    value_lst = [value[1:-1].replace("''", "'") if 'CAST' in value else value for value in value_lst] # remove bracekts from start and end
    values = ', '.join(value_lst)
    
    # Create the insert statement
    insert_statement = f"INSERT INTO {schema_name}.{table_name} ({', '.join(df.columns)}) VALUES ({values});"
    insert_statements.append(insert_statement)

flie_path = Path(file_path)
file_name = flie_path.stem

# Output the statements to a file
with open(rf'C:\Dane\repo\python\parse_CSV\_output\insert_statements_{file_name}.sql', 'w', encoding='UTF-8') as f:
    for statement in insert_statements:
        f.write(statement + '\n')

print('\n\nDone!\n')

