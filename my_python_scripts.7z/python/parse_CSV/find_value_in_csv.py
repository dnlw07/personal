import pandas as pd
import chardet

file_path = r"C:\Users\PZ006369\Desktop\bquxjob_7f2b5147_19229247e62.csv"

# Define the value to search for
search_value = '01,01'


with open(file_path, 'rb') as rawdata:
	result = chardet.detect(rawdata.read(10000))


corrected_endcoding = 'ISO-8859-2' if result['encoding'] == 'ISO-8859-1' else result['encoding']
df = pd.read_csv(file_path, delimiter=',', header=0, encoding='ISO-8859-2')


print(df)
df.info()



# Go through each column to check if it contains the value
for column in df.columns:
	if df[column].eq(search_value).any():
		print(f"The value '{search_value}' is found in column: {column}")
	else:
		pass
		# print(f"The value '{search_value}' is not found in column: {column}")


