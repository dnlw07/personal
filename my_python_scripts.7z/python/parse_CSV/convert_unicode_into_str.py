# covnerst Unicode characters into actual signs (ex. \u003d into '=' etc.)

# unicode string
sql_str = u'''
(?:(?:FROM|JOIN)\s+?)[\x60\[]?(?:(?P<project>[\w][-\w]+?)\x60?[\:\.])?\x60?(?P<dataset>[\w]+?)\x60?\.\x60?(?P<table>[\w]+)[\x60\]]?(?:\s|$)
'''


# covnert unicode into python string
fixed_sql_str = str(sql_str)


print(f'\n\n{fixed_sql_str}\n\n')