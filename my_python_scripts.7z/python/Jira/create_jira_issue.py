import requests
import json
import time


#########################################################################################################################
# CONTROL PANEL 
#########################################################################################################################
pakcage_name = 'GCP-IDA_IPKO-04.01'
description = 'Paczka poprawkoa IDA. Dodanie DISTINCT do procedury, zdjęcie walidacji PK oraz zdjęcie corssdep dla tabeli t429044_ipko_login oraz zdwiększenie długości pola do 8000 znaków dla tabeli t429043_ipko_activity.'
installation_condition = 'brak'
anow_objects = 'tak'
after_installation = 'nie' 
# UWAGI!
	# - zdjęcie flag pass by w schedulerze 'NAZWA_SCHEDULERA'
	# - jeżeli dojdzie do aktualizacji obiektów ANOW to: jeżeli obecnie istniejąca instancja obietku 'NAZWA_WFL*' została już uruchomiona to należy ją zatrzymać i uruchomić ponownie po instalacji paczki
#########################################################################################################################


# JIRA instance URL
jira_url = 'https://jira.pkobp.pl'

# Your access token
access_token = 'KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1'

# Your JIRA email
email = 'daniel.wisniewski.2@pkobp.pl'


# Set up headers with Basic Auth using the access token
headers = {
	'Authorization': f'Bearer {access_token}',
	'Content-Type': 'application/json'
}



#########################################################################################################################
# CREATE NEW ISSUE
#########################################################################################################################

# Issue key of the original issue
# issue_key = 'OHIORM-3390'

# Test connection by getting the current user information
# response = requests.get(f'{jira_url}/rest/api/2/issue/{issue_key}', headers=headers, verify=False)

# if response.status_code == 200:
#     original_issue = response.json()
#     print("Original issue details fetched successfully!")
#     print(original_issue)

	# Step 2: Create a new issue using the fetched details
	# fields_to_remove = ['id', 'key', 'self', 'created', 'updated', 'status', 'resolution']
	# issue_data = original_issue['fields']
	# for field in fields_to_remove:
	#     issue_data.pop(field, None)

	# Adjust some fields as necessary
	# issue_data['summary'] = f"Cloned: {issue_data['summary']}"

issue_data = f"""
{{
	"fields": {{

		"assignee": {{
			"name": "PZ006369",
			"key": "JIRAUSER124211",
			"displayName": "Wiśniewski Daniel 2 (EXT)"
		}},
		"customfield_15051": 50.0,
		"issuetype": {{
			"id": "12703",
			"description": "",
			"iconUrl": "https://jira.pkobp.pl/secure/viewavatar?size=xsmall&avatarId=10311&avatarType=issuetype",
			"name": "Paczka wdrożeniowa",
			"subtask": false,
			"avatarId": 10311
		}},
		"timetracking": {{}},
		"customfield_11504": [
			{{
				"name": "PZ006369",
				"key": "JIRAUSER124211",
				"displayName": "Wiśniewski Daniel 2 (EXT)"
			}}
		],
		"labels": [],
		"components": [],
		"project": {{
			"id": "16835",
			"key": "OHIORM",
			"name": "OHIO RM",
			"projectTypeKey": "software",
			"projectCategory": {{
				"id": "10701",
				"description": "",
				"name": "Projekty DID"
			}}
		}},
		"description": "1. Opis zmian: {description} \\n2. Warunki instalacji: {installation_condition}\\n3. Czynności do wykonania po instalacji: {after_installation}\\n4. Nowe obiekty w ANOW: {anow_objects}\\n5. Środowiska instalacji: TST1, PR\\n6. Dodatkowe informacje: brak\\n7. Termin instalacji (Data i godzina): Zgodnie z wydaniem",
		"summary": "{pakcage_name}",
		"fixVersions": [],
		"customfield_16309": {{
			"value": "Niskie",
			"id": "17105",
			"disabled": false
		}},
		"customfield_16303": "https://code.pkobp.pl/ohio/INSTALL/-/tree/master/GCP/{pakcage_name}",
		"customfield_16305": {{
			"value": "PROD",
			"id": "17104",
			"disabled": false
		}},
		"customfield_24902": "APL-30823"
	}}
}}
"""

# print(issue_data)
json_data = json.loads(issue_data)

# Create a new issue
response = requests.post(f'{jira_url}/rest/api/2/issue', headers=headers, data=json.dumps(json_data), verify=False)

if response.status_code == 201:
	new_issue = response.json()
	issue_key = new_issue['key']
	print("\n\nIssue created successfully!")
	print(f"New issue: https://jira.pkobp.pl/browse/{issue_key}")
else:
	print(f"Failed to create issue: {response.status_code}")
	print(response.text)
# else:
#     print(f"Failed to fetch issue: {response.status_code}")
#     print(response.text)
	

#########################################################################################################################
# CHANGE STATUS
#########################################################################################################################
# issue_key = 'OHIORM-3553'

transition_lst = ['71','101','111']

for transition_id in transition_lst:

	# Change status
	
	transition_data = {"transition": {"id": transition_id}}
	transition_url = f'{jira_url}/rest/api/2/issue/{issue_key}/transitions'
	response = requests.post(transition_url, headers=headers, data=json.dumps(transition_data), verify=False)
	time.sleep(1)

	# Print the response for transitioning issue
	if response.status_code == 204:
		print("Issue transitioned successfully!")
	else:
		print(f"Failed to transition issue: {response.status_code}")
		print(response.text)



#########################################################################################################################
# ADD COMMENT
#########################################################################################################################

# Comment data
comment_data = {"body": "Zainstalowano na T1"}

# Send the POST request to add the comment
response = requests.post(f'{jira_url}/rest/api/2/issue/{issue_key}/comment', headers=headers, data=json.dumps(comment_data), verify=False)

# Print the response
if response.status_code == 201:
	print("Comment added successfully!")
	# print(response.json())
else:
	print(f"Failed to add comment: {response.status_code}")
	print(response.text)


print(f"\n\n\nNew issue: https://jira.pkobp.pl/browse/{issue_key}\n\n")



## curl "https://jira.pkobp.pl/rest/api/2/myself" -H "Authorization: Bearer KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1"
## curl "https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3559" -H "Authorization: Bearer KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1"
## curl "https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3390/transitions" -H "Authorization: Bearer KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1"


# https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3481
# https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3708
# https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3710
# https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3711

