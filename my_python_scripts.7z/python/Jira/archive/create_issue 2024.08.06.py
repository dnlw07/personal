import requests
import json
import time


#########################################################################################################################
# CONTROL PANEL 
#########################################################################################################################
pakcage_name = 'GCP-SDA_DIGM-01.01'
description = 'Aktualizacja wpisu w metadanych'
installation_condition = 'brak'
anow_objects = 'nie'
after_installation = 'nie'
#########################################################################################################################


# JIRA instance URL
jira_url = 'https://jira.pkobp.pl'

# Your access token
access_token = 'KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1'

# Your JIRA email
email = 'daniel.wisniewski.2@pkobp.pl'


# Set up headers with Basic Auth using the access token
headers = {
	'Authorization': f'Bearer {access_token}',
	'Content-Type': 'application/json'
}



#########################################################################################################################
# CREATE NEW ISSUE
#########################################################################################################################

# Issue key of the original issue
# issue_key = 'OHIORM-3390'

# Test connection by getting the current user information
# response = requests.get(f'{jira_url}/rest/api/2/issue/{issue_key}', headers=headers, verify=False)

# if response.status_code == 200:
#     original_issue = response.json()
#     print("Original issue details fetched successfully!")
#     print(original_issue)

	# Step 2: Create a new issue using the fetched details
	# fields_to_remove = ['id', 'key', 'self', 'created', 'updated', 'status', 'resolution']
	# issue_data = original_issue['fields']
	# for field in fields_to_remove:
	#     issue_data.pop(field, None)

	# Adjust some fields as necessary
	# issue_data['summary'] = f"Cloned: {issue_data['summary']}"

issue_data = f"""
{{
	"fields": {{

		"assignee": {{
			"name": "PZ006369",
			"key": "JIRAUSER124211",
			"displayName": "Wiśniewski Daniel 2 (EXT)"
		}},
		"customfield_15051": 50.0,
		"issuetype": {{
			"id": "12703",
			"description": "",
			"iconUrl": "https://jira.pkobp.pl/secure/viewavatar?size=xsmall&avatarId=10311&avatarType=issuetype",
			"name": "Paczka wdrożeniowa",
			"subtask": false,
			"avatarId": 10311
		}},
		"timetracking": {{}},
		"customfield_11504": [
			{{
				"name": "H0800413",
				"key": "h0800413",
				"displayName": "Borowiński Marek"
			}},
			{{
				"name": "H0800414",
				"key": "h0800414",
				"displayName": "Cader Maciej"
			}},
			{{
				"name": "H0800415",
				"key": "h0800415",
				"displayName": "Daniecki Adam"
			}},
			{{
				"name": "PZ001622",
				"key": "JIRAUSER88241",
				"displayName": "Leśniewski Emil (EXT)"
			}},
			{{
				"name": "H0800441",
				"key": "h0800441",
				"displayName": "Sienkiewicz Krzysztof"
			}},
			{{
				"name": "S1603933",
				"key": "s1603933",
				"displayName": "Ślesicki Wojciech"
			}},
			{{
				"name": "PZ006369",
				"key": "JIRAUSER124211",
				"displayName": "Wiśniewski Daniel 2 (EXT)"
			}}
		],
		"labels": [],
		"components": [],
		"project": {{
			"id": "16835",
			"key": "OHIORM",
			"name": "OHIO RM",
			"projectTypeKey": "software",
			"projectCategory": {{
				"id": "10701",
				"description": "",
				"name": "Projekty DID"
			}}
		}},
		"description": "1. Opis zmian: {description} \\n2. Warunki instalacji: {installation_condition}\\n3. Czynności do wykonania po instalacji: {after_installation}\\n4. Nowe obiekty w ANOW: {anow_objects}\\n5. Środowiska instalacji: TST1, PR\\n6. Dodatkowe informacje: brak\\n7. Termin instalacji (Data i godzina): Zgodnie z wydaniem",
		"customfield_11103": {{
			"name": "gwappmlops"
		}},
		"summary": "{pakcage_name}",
		"fixVersions": [],
		"customfield_16309": {{
			"value": "Niskie",
			"id": "17105",
			"disabled": false
		}},
		"customfield_16303": "https://code.pkobp.pl/ohio/INSTALL/-/tree/master/GCP/{pakcage_name}",
		"customfield_16305": {{
			"value": "PROD",
			"id": "17104",
			"disabled": false
		}},
		"customfield_24902": "APL-30823"
	}}
}}
"""

# print(issue_data)

json_data = json.loads(issue_data)

# Create a new issue
response = requests.post(f'{jira_url}/rest/api/2/issue', headers=headers, data=json.dumps(json_data), verify=False)

if response.status_code == 201:
	new_issue = response.json()
	issue_key = new_issue['key']
	print("\n\nIssue cloned successfully!")
	print(f"New issue: https://jira.pkobp.pl/browse/{issue_key}")
else:
	print(f"Failed to create issue: {response.status_code}")
	print(response.text)
# else:
#     print(f"Failed to fetch issue: {response.status_code}")
#     print(response.text)
	

#########################################################################################################################
# CHANGE STATUS
#########################################################################################################################
# issue_key = 'OHIORM-3553'

transition_lst = ['71','101','111']

for transition_id in transition_lst:

	# Change status
	
	transition_data = {"transition": {"id": transition_id}}
	transition_url = f'{jira_url}/rest/api/2/issue/{issue_key}/transitions'
	response = requests.post(transition_url, headers=headers, data=json.dumps(transition_data), verify=False)
	time.sleep(1)

	# Print the response for transitioning issue
	if response.status_code == 204:
		print("Issue transitioned successfully!")
	else:
		print(f"Failed to transition issue: {response.status_code}")
		print(response.text)



#########################################################################################################################
# ADD COMMENT
#########################################################################################################################

# Comment data
comment_data = {"body": "Zainstalowano na T1"}

# Send the POST request to add the comment
response = requests.post(f'{jira_url}/rest/api/2/issue/{issue_key}/comment', headers=headers, data=json.dumps(comment_data), verify=False)

# Print the response
if response.status_code == 201:
	print("Comment added successfully!")
	print(response.json())
else:
	print(f"Failed to add comment: {response.status_code}")
	print(response.text)



## curl "https://jira.pkobp.pl/rest/api/2/myself" -H "Authorization: Bearer KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1"
## curl "https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3559" -H "Authorization: Bearer KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1"
## curl "https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3390/transitions" -H "Authorization: Bearer KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1"


https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3481
https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3708
