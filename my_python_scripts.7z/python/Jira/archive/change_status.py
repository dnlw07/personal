import requests
import json

# JIRA instance URL
jira_url = 'https://jira.pkobp.pl'

# Your access token
access_token = 'KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1'

# Your JIRA email
email = 'daniel.wisniewski.2@pkobp.pl'

# Issue key of the original issue
issue_key = 'OHIORM-3481'

# Set up headers with Basic Auth using the access token
headers = {
    'Authorization': f'Bearer {access_token}',
    'Content-Type': 'application/json'
}

# Step 1: Get available transitions for the issue
# transition_url = f'{jira_url}/rest/api/2/issue/{issue_key}/transitions'
# response = requests.get(f'{transition_url}', headers=headers, verify=False)


# if response.status_code == 200:
#     transitions = response.json()
#     print("Available transitions fetched successfully!")
#     print(json.dumps(transitions, indent=2))
    
    # Choose a transition ID (replace with the actual ID from the available transitions)
    # transition_id = '71' # 71 - READY FOR TESTING
    # transition_id = '101' # 101 - IN TEST
    # transition_id = '111' # 111 - TEST COMPLETED

transition_lst = ['71','101','111']

for transition_id in transition_lst:
    # Step 2: Transition the issue
    transition_data = {"transition": {"id": transition_id}}

    # Send the POST request to transition the issue
	transition_url = f'{jira_url}/rest/api/2/issue/{issue_key}/transitions'
    response = requests.post(transition_url, headers=headers, data=json.dumps(transition_data), verify=False)

    # Print the response for transitioning issue
    if response.status_code == 204:
        print("Issue transitioned successfully!")
    else:
        print(f"Failed to transition issue: {response.status_code}")
        print(response.text)

# else:
#     print(f"Failed to fetch transitions: {response.status_code}")
#     print(response.text)


## curl "https://jira.pkobp.pl/rest/api/2/issue/OHIORM-3481/transitions" -H "Authorization: Bearer KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1"

