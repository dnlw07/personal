import requests

# JIRA instance URL
jira_url = 'https://jira.pkobp.pl'

# Your access token
access_token = 'KMkTaEnfaKP0R2XG1futbhI5iYuVNmu3AGaWc1'

# Your JIRA email
email = 'daniel.wisniewski.2@pkobp.pl'

# Set up headers with Basic Auth using the access token
headers = {
    'Authorization': f'Basic {access_token}',
    'Content-Type': 'application/json'
}

# Test connection by getting the current user information
response = requests.get(f'{jira_url}/rest/api/2/myself', headers=headers, verify=False)

if response.status_code == 200:
    print("Connection successful!")
    print(response.json())
else:
    print(f"Failed to connect: {response.status_code}")
    print(response.text)
    

