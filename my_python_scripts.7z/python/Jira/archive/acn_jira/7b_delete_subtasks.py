""" 
create subtasks in JIRA
"""

from atlassian.jira import Jira


####################################
# CONTROL PANEL
jira_key = 'DAQASC-3751'
####################################

project_key = 'DAQASC'

jira = Jira(url='https://atc.bmwgroup.net/jira/', username='QXZ1O3D', password='czarymaryhokuspokus', verify_ssl=False)


sub_task_name = jira.issue(jira_key)['fields']['summary']
# print(sub_task_name)

if sub_task_name == 'delete me':
    status = jira.delete_issue(jira_key)
