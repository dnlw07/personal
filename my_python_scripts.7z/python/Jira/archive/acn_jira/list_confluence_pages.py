    # %%
import os
from atlassian import Confluence
from bs4 import BeautifulSoup
import csv
from pprint import pprint
from configparser import ConfigParser, ExtendedInterpolation
import json

output_csv_path = r'C:\Dane\VSCRepo\python\confluence\input\confluence_pages.csv'

config = ConfigParser()
config.read_file(open('C:\Dane\VSCRepo\python\confluence\config.ini'))
# page_title = config['OBJECT_NAME']['tgt_name']
page_title = 'Spare Parts Warehouse Locations'
# page_title = 'Data Assets in Impact'

space = 'DETOX'

confluence = Confluence(url='https://atc.bmwgroup.net/confluence/', username='QXZ1O3D', password='czarymaryhokuspokus', verify_ssl=False)


# check if page exists
status = confluence.page_exists(space, title=page_title)
print(status)

# get page id
page_id = confluence.get_page_id(space=space, title=page_title)
print(page_id)

page_dct = confluence.get_page_child_by_type(page_id, type='page', start=None, limit=500)
print(page_dct)

child_page_id_lst = [elem['id'] for elem in page_dct]
child_page_lst = [f"{elem['title']}, {elem['_links']['webui']}" for elem in page_dct]

# grand child pages
grandchild_page_lst = []
grandchild_page_id_lst = []
for page_id in child_page_id_lst:
    page_dct = confluence.get_page_child_by_type(page_id, type='page', start=None, limit=500)
    grandchild_page_id_lst.extend([elem['id'] for elem in page_dct])
    grandchild_page_lst.extend([f"{elem['title']}, {elem['_links']['webui']}" for elem in page_dct])

# grand grand child pages
grand_grandchild_page_lst = []
for page_id in grandchild_page_id_lst:
    page_dct = confluence.get_page_child_by_type(page_id, type='page', start=None, limit=500)
    grand_grandchild_page_lst.extend([f"{elem['title']}, {elem['_links']['webui']}" for elem in page_dct])

child_page_lst.extend(grandchild_page_lst)
child_page_lst.extend(grand_grandchild_page_lst)

with open(output_csv_path, 'w', encoding='utf-8') as f:
    f.write("\n".join(child_page_lst))

# curl -u QXZ1O3D:czarymaryhokuspokus -X GET "https://atc.bmwgroup.net/confluence/rest/api/content/1398067054/descendant" | python -mjson.tool




