""" 
create subtasks in JIRA
"""

from re import match, sub
import os
from atlassian import Confluence
from atlassian.jira import Jira
from bs4 import BeautifulSoup
import csv
from pprint import pprint
from configparser import ConfigParser, ExtendedInterpolation


####################################
# CONTROL PANEL
new_process_flg = False # True - add substasks according to new short process, False - add tasks according the old longer process
test_flg = True # check if substask will be added as planned
# test_flg = False # add subtasks
####################################


# TODO choose what to include




config = ConfigParser()
config.read_file(open('C:\Dane\VSCRepo\python\confluence\config.ini'))
# jira_epic_key = config['JIRA']['jira_epic_key']
jira_epic_key = 'DAQASC-2812'
project_key = 'DAQASC'


jira = Jira(url='https://atc.bmwgroup.net/jira/', username='QXZ1O3D', password='czarymaryhokuspokus', verify_ssl=False)

if new_process_flg:
    setup_subtask_name_lst = []
    # setup_subtask_name_lst = []

    dev_subtask_name_lst = []
    dev_subtask_name_lst = [
        'Update specifications in the appropriate confluence space',
        'Sync Tables',
        'Sync Tables - Schedules',
        'Sync Tables - Health Checks',
        'Sync Tables - Xray test',
        'Sync Tables - ITSM ticket',
        'Code Implementation with specified requirements and business logic - Working Space',
        'Code Implementation - Partition to Semantic Layer',
        'Build of tables in Working Space and Semantic Layer'
    ]

    test_subtask_name_lst = []
    test_subtask_name_lst = [
        'Create Xray test',
        'Execute tests from the Xray ticket',
        'Update PR with Xray Testing link',
        'Code Review with Joerg',
        'Send PR to Data Steward to merge to master',
        'Merge branch to Master has been completed',
        'ITSM ticket creation and approval'
    ]

    # not needed - leave empty
    prod_subtask_name_lst = []
    # prod_subtask_name_lst = []


    golive_subtask_name_lst = []
    golive_subtask_name_lst = [
        'Build table in master',
        'Update Build Schedule',
        'Update Lineage Documentation',
        'Apply Health Checks',
        'Apply BMW AG Security Marking',
        'Update Confluence Page Specifications',
        'Create Handover Documentation',
        'Handover to Accenture Ops has been conducted and recording attached'
    ]


else:
    setup_subtask_name_lst = []
    setup_subtask_name_lst = [
        'Identify if the Data Asset Working Space and the Semantic Layer project folders have been created and accessible in impact',
        'Create Technical Specifications and Functional/Non Functional documentation pages in DTO',
        'Set up structure of folders Working Space & Semantic Layer',
        'XRay test to document correct structure',
        'Code Review with Data Steward to ensure correct structure',
        'Send Documentation Review for Technical and Functional Specifications',
        'Create Lineage documentation'
    ]

    dev_subtask_name_lst = []
    dev_subtask_name_lst = [
        'Update specifications in the appropriate confluence space'
        'Sync Tables'
        'Code Implementation with specified requirements and business logic - Working Space'
        'Code Implementation - Partition to Semantic Layer'
    ]

    test_subtask_name_lst = []
    test_subtask_name_lst = [
        'Xray Test - Test Code Implementation (Semantic Layer)',
        'Create Pull Request',
        'ITSM ticket creation and approval',
        'Code Review with colleagues and data steward',
        'Request PR be merged to master branch by the Data Steward',
        'Update Confluence Page Specifications',
        'Create lineage documentation and update schedules',
        'Data Health Checks implemented'
    ]

    prod_subtask_name_lst = []
    prod_subtask_name_lst = [
        'Document specifications in the appropriate confluence space',
        'Sync PROD table from ILAS Data Warehouse',
        'Apply Health Checks',
        'Update input path on Working Space',
        'Code Implementation - Remove testing fields (if needed)',
        'Xray Test - Test Code Implementation on Semantic Layer',
        'Create Pull Request',
        'ITSM ticket creation and approval'
    ]

    golive_subtask_name_lst = []
    golive_subtask_name_lst = [
        'Code Review with Joerg',
        'Request PR be merged to master branch by the Data Steward',
        'Update Lineage Documentation',
        'Build schedule',
        'Decommission the Syncs of the ILAS INT source table',
        'Update Confluence Page Specifications',
        'Apply BMW AG Security Marking',
        'Documentation for Handover to ACN OPS',
        'Handover to ACN OPS (meeting)'
    ]


subtask_name_lst = [setup_subtask_name_lst, dev_subtask_name_lst, test_subtask_name_lst, prod_subtask_name_lst, golive_subtask_name_lst]


# Check if in epic exits task with names Development and Set up
jql_request = f'issue in childIssuesOf ({jira_epic_key})'
data = jira.jql(jql_request)


# Create task list of given epic
task_hierarchy_lst = []
for issue in data['issues']:
    task_hierarchy_lst.append((issue['key'], issue['fields']['summary']))


# Get Development and Set up task keys
task_key_lst = []
for issue in task_hierarchy_lst:
    if match('.*Set Up Project Folders.*', issue[1]):
        setup_task_key = issue[0]
    elif match('.*Develop.*', issue[1]):
        dev_task_key = issue[0]
    elif match('.*Test and Integrate.*', issue[1]):
        test_task_key = issue[0]
    elif match('.*Prod Data Pipeline.*', issue[1]):
        prod_task_key = issue[0]
    elif match('.*Go Live on Prod.*', issue[1]):
        golive_task_key = issue[0]

task_key_lst = [setup_task_key, dev_task_key, test_task_key, prod_task_key, golive_task_key] 


assert len(task_key_lst) == len(subtask_name_lst)


subtask_dct = {}
for key, name_lst in zip(task_key_lst, subtask_name_lst):
    subtask_dct[key] = name_lst
# pprint(subtask_dct)


# create sub-task if not exist yet
for parent_key, subtask_name_lst in subtask_dct.items():
    task = jira.issue(parent_key)
    if not task['fields']['subtasks']: # Check if the tasks already contain subtasks
        for subtask_name in subtask_name_lst:
            fields = {
                'project': {'key': project_key},
                'issuetype': {'name': 'Sub-task'},
                'parent': {'key': parent_key},
                'summary': subtask_name,
                'description': subtask_name,
                'assignee': {'name': 'qxz1o3d'}
            }
            if test_flg:
                print(f'{parent_key}, {subtask_name}') # for testing purpose
            else:
                status = jira.issue_create(fields) # uncomment after positive test
                pass
    else:
        print(f'\n{parent_key}, don\'t create sub-tasks\n')



# # Set issue status
# jira.set_issue_status(issue_key, status_name, fields=None)

# # Get issue status
# jira.get_issue_status(issue_key)
