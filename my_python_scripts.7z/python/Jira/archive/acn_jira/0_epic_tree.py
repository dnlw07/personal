import os
from re import match, sub
from copy import Error
from atlassian import Jira
from pprint import pprint
from treelib import Tree
from configparser import ConfigParser, ExtendedInterpolation


config = ConfigParser()
config.read_file(open('C:\Dane\VSCRepo\python\confluence\config.ini'))

# jira_epic_key = 'DAQASC-2152'
jira_epic_key = config['JIRA']['jira_epic_key']
jql_request = f'issue in childIssuesOf ({jira_epic_key})'


jira = Jira(url='https://atc.bmwgroup.net/jira/', username='QXZ1O3D', password='czarymaryhokuspokus', verify_ssl=False)

data = jira.jql(jql_request)

epic_name = jira.issue(jira_epic_key)['fields']['summary']
print(epic_name)

output_path = f'C:\\Dane\\VSCRepo\\python\\confluence\\output\\epic_tree - {epic_name}.txt'

# dict is only to keep the correct order (not working)
task_hierarchy_dct = {}
task_hierarchy_dct['Go Live'] = ()
task_hierarchy_dct['Requirements'] = ()
task_hierarchy_dct['Set Up'] = ()
task_hierarchy_dct['Develop'] = ()
task_hierarchy_dct['Test and Integrate'] = ()
task_hierarchy_dct['Prod Data'] = ()

for issue in data['issues']:
    status = issue['fields']['status']['statusCategory']['name']
    try:
        task_hierarchy_dct[issue['key']] = (f"{issue['key']} - {issue['fields']['summary'].strip()} - {status}", issue['key'], issue['fields']['parent']['key'])
    except KeyError:
        if match('Requirements Engineering.*', issue['fields']['summary'].strip()):
            task_hierarchy_dct['Requirements'] = (f"1. {issue['key']} - {issue['fields']['summary'].strip()} - {status}", issue['key'], jira_epic_key)
        elif match('Set Up Project.*', issue['fields']['summary'].strip()):
            task_hierarchy_dct['Set Up'] = (f"2. {issue['key']} - {issue['fields']['summary'].strip()} - {status}", issue['key'], jira_epic_key)
        elif match('Develop.*', issue['fields']['summary'].strip()):
            task_hierarchy_dct['Develop'] = (f"3. {issue['key']} - {issue['fields']['summary'].strip()} - {status}", issue['key'], jira_epic_key)
        elif match('Test and Integrate.*', issue['fields']['summary'].strip()):
            task_hierarchy_dct['Test and Integrate'] = (f"4. {issue['key']} - {issue['fields']['summary'].strip()} - {status}", issue['key'], jira_epic_key)
        elif match('Prod Data Pipeline.*', issue['fields']['summary'].strip()):
            task_hierarchy_dct['Prod Data'] = (f"5. {issue['key']} - {issue['fields']['summary'].strip()} - {status}", issue['key'], jira_epic_key)
        elif match('Go( |-)Live on Prod.*', issue['fields']['summary'].strip()):
            task_hierarchy_dct['Go Live'] = (f"6. {issue['key']} - {issue['fields']['summary'].strip()} - {status}", issue['key'], jira_epic_key)
        else:
            # raise Exception(f"\"{issue['fields']['summary'].strip()}\" - Jira name does not fit to regex match patterns")
            print(f"\"{issue['fields']['summary'].strip()}\" - Jira name does not fit to regex match patterns")



# generate graph
tree = Tree()
tree.create_node(f'{jira_epic_key} - {epic_name}', jira_epic_key)
for key, args in task_hierarchy_dct.items():
    tree.create_node(*args)
    # for key, args in task_hierarchy_dct.items():
        # try:
            # tree.create_node(*args)
            # break
        # except:
            # continue

print('')
tree.show()


if os.path.exists(output_path):
    os.remove(output_path)

tree.save2file(output_path)



with open(output_path, 'r', encoding='utf-8') as f:
    mystring = f.read()
tree_lst = mystring.split('\n')

# modify text file
tree_lst_2 = []
for line in tree_lst:
    if match('.*In Progress.*', line):
        line = sub(' - In Progress', '', line)
        line = f'?\t{line}'
        tree_lst_2.append(line)
    elif match('.*To.* Do.*', line):
        line = sub(' - To Do', '', line)
        line = f'☐\t{line}'
        tree_lst_2.append(line)
    elif match('.*Done.*', line):
        line = sub(' - Done', '', line)
        line = f'✔\t{line}'
        tree_lst_2.append(line)
    else:
        tree_lst_2.append(line)


with open(output_path, 'w', encoding='utf-8') as f:
    f.write('\n'.join(tree_lst_2))

# print(tree_lst_2)


