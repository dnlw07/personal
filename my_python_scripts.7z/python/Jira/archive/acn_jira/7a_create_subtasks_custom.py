""" 
create subtasks in JIRA
"""

from re import match, sub
import os
from atlassian import Confluence
from atlassian.jira import Jira
from bs4 import BeautifulSoup
import csv
from pprint import pprint
from configparser import ConfigParser, ExtendedInterpolation



####################################
# CONTROL PANEL
new_process_flg = False # True - add substasks according to new short process, False - add tasks according the old longer process
test_flg = False # check if substask will be added as planned
# test_flg = False # add subtasks
####################################


# TODO choose what to include


config = ConfigParser()
config.read_file(open('C:\Dane\VSCRepo\python\confluence\config.ini'))
# jira_epic_key = config['JIRA']['jira_epic_key']
# jira_epic_key = 'DAQASC-2812'


jira_key = 'DAQASC-4653'
project_key = jira_key.split('-')[0]
print(project_key)
# project_key = 'DAQASC'


subtask_name_lst = [
"Meet with the data stewards and discuss the current state of the data asset",
"Identify if component tables are available in CDH or impACT!",
"Update Implementation Requirements page in confluence for data asset",
"Update and complete all fields in Data Asset definition page on confluence",
"Update Functional Specifications",
"Obtain signoff on the requirements confluence page"
]



jira = Jira(url='https://atc.bmwgroup.net/jira/', username='QXZ1O3D', password='czarymaryhokuspokus', verify_ssl=False)



# create sub-task if not exist yet
for subtask_name in subtask_name_lst:
    fields = {
        'project': {'key': project_key},
        'issuetype': {'name': 'Sub-task'},
        'parent': {'key': jira_key},
        'summary': subtask_name,
        'description': subtask_name,
        'assignee': {'name': 'qxz1o3d'}
    }
    if test_flg:
        print(f'TEST: {jira_key}, {subtask_name}') # for testing purpose
    else:
        status = jira.issue_create(fields) # uncomment after positive test
        pass




# # Set issue status
# jira.set_issue_status(issue_key, status_name, fields=None)

# # Get issue status
# jira.get_issue_status(issue_key)
