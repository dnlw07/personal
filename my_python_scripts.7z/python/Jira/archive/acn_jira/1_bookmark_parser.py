'''
generates csv file with links taken from bookmarks
'''

# from pprint import pprint
from bs4 import BeautifulSoup
from configparser import ConfigParser, ExtendedInterpolation
from pprint import pprint

config = ConfigParser()
config.read_file(open('C:\Dane\VSCRepo\python\confluence\config.ini'))

temp_tgt_name = config['OBJECT_NAME']['temp_tgt_name']
tgt_name = config['OBJECT_NAME']['tgt_name']

# temp_tgt_name = 'Spare Parts Orders'
# tgt_name = 'Spare Parts Deliveries'

input_html_path = r'C:\Users\daniel.wisniewski\Downloads\bookmarks.html'
output_csv_path = r'C:\Dane\VSCRepo\python\confluence\input\links.csv'


with open(input_html_path, 'r') as html_text:
    soup = BeautifulSoup(html_text, 'lxml')

old_story_folder = [h3 for h3 in soup.find_all('h3') if temp_tgt_name in h3.string][0]
old_bookmarks = old_story_folder.parent.next_sibling
# old_bookmarks_2 = old_story_folder.parent.next_sibling.child


new_story_folder = [h3 for h3 in soup.find_all('h3') if tgt_name in h3.string][0]
new_bookmarks = new_story_folder.parent.next_sibling

link_lst = [old_a.string + ',' + old_a.get('href') + ',' + new_a.string + ',' + new_a.get('href') for old_a, new_a in zip(old_bookmarks.find_all('a'), new_bookmarks.find_all('a'))]

csv_lines = []
for link in link_lst:
    csv_line = f'{link}\n'
    csv_lines.append(csv_line)

with open(output_csv_path, 'w') as csv:
    csv.writelines(csv_lines)
