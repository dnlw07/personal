# %%
import re
import pandas as pd
from copy import deepcopy
from configparser import ConfigParser

# TODO: dodać typy danych w daklaracji funkcji, dodać typy danych w importach, parametry powinny być oddzielowne enterami, w dekoratorze powinien znadjować się parametr z inputem (jak w Backorders), dodać docstring

""" INPUT """

config = ConfigParser()
config.read_file(open('C:\Dane\VSCRepo\python\confluence\config.ini'))

incremental_flg = config['GENERAL'].getboolean('incremental')
filter_flg = config['GENERAL'].getboolean('filter')
join_flg = config['GENERAL'].getboolean('join')
join_type_flg = config['GENERAL']['join_type']

src_folder_name = config['OBJECT_NAME']['src_data_model_name']
tgt_folder_name = config['OBJECT_NAME']['tgt_name']
src_names_str = config['OBJECT_NAME']['src_tbl_name_lst']

src_name_lst = src_names_str.split(',')

src_var_lst = [f'input_{src_name}' for src_name in src_name_lst]
src_names = ', '.join(src_var_lst)

if incremental_flg:
    incremental_suffix_str = 'Incremetnal'
    import_str = ' incremental, configure,'
    import2_str = f' {incremental_suffix_str}TransformContext,'
    src_names = f'ctx: {incremental_suffix_str}TransformContext, {src_names}'
# else:
#     pass

tgt_name = tgt_folder_name.lower().replace(' ', '_')
src_name = src_name_lst[0]


# src_folder_name = 'ILAS Data Warehouse Prep'
# tgt_folder_name = 'Spare Parts Orders'
# src_name_lst = ['zdomwerks']

## %%

""" TEMPLATE """

script_template_lst = [
f'from transforms.api import transform,{import_str} Input, Output,{import2_str} {incremental_suffix_str}TransfromInput, {incremental_suffix_str}TransformOutput',
'from pyspark.sql import functions as F',
'',
'',
'@transform(',
f'    output_{tgt_name}=Output("/BMW/{tgt_folder_name} - Working Space/data/views/{tgt_name}"),',
')',
f'def {tgt_name}_function({src_names}: {incremental_suffix_str}TransfromInput, output_{tgt_name}: {incremental_suffix_str}TransformOutput):',
'    """',
f'    The objective of this transformation is to create the table of {tgt_name}',
'    """',
'',
'',
'    # Requirements and Business Logic',
f'    {tgt_name} = {src_name}_table\\',
'        .cache()',
'',
f'    output_{tgt_name}.write_dataframe({tgt_name})',
'',
]

# copy template
script_lst = deepcopy(script_template_lst)


""" GENERATE CODE SNIPPES """

# TODO dodać możliwość generowanie kilku źródeł

# generate incremental
# incremental_decorator_lst = ["@incremental(semantic_version=1)"]
incremental_decorator_lst = ["@incremental(semantic_version=1)","# In order to facilitate the first build (as snapshot) for the large amount of data, configure function has been used.","# Not necessary to use for update. Reactivate IF an increase of the semantic version of the incremental transform is required,","# as the first run will be snapshot and the increased resources will be needed to prevent OOM failures.","@configure(profile=[","            'DRIVER_MEMORY_MEDIUM',","            'EXECUTOR_CORES_MEDIUM',","            'NUM_EXECUTORS_8',","            'EXECUTOR_MEMORY_MEDIUM'])"] # not enough permision

incremental_header_lst = ["    if ctx.is_incremental:"]
temp_src_df_lst = [f'        input_{src_name} = input_{src_name}.dataframe()' for src_name in src_name_lst]
incremental_header_lst.extend(temp_src_df_lst)
incremental_header_lst.append('    else:')
temp_src_df_lst = [f"        input_{src_name} = input_{src_name}.dataframe(mode='current')" for src_name in src_name_lst]
incremental_header_lst.extend(temp_src_df_lst)
incremental_header_lst.append('')

incremental_footer_lst = [f"    output_{tgt_name}.set_mode('replace')"]

# generate input source paths
decorator_input_src_lst = [f'    input_{src_name}=Input("/BMW/{src_folder_name}/data/pre_int_eu-west-1/{src_name}"),' for src_name in src_name_lst]

# generate rename and cast field mappings
df = pd.read_csv(f'C:\\Dane\\VSCRepo\\python\\confluence\\output\\table_{tgt_name}.csv')
mapping = df[['Column name of data asset table', 'Column name of source table in impACT!', 'Type of field']]

# rename mapping
mapping['rename'] = [f"        F.col('{str(tgt_field_name)}').alias('{str(src_field_name)}')," for tgt_field_name, src_field_name in zip(mapping['Column name of data asset table'], mapping['Column name of source table in impACT!'])]
rename_lst = mapping['rename'].tolist()

# cast mapping
mapping['cast'] = [f"        .withColumn('{str(field_name)}', F.col('{str(field_name)}').cast('{str(type)}'))\\" for field_name, type in zip(mapping['Column name of data asset table'], mapping['Type of field'])]
cast_lst = mapping['cast'].tolist()

# mapping[['rename', 'cast']].to_csv(r'C:\Dane\VSCRepo\python\confluence\output\df_script_snippets.csv')

# generate source df
if incremental_flg:
    src_df_lst = [f'    {src_name}_table = input_{src_name}.select(\n    ).cache()\n' for src_name in src_name_lst]
else:
    src_df_lst = [f'    input_{src_name} = input_{src_name}.dataframe()\n    {src_name}_table = input_{src_name}.select(\n    ).cache()\n' for src_name in src_name_lst]
src_df_lst_2 = []
[src_df_lst_2.extend(row.split('\n')) for row in src_df_lst] # string is split to list to allow insert into list
[src_df_lst_2.insert(-2,rename) for rename in rename_lst]

# generate filtering tempate
filtering_lst = ["    # Filter logic","    # name_table = name_table.filter((F.col('field_name') != 'R') & (F.col('field_name') == '#'))",""]

# generate join tempate
join_lst = ["    # Join ZDOMLGNUM table","    # zdomwerks_table = zdomwerks_table\\","        # .withColumn('ingestdt', F.to_date(F.col('ingestdt'), 'yyyy-MM-dd-HH-mm-ss'))\\","        # .join(zdomlgnum_table, on=['plant', 'ingestdt'], how='left_outer')\\","        # .dropDuplicates()",""]

# incremental
if incremental_flg:
    incremental_filter_lst = ["    # If NEW DATA",
    f"    if not {src_name}_table.rdd.isEmpty():",
    "",
    "        # Latest records according to the ingestdt (WARNING: take care when using ingestdt, check documentation)",
    f"        latest_{src_name}_table = (",
    f"            {src_name}_table",
    "            .groupBy('pk_field_1', 'pk_field_2')",
    "            .agg(F.max('ingestdt').alias('ingestdt'))",
    "        )",
    f"        {src_name}_table = {src_name}_table.join(",
    f"            latest_{src_name}_table, on=['pk_field_1', 'pk_field_2', 'ingestdt'], how='inner')",
    ""]


""" INSERT CODE SNIPPETS INTO TEMPLATE """

# insert incremental decorator
if incremental_flg:
    idx = [i for i, elem in enumerate(script_lst) if re.match('.*@transform.*', elem)][0]
    [script_lst.insert(idx,incremental) for incremental in reversed(incremental_decorator_lst)]

# insert incremental header
if incremental_flg:
    idx = [i + 5 for i, elem in enumerate(script_lst) if re.match(f'.*{tgt_name}_function.*', elem)][0]
    [script_lst.insert(idx,incremental) for incremental in reversed(incremental_header_lst)]

# insert source input
idx = [i + 2 for i, elem in enumerate(script_lst) if re.match('.*@transform.*', elem)][0]
[script_lst.insert(idx,src_input) for src_input in reversed(decorator_input_src_lst)]

# insert source df
idx = [i for i, elem in enumerate(script_lst) if re.match('.*# Requirements and Business Logic*.*', elem)][0]
[script_lst.insert(idx,src_df) for src_df in reversed(src_df_lst_2)]

# insert fitlering example
if filter_flg:
    idx = [i for i, elem in enumerate(script_lst) if re.match('.*# Requirements and Business Logic*', elem)][0]
    [script_lst.insert(idx,filtering) for filtering in reversed(filtering_lst)]

# insert join example
if join_flg:
    idx = [i for i, elem in enumerate(script_lst) if re.match('.*# Requirements and Business Logic*', elem)][0]
    [script_lst.insert(idx,join) for join in reversed(join_lst)]

# insert incremental fitler
if join_flg:
    idx = [i for i, elem in enumerate(script_lst) if re.match('.*# Requirements and Business Logic*', elem)][0]
    [script_lst.insert(idx,inc_filter) for inc_filter in reversed(incremental_filter_lst)]

# insert target cast
idx = [i + 2 for i, elem in enumerate(script_lst) if re.match('.*# Requirements and Business Logic*', elem)][0]
[script_lst.insert(idx,cast) for cast in reversed(cast_lst)]

# insert incremental footer
if incremental_flg:
    idx = [i for i, elem in enumerate(script_lst) if re.match('.*output.*write_dataframe.*', elem)][0]
    [script_lst.insert(idx,incremental_footer) for incremental_footer in reversed(incremental_footer_lst)]



""" SAVE TO FILE """

with open(r'C:\Dane\VSCRepo\python\confluence\output\pySpark.py', 'w') as f:
    f.write('\n'.join(script_lst))


# %%
