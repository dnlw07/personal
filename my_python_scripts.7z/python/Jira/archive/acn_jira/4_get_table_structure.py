# %%
import os
from atlassian import Confluence
from bs4 import BeautifulSoup
import csv
from pprint import pprint
from configparser import ConfigParser, ExtendedInterpolation
import re

config = ConfigParser()
config.read_file(open('C:\Dane\VSCRepo\python\confluence\config.ini'))
page_title = config['OBJECT_NAME']['tgt_name']

# page_title = 'Spare Parts Orders'
# page_title = 'Spare Parts Material Management Data'
# page_title = 'Spare Parts Call-Offs'
# page_title = 'Spare Parts Retail Key Figures'
page_title = 'Service Partner Assignment'


space = 'DETOX'

confluence = Confluence(url='https://atc.bmwgroup.net/confluence/', username='QXZ1O3D', password='czarymaryhokuspokus', verify_ssl=False)

src_html_folder_path = r'C:\Dane\VSCRepo\python\confluence\input'
tgt_csv_folder_path = r'C:\Dane\VSCRepo\python\confluence\output'

print('')
pprint(page_title)

src_html_path = os.path.join(src_html_folder_path, f'{page_title}.html')
tgt_csv_path = os.path.join(tgt_csv_folder_path, f'table_{page_title}.csv'.replace(' ', '_').lower())

# check if page exists
status = confluence.page_exists(space, title=page_title)
print(status)

# get page id
page_id = confluence.get_page_id(space=space, title=page_title)
pprint(page_id)

# get page body
page_body = confluence.get_page_by_id(page_id, expand='body.storage').get('body').get('storage').get('value')
# pprint(page_body)

# %%
soup = BeautifulSoup(page_body, 'lxml')
page_body = soup.prettify()
# pprint(page_body)

# extract proper table from html file
# page_header = [elem for elem in soup.find_all('strong') if elem.string is not None and re.match('.*vehicle_current_assignment*', elem.string, re.I)][0]
# table_html = page_header.parent.next_sibling
# pprint(page_header)
table_html_lst = [elem for elem in soup.find_all('table') if re.match('.*Column name of*|', elem.text, re.I)]
# pprint(table_html)

# get more then one table
# page_header2 = [elem for elem in soup.find_all('strong') if elem.string is not None and re.match('.*Table name:.*monthly_key_figures_overall', elem.string, re.I)][0]
# table_html2 = page_header2.parent.next_sibling

# %%

# headers = [th.text.strip().replace('\xa0', ' ') for th in table_html.find_all('td')]
# print(f'column list: {headers}')

with open(tgt_csv_path, 'w', encoding='utf-8') as f:
    wr = csv.writer(f, delimiter=',', lineterminator='\n')
    for table_html in table_html_lst:
        wr.writerow([th.text.strip().replace('\xa0', ' ') for th in table_html.find_all('td')])
        wr.writerows([[td.text.strip().replace('\xa0', ' ') for td in row.find_all('td')] for row in table_html.select('tr + tr')])
        wr.writerows([''])
        wr.writerows([''])
    # wr.writerows([[td.text.strip().replace('\xa0', ' ') for td in row.find_all('td')] for row in table_html2.select('tr + tr')])

