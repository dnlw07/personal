""" 
create test evidence in JIRA
"""

from atlassian import Xray
from pprint import pprint
import re

# test_key = 'DAQASC-3324' # done
test_key = 'DAQASC-4876' # empty
repo_link = r'https://impact.bmw.cloud/workspace/data-integration/dataset/preview/ri.foundry.main.dataset.ce8aa5ef-7c45-4d3a-97f7-009378b99dd9/master'

xray = Xray(url='https://atc.bmwgroup.net/jira/', username='QXZ1O3D', password='czarymaryhokuspokus', verify_ssl=False)


# csv_file_path =r'C:\Dane\VSCRepo\python\confluence\templates\xray_documentation.csv'
# csv_file_path =r'C:\Dane\VSCRepo\python\confluence\templates\xray_sync.csv'
csv_file_path =r'C:\Dane\VSCRepo\python\confluence\templates\xray_build.csv'

# get test steps from template file
with open(csv_file_path, 'r') as f:
    test_step_str = f.read()
test_step_str = re.sub('link_target_table', repo_link, test_step_str)
test_step_lst = test_step_str.split("\n")

xray_step_lst = [tuple(step.split(',')) for step in test_step_lst if step != '']
# print(xray_step_lst)



# xray_sync_lst = [
# ('Sync of the tables has been completed successfully (build)',
# 'https://impact.bmw.cloud/workspace/data-integration/monocle/graph/ri.monocle.main.graph.5a089892-e5f5-42c7-9024-5ba3c86ad1a6?coloring=monocle.color.resource-type',
# 'Table is sync into the Impact Source layer with a successful build'),
# ('Check that the total number of rows of the table in CDH is the same as the table in the Source Layer (Impact)',
# 'https://impact.bmw.cloud/workspace/data-integration/dataset/preview/ri.foundry.main.dataset.9f7e67da-6c49-4c48-bfb2-b50d926ca36c/master',
# 'The table in CDH contains same number of rows as in Source Layer table')
# ]

# xray_docu_lst = []
# xray_build_lst = []


# CAUTION! choose proper list
# xray_step_lst = xray_sync_lst
# xray_step_lst = xray_docu_lst
# xray_step_lst = xray_build_lst


# # CAUTION! delete test steps
data = xray.get_test_steps(test_key)
test_id_lst = [step['id'] for step in data]
[xray.delete_test_step(test_key, id) for id in test_id_lst]


# # create test steps
[xray.create_test_step(test_key, *step) for step in xray_step_lst]



# EXAMPLES:
# data = xray.get_tests(list(test_key))
# data = xray.get_test_runs(test_key)
# data = xray.get_test_executions(test_key)
# test_exec_key_lst = [test_exec['key'] for test_exec in data]
# xray.update_test_step('TEST-001', 100, 'Updated Test Step', 'Updated Test Data', 'Updated Test Result')

# pprint(data)