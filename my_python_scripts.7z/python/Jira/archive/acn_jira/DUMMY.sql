-- check duplicates
WITH QUERY AS (
SELECT * FROM ${2:TABLE_NAME
)
SELECT calloff_date,plant,part_number_source,snapshot_timestamp, COUNT(*) AS DUPLICATES FROM QUERY GROUP BY calloff_date,plant,part_number_source,snapshot_timestamp HAVING COUNT(*)>1 ORDER BY DUPLICATES DESC;