""" 
generates documentation such as:
- scripts.py
- documentation test
- INT development test
- PROD development test 
- INT pull request
- PROD pull request
"""