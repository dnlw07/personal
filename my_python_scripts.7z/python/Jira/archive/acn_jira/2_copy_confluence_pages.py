'''
copy confluence page and it's subpages to another location
'''

# curl -u username:password -X GET -H "Content-Type: application/json" http://localhost:8080/rest/api/2/issue/createmeta


# copy page hierarchy
import requests
from requests.auth import HTTPBasicAuth
import json

auth = HTTPBasicAuth("username","password")
# TODO add verify_ssl=False

domain = ""
page_id = ""
destinationPageId = ""
prefix = ""
replace = ""
search = ""

url = f'https://{domain}.atlassian.net/wiki/rest/api/content/{page_id}/pagehierarchy/copy'

headers = {
    "Content-Type": "application/json"
}

payload = json.dumps({
    "copyAttachments": True,
    "copyPermissions": True,
    "copyProperties": True,
    "copyLabels": True,
    "copyCustomContents": True,
    "destinationPageId": destinationPageId,
    "titleOptions": {
        "prefix": prefix,
        "replace": replace,
        "search": search
    }
})

response = requests.request(
    "POST",
    url,
    data=payload,
    headers=headers,
    auth=auth
)

print(response.text)

