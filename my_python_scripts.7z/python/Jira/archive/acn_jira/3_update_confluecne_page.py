import os
import re
import time
from atlassian import Confluence
from configparser import ConfigParser, ExtendedInterpolation

config = ConfigParser()
config.read_file(open('C:\Dane\VSCRepo\python\confluence\config.ini'))

temp_dev_jira_num = config['JIRA']['temp_dev_jira_key']
dev_jira_num = config['JIRA']['dev_jira_key']

temp_prod_jira_num = config['JIRA']['temp_prod_jira_key']
prod_jira_num = config['JIRA']['prod_jira_key']

temp_tgt_name = config['OBJECT_NAME']['temp_tgt_name']
tgt_name = config['OBJECT_NAME']['tgt_name']

temp_src_tbl_names_str = config['OBJECT_NAME']['temp_src_tbl_name_lst']
src_tbl_names_str = config['OBJECT_NAME']['src_tbl_name_lst']

temp_src_tbl_name_lst = temp_src_tbl_names_str.split(',')
src_tbl_name_lst = src_tbl_names_str.split(',')


# temp_dev_jira_num = 'DAQASC-3233'
# dev_jira_num = 'DAQASC-3238'

# temp_prod_jira_num = 'DAQASC-3234'
# prod_jira_num = 'DAQASC-3240'

# temp_tgt_name = 'Spare Parts Orders'
# tgt_name = 'Spare Parts Deliveries'

# temp_src_tbl_name = 'zdomwerks'
# src_tbl_name = 'te_ilaadr40_f'


space = 'DETOX'

src_html_folder_path = r'C:\Dane\VSCRepo\python\confluence\input'
tgt_html_folder_path = r'C:\Dane\VSCRepo\python\confluence\output'


page_title_lst = [
    f'{tgt_name} Specifications',
    f'{tgt_name} Functional Specifications',
    f'Implementation Logic - {tgt_name}',
    f'{tgt_name} Technical Specification',
]

confluence = Confluence(url='https://atc.bmwgroup.net/confluence/', username='QXZ1O3D', password='czarymaryhokuspokus', verify_ssl=False)

for page_title in page_title_lst:
    
    print('')
    print(page_title)

    src_html_path = os.path.join(src_html_folder_path, f'{page_title}.html')
    tgt_html_path = os.path.join(tgt_html_folder_path, f'{page_title}.html')

    # check if page exists
    status = confluence.page_exists(space, title=page_title)
    print(status)

    # get page id
    page_id = confluence.get_page_id(space=space, title=page_title)
    print(page_id)

    # get page body
    page_body = confluence.get_page_by_id(page_id, expand='body.storage').get('body').get('storage').get('value')
    # print(page_body)

    with open(src_html_path, 'w') as csv:
        csv.write(page_body)

    # Page names
    page_body=re.sub(temp_tgt_name, tgt_name, page_body)
    page_body=re.sub(temp_tgt_name.replace(' ', '\+'), tgt_name.replace(' ', '\+'), page_body)
    page_body=re.sub(temp_tgt_name.lower().replace(' ', '_'), tgt_name.lower().replace(' ', '_'), page_body)
    page_body=re.sub(temp_tgt_name.lower().replace(' ', '\+'), tgt_name.lower().replace(' ', '\+'), page_body)

    # Source table name
    for temp_src_tbl_name, src_tbl_name in zip(temp_src_tbl_name_lst, src_tbl_name_lst):
        page_body=re.sub(temp_src_tbl_name, src_tbl_name, page_body)

    # Jira tasks
    page_body=re.sub(temp_dev_jira_num, dev_jira_num, page_body)
    page_body=re.sub(f'Develop {temp_tgt_name} Table', f'Develop {tgt_name} Table', page_body)
    page_body=re.sub(temp_prod_jira_num, prod_jira_num, page_body)
    page_body=re.sub(f'Go Live on Prod Pipeline for {temp_tgt_name}', f'Go Live on Prod Pipeline for {tgt_name}', page_body)

    # TODO - map values from CSV file
    # Impact repositories
    page_body=re.sub('https://impact.bmw.cloud/workspace/compass/view/ri.compass.main.folder.9ac2cded-816a-4496-b34a-79bc90116c42', 'https://impact.bmw.cloud/workspace/compass/view/ri.compass.main.folder.b04180dd-05a5-4512-ba75-78e17e343059', page_body)
    page_body=re.sub('https://impact.bmw.cloud/workspace/compass/view/ri.compass.main.folder.988c5146-d26d-4160-9bd6-b18b13334a24', 'https://impact.bmw.cloud/workspace/compass/view/ri.compass.main.folder.1706d232-a0b9-423c-998c-716e352c55f4', page_body)
    page_body=re.sub('https://impact.bmw.cloud/workspace/data-integration/code/repos/ri.stemma.main.repository.ab7848b6-10d4-4424-8178-6f57787b5e17/contents/refs%2Fheads%2Fmaster', 'https://impact.bmw.cloud/workspace/code/repos/ri.stemma.main.repository.1b3e518a-e082-4dc5-82d0-71eefa13f2f1/contents/refs%252Fheads%252Fmaster', page_body)
    page_body=re.sub('https://impact.bmw.cloud/workspace/data-integration/code/repos/ri.stemma.main.repository.6c9207bc-c8e7-429a-b327-f8a7b7ff5556/contents/refs%2Fheads%2Fmaster', 'https://impact.bmw.cloud/workspace/code/repos/ri.stemma.main.repository.08cb79ef-48fc-481d-b6a3-ad39cbfac225/contents/refs%252Fheads%252Fmaster', page_body)

    # Pull requests INT
    # page_body=re.sub('', '', page_body)
    # page_body=re.sub('', '', page_body)

    # Pull requests PROD
    # page_body=re.sub('', '', page_body)
    # page_body=re.sub('', '', page_body)

    with open(tgt_html_path, 'w') as csv:
        csv.write(page_body)

    # update or create
    # confluence.update_page(page_id=page_id, title=page_title, body=page_body, parent_id=None, type="page", representation="storage")
    
    # set time interval
    time.sleep(1)

