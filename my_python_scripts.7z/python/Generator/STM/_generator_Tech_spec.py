import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
from openpyxl import load_workbook, Workbook
# import pandas as pd
# from datetime import datetime
# import re
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from copy import deepcopy
# from excel_functions_stm import *


# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
from control_panel import wf_ID, sda_sys_cd, sda_type, sda_tgt_schema_name, sda_atc, sda_table_map
from excel_functions import *


# wf_ID = 'ESF'
# sda_table_codes = ['T226001','T226002','T226003','T226004']

tmp_wb_paths = [r"C:\Dane\repo\notebook\projects\_templates\specyfikacje_v6.5.xlsm"]


# path to executable file
base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output')
output_package_path = rf'C:\Dane\repo\python\Generator\_output'
output_file_path = os.path.join(output_package_path, f'Specyfikacja_interfejsów_{sda_sys_cd.upper()}_v0.1.xlsx')


# [os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.xls'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany


# replace 'null' with an empty string
for dct in sda_atc:
	for k,v in dct.items():
		dct[k] = '' if v == 'null' else v

# enrich dictionary
sda_atc_2 = [{'table_name': dct['table_name'], 'lp': dct['lp'], 'pk': 'NIE', 'column_name':  dct['column_name'], 'data_type':  dct['data_type'], 'data_length':  dct['data_length'],  dct['data_length']: '', 'data_scale':  dct['data_scale'], 'format':  dct['format'], 'dedicated_dict': '', 'description':  dct['description'], 'column_name_2': dct['column_name'], 'data_type_2': dct['data_type'], 'data_length_2': dct['data_length'], 'data_precision_2': dct['data_precision'], 'data_scale_2': dct['data_scale'], 'format_2': dct['format'], 'dummy_1': '', 'dummy_2': 'NIE', 'dummy_3': 'event_dttm', 'dummy_4': '', 'dummy_5': '', 'column_name_3': dct['column_name'], 'data_type_3': dct['data_type'], 'data_length_3': dct['data_length'], 'data_precision_3': dct['data_precision'], 'data_scale_3': dct['data_scale'] } for dct in sda_atc]


sda_dct = {}
for item in sda_atc_2:
    table_name = item['table_name']
    column_name = item['column_name']
    if table_name not in sda_dct:
        sda_dct[table_name] = [{**{k: v for k, v in item.items() if k != 'table_name'}}]
    else:
        sda_dct[table_name].append({**{k: v for k, v in item.items() if k != 'table_name'}})


sda_table_codes = [re.findall('t\d+', new_table_name, re.IGNORECASE)[0].lower() for old_table_name, new_table_name in sda_table_map.items()]


# loop through workbooks
for tmp_wb_path in tmp_wb_paths:

	# open STM workbook
	tmp_wb = load_workbook(tmp_wb_path, read_only=False, data_only=False)  # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again

	row = 2
	row_lista = 4
	for extract_name, table_body in sda_dct.items():
		sda_table_name = sda_table_map[extract_name].lower()
		# sda_table_name = sda_table_map[src_table_name].lower() if src_table_name in sda_table_map.keys() else src_table_name.lower()
		table_prefix = re.findall('t\d+', sda_table_name, re.IGNORECASE)[0].lower() if sda_table_name in sda_table_map.values() else 't00000'
		table_suffix = re.sub('t\d+_', '', sda_table_name, re.IGNORECASE).lower()

		if table_prefix.lower() in sda_table_codes:
			
			if sda_type == 'DB':
				tmp_sheet = 'DATA_TEMPLATE_SDA_ORA'
				extract_type = 'DB'
				process_sin_wfl_nm = 'WFL_GCP_LOAD_DTLK_HARVESTER'
				src_schema_nm = 'TODO'
			elif sda_type == 'FILE':
				tmp_sheet = 'DATA_TEMPLATE_SDA_FILE'
				extract_type = 'PLIK'
				process_sin_wfl_nm = 'WFL_GCP_LOAD_DTLK_LOAD_CNV_FILE'
				src_schema_nm = 'Brak'

			# create new sheet
			meta_sheet_name = copy_and_move_sheet(tmp_wb, 'META_TEMPLATE_SDA', f'META_{table_suffix}', dest_pos=None)
			data_sheet_name = copy_and_move_sheet(tmp_wb, tmp_sheet, f'DATA_{table_suffix}', dest_pos=None)
			conv_sheet_name = copy_and_move_sheet(tmp_wb, 'CONV_TEMPLATE_SDA', f'CONV_{table_suffix}', dest_pos=None)

			# set zoom
			tmp_wb[meta_sheet_name].sheet_view.zoomScale = 85
			tmp_wb[data_sheet_name].sheet_view.zoomScale = 85
			tmp_wb[conv_sheet_name].sheet_view.zoomScale = 85

			################################
			# HEADER TABLE
			tmp_wb[meta_sheet_name]['B1'].value = f'out_{table_suffix.lower()}'
			tmp_wb[meta_sheet_name]['B2'].value = ''
			tmp_wb[meta_sheet_name]['B3'].value = 'SDA'
			tmp_wb[meta_sheet_name]['B4'].value = 'NOCAST'  # for file NOCAST ['NOCAST', 'ORACLE', 'MSSQL', 'POSTGRES']
			tmp_wb[meta_sheet_name]['B5'].value = extract_type.upper()
			
			tmp_wb[meta_sheet_name]['B6'].value = sda_tgt_schema_name.lower()
			tmp_wb[meta_sheet_name]['B7'].value = sda_table_name.lower()
			tmp_wb[meta_sheet_name]['B8'].value = 'GCP_DTLK_PROJECT_ID'
			# tmp_wb[meta_sheet_name]['B9'].value = f'{sda_sys_cd.upper()}_01'
			tmp_wb[meta_sheet_name]['B10'].value = 'SINGLE'
			# tmp_wb[meta_sheet_name]['B11'].value = f'DTLK_RSC_SEM_TI_DATALAKE_GCP_{sda_tgt_schema_name.upper()}_{sda_table_name.upper()}_{sda_sys_cd.upper}_01'
			
			tmp_wb[meta_sheet_name]['B12'].value = 'due_dt'
			tmp_wb[meta_sheet_name]['B13'].value = 'TODO'  # TODO: automatycznie wypełniać na podstawie zapytania SQL
			# tmp_wb[meta_sheet_name]['B14'].value = 'ED_DSA'
			
			tmp_wb[meta_sheet_name]['B15'].value = src_schema_nm
			tmp_wb[meta_sheet_name]['B16'].value = sda_sys_cd.upper()
			
			tmp_wb[meta_sheet_name]['B17'].value = 'BUCKET_FILE'
			tmp_wb[meta_sheet_name]['B18'].value = ''
			tmp_wb[meta_sheet_name]['B19'].value = 'INCR'  # ['FULL', 'INCR']
			tmp_wb[meta_sheet_name]['B20'].value = '1'
			tmp_wb[meta_sheet_name]['B21'].value = ''
			tmp_wb[meta_sheet_name]['B22'].value = 'AVRO'
			tmp_wb[meta_sheet_name]['B23'].value = sda_sys_cd.upper()
			# tmp_wb[meta_sheet_name]['B24'].value = '/data/OUT'
			# tmp_wb[meta_sheet_name]['B25'].value = '/data/IN'
			tmp_wb[meta_sheet_name]['B26'].value = '[BANK]NODE_OS_ANTHOS_ETL_PROC'
			tmp_wb[meta_sheet_name]['B27'].value = '[NULL]'
			tmp_wb[meta_sheet_name]['B28'].value = '1'
			tmp_wb[meta_sheet_name]['B29'].value = '1'
			tmp_wb[meta_sheet_name]['B30'].value = '1'
			tmp_wb[meta_sheet_name]['B31'].value = '1'
			tmp_wb[meta_sheet_name]['B32'].value = process_sin_wfl_nm
			tmp_wb[meta_sheet_name]['B33'].value = ''
			tmp_wb[meta_sheet_name]['B34'].value = ''
			tmp_wb[meta_sheet_name]['B35'].value = ''
			tmp_wb[meta_sheet_name]['B36'].value = '_data_danych = @DUE_DT@'
			tmp_wb[meta_sheet_name]['B37'].value = 'NIE'
			
			tmp_wb[meta_sheet_name]['B38'].value = table_suffix
			# tmp_wb[meta_sheet_name]['B39'].value = f'in_{table_suffix.lower()}'
			tmp_wb[meta_sheet_name]['B40'].value = ''
			tmp_wb[meta_sheet_name]['B41'].value = 'csv'
			tmp_wb[meta_sheet_name]['B42'].value = 'GCS'
			# tmp_wb[meta_sheet_name]['B43'].value = '<BUCKET_NM>'
			# tmp_wb[meta_sheet_name]['B44'].value = f'data/input/{sda_sys_cd.upper()}'
			tmp_wb[meta_sheet_name]['B45'].value = 'file_name_(\d{4})_(\d{2})_(\d{2}).csv'
			tmp_wb[meta_sheet_name]['B46'].value = 'YYYY,MM,DD,NN'
			tmp_wb[meta_sheet_name]['B47'].value = 'EBCDIC'
			tmp_wb[meta_sheet_name]['B48'].value = 'CP1250'  # ['CP1250', 'ISO-8859-2']
			tmp_wb[meta_sheet_name]['B49'].value = '0'
			tmp_wb[meta_sheet_name]['B50'].value = 'TRUE'
			tmp_wb[meta_sheet_name]['B51'].value = 'FALSE'
			tmp_wb[meta_sheet_name]['B52'].value = 'LF - 0x0A'
			tmp_wb[meta_sheet_name]['B53'].value = 'średnik - 0x3B'
			tmp_wb[meta_sheet_name]['B54'].value = 'przecinek - 0x2C'  # ['kropka - 0x2E', 'przecinek - 0x2C']
			tmp_wb[meta_sheet_name]['B55'].value = ''
			tmp_wb[meta_sheet_name]['B56'].value = 'stdin'
			tmp_wb[meta_sheet_name]['B57'].value = 'FALSE'
			tmp_wb[meta_sheet_name]['B58'].value = 'FALSE'
			tmp_wb[meta_sheet_name]['B59'].value = ''
			
			# tmp_wb[meta_sheet_name]['B60'].value = f'out_{table_suffix.lower()}'
			tmp_wb[meta_sheet_name]['B61'].value = 'IMPORT'
			# tmp_wb[meta_sheet_name]['B62'].value = f'data/output/{sda_sys_cd.upper()}'
			tmp_wb[meta_sheet_name]['B63'].value = 'file_name_[YYYY][MM][DD]_[NN].avro'
			tmp_wb[meta_sheet_name]['B64'].value = 'FALSE'
			tmp_wb[meta_sheet_name]['B65'].value = 'FALSE'
			tmp_wb[meta_sheet_name]['B66'].value = ''
			tmp_wb[meta_sheet_name]['B67'].value = ''
			tmp_wb[meta_sheet_name]['B68'].value = 'UTF-8'
			tmp_wb[meta_sheet_name]['B69'].value = 'UTF-8'
			tmp_wb[meta_sheet_name]['B70'].value = 'bucket'
			tmp_wb[meta_sheet_name]['B71'].value = 'przecinek - 0x2C'
			tmp_wb[meta_sheet_name]['B72'].value = ''
			
			tmp_wb[meta_sheet_name]['B73'].value = 'TRPT'
			tmp_wb[meta_sheet_name]['B74'].value = '10'
			
			tmp_wb[meta_sheet_name]['B75'].value = 'C'
			tmp_wb[meta_sheet_name]['B76'].value = 'P'

			################################
			# MAIN TABLE
			row_num = dict_to_range(row_lst=table_body, sheet_obj=tmp_wb[data_sheet_name], start_cell='A8', table_title=None, skip_header=True, orientation='H')

			################################
			# CONV TABLE
			def conversion_type_func(data_type):
				'''	
				# ['none','incremental','date','number','upper','lower','regex','trim','rtrim','ltrim','default','xml_root']
				dct - standaryzacje pola słownikowego:
					Usunięcie białych znaków (spacje, tabulatory, znaki nowej linii)
					Konwersja wszystkich znaków do wielkich liter (upper case)
				text - standaryzacje pola znakowego:
					Zastąpienie białych znaków (tabulatory, znaki nowej linii) z łańcucha znaków znakiem spacji
					Usunięcie spacji poprzedzających pierwszy dozwolony znak w łańcuchu znaków
					Usunięcie spacji występujących po ostatnim dozwolonym znaku w łańcuchu znaków
					Zastąpienie wielokrotnych wystąpień spacji na pojedyncze wystąpienie spacji jeśli występuje w tekście
				flag - standaryzacja pola flagowego na podstawie tabeli t00023_value_conversion_map
				'''
				
				if data_type.lower() == 'string':
					return 'text'
				else:
					return 'none'


			conversion_map_dct = [
				{'Lp.': row['lp'], 'None': '', 'conversion_cd': f'in_{table_suffix.lower()}_2_out_{table_suffix.lower()}', 'conversion_index': row['lp'], 'conversion_field_index': '1', 'output_file_cd': f'out_{table_suffix.lower()}', 'output_field_nm': row['column_name'], 'src_file_cd': f'in_{table_suffix.lower()}', 'src_field_nm': row['column_name'], 'conversion_type': conversion_type_func(row['data_type']) , 'regex_value': '', 'default_value': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''} for row in table_body
			]

			row_num = dict_to_range(row_lst=conversion_map_dct, sheet_obj=tmp_wb[conv_sheet_name], start_cell='A3', table_title=None, skip_header=True, orientation='H')
			################################
			# Index sheet
			tmp_wb['INDEX'][f'A{row}'].value = table_suffix
			tmp_wb['INDEX'][f'B{row}'].value = 'TAK'
			row+=1

			################################
			# Lista tabel sheet
			tmp_wb['Lista tabel'][f'B{row_lista}'].value = sda_table_name
			tmp_wb['Lista tabel'][f'C{row_lista}'].value = f'=HYPERLINK("#META_{table_suffix}!G1","META_{table_suffix}")'
			tmp_wb['Lista tabel'][f'D{row_lista}'].value = f'=HYPERLINK("#DATA_{table_suffix}!G1","DATA_{table_suffix}")'
			tmp_wb['Lista tabel'][f'E{row_lista}'].value = f'=HYPERLINK("#CONV_{table_suffix}!G1","CONV_{table_suffix}")'
			tmp_wb['Lista tabel'][f'F{row_lista}'].value = 'D.Wiśniewski'
			tmp_wb['Lista tabel'][f'H{row_lista}'].value = '1.0'
			tmp_wb['Lista tabel'][f'I{row_lista}'].value = 'I'
			row_lista+=1


	# remove tmp sheet
	del tmp_wb['DATA_TEMPLATE_SDA']
	del tmp_wb['DATA_TEMPLATE_SDA_ORA']
	del tmp_wb['DATA_TEMPLATE_SDA_FILE']
	del tmp_wb['META_TEMPLATE_SDA']
	del tmp_wb['CONV_TEMPLATE_SDA']
	del tmp_wb['EDA']

	# save workbook
	tmp_wb.save(output_file_path)  # jeżeli błąd to zainstalować starszą wersję: pip install openpyxl-2.6.2
	
	# open file
	os.system(output_file_path) # development purpose only


	print('\n\nDone!\n')

