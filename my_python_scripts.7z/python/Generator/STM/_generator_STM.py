import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
from openpyxl import load_workbook, Workbook
# import pandas as pd
# from datetime import datetime
# import re
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from copy import deepcopy
# from excel_functions_stm import *

# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())

from const import tech_fields_scd2, tech_fields_scd1_act, tech_fields_scd1_ovr, tech_fields_snap_ovr, tech_fields_fact, stm_const_parameteres, stm_main_header
from control_panel import wf_ID, xda_tgt_schema_name, new_table_codes, output_ldm_file_path, stm_sys_cd, xDA, stm_source_lst
from excel_functions import *

# input_stm_file_name = rf'CRM3.0_STM_MDM_-_Zdarzenia_i_Sygnały_v0.1.xlsx'
# stm_sys_cd = 'PZKB'
# wf_ID = 'ESF'


tmp_wb_paths = [rf'C:\Dane\repo\notebook\projects\_templates\tmp_STM.xlsx']


# path to executable file
base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output')
output_package_path = rf'C:\Dane\repo\python\Generator\_output'
output_file_path = os.path.join(output_package_path, f'{wf_ID.lower()}_IDA_STM_v1.0.xlsx')


# [os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.xls'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany


# loop through workbooks
for tmp_wb_path in tmp_wb_paths:

	################################################################################################################################
	# READ INPUT
	################################################################################################################################

	src_wb = None
	ldm_wb = load_workbook(output_ldm_file_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	ldm_sheet_names = [string for string in ldm_wb.sheetnames if any((substr[1:7] in string) for substr in new_table_codes)]
	ldm_main_dct = all_datasets_by_table_name(ldm_wb, ldm_sheet_names, table_name_pattern='Specyfikacja logicznego modelu danych', offset_header_rows=2, orientation='H')

	tmp_wb = load_workbook(tmp_wb_path, read_only=False, data_only=False) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	
	ldm_sheet_names = [string for string in ldm_wb.sheetnames if any((substr[1:7] in string) for substr in new_table_codes)]
	stm_sheet_names = [f"STM_{re.sub('LDM_', '', ldm_sheet_name)}" for ldm_sheet_name in ldm_sheet_names]
	tgt_table_names = list(stm_source_lst.keys())


	################################################################################################################################
	# GENERATE DICTS
	################################################################################################################################


	################################
	# SRC AREAS TABLE
	stm_src_areas = [{'Nazwa obszaru': '', 'None': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}]

	################################
	# SRC LIST TABLE
	stm_src_tables_dct = {}

	for tgt_table_name, sources in stm_source_lst.items():
		new_lst = []
		for source in sources:
			src_schema_name, src_table_name = source.split('.')
			elem = {'System źródłowy': 'DDP', 'Schemat': src_schema_name, 'Tabela źródłowa': src_table_name, 'None': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
			new_lst.append(elem)
		table_prefix = tgt_table_name[0:7]
		stm_src_tables_dct.setdefault(table_prefix, []).extend(new_lst)

	################################
	# SRC DEFINITION TABLE
	stm_src_definition = {}

	for tgt_table_name, sources in stm_source_lst.items():
		new_lst = []
		for source in sources:
			src_schema_name, src_table_name = source.split('.')
			elem = {'Wynikowy zbiór danych': tgt_table_name, 'Wejściowy zbiór danych': src_table_name, 'Alias': 'X', 'Filtrowanie wejściowego \nzbioru danych': 'xxx = xxx', 'Rola wejściowego zbioru danych': 'Master', 'Operator': 'xxx', 'Warunek łączenia tabel': 'xxxx', 'Filtrowanie wynikowego \nzbioru danych': '', 'Agregacja \nwynikowego zbioru danych': '', 'Kolumny wynikowe': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
			new_lst.append(elem)
		table_prefix = tgt_table_name[0:7]
		stm_src_definition.setdefault(table_prefix, []).extend(new_lst)

	################################
	# MAIN STM TABLE
	new_dct_5 = {}
	for tgt_table_name, (tgt_table_code, rows) in zip(tgt_table_names, ldm_main_dct.items()): # TODO - upewnij się że w zip jest taka sama ilość elementów
		new_lst = []
		for row in rows:
			tgt_field_name = row['Kolumna']
			src_field_name = tgt_field_name
			src_schema_name, src_table_name = stm_source_lst[tgt_table_name][0].split('.')
			elem = {'Schemat wynikowego zbioru danych': xda_tgt_schema_name.upper(), 'Wynikowy zbiór danych': tgt_table_name.upper(), 'Nazwa kolumny w wynikowym zbiorze': tgt_field_name.upper(), 'Źródłowy zbiór danych': src_table_name.upper(), 'None': '', 'Alias źródłowego zbioru danych': 'X', 'Kolumna źródłowa': src_field_name.upper(), 'Logika transformacji': '1-1', 'None_2': '', 'Wartość domyślna': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
			new_lst.append(elem)
		table_prefix = tgt_table_name[0:7]
		new_dct_5.setdefault(table_prefix, []).extend(new_lst)

	################################
	# PARAMETERS TABLE
	for item in stm_const_parameteres:
		if item['Nazwa parametru'] == '$$ETLPackage':
			item['Formuła'] = rf"''{stm_sys_cd}_01'"

	stm_parameters = {}
	for tgt_table_name, sources in stm_source_lst.items():
		new_lst = []
		for source in sources:
			src_schema_name, src_table_name = source.split('.')
			try:
				src_prefix = re.findall('^t\d+', src_table_name, re.I)[0]
			except:
				src_prefix = 't000000'

			if 'sda_' in src_schema_name:
				elem = {'Nazwa parametru': f'$$ExtractVersion_{src_prefix}', 'Typ': '', 'Opis': f'Wersja ekstraktu {src_table_name}', 'None': '', 'Formuła': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
				new_lst.append(elem)
		table_prefix = tgt_table_name[0:7]
		stm_parameters.setdefault(table_prefix, []).extend(stm_const_parameteres)
		stm_parameters.setdefault(table_prefix, []).extend(new_lst)

	################################################################################################################################
	# WRITE dicts into excel
	################################################################################################################################

	for ldm_sheet_name, stm_sheet_name, tgt_table_name in zip(ldm_sheet_names, stm_sheet_names, tgt_table_names):
		
		# create new sheet
		stm_sheet_name = copy_and_move_sheet(tmp_wb, 'tmp', stm_sheet_name, dest_pos=None)
		
		# set zoom
		tmp_wb[stm_sheet_name].sheet_view.zoomScale = 85

		################################
		# HEADER TABLE
		# tmp_wb[stm_sheet_name]['C4'].value = re.sub(f'T{ldm_sheet_name[1:3]}', f'T{xda_tgt_schema_name[4:7]}', src_wb[ldm_sheet_name]['D4'].value)
		tmp_wb[stm_sheet_name]['C4'].value = tgt_table_name
		tmp_wb[stm_sheet_name]['C5'].value = xda_tgt_schema_name
		table_type = ldm_wb[ldm_sheet_name]['C11'].value.lower()
		tmp_wb[stm_sheet_name]['C6'].value = table_type


		# leave table prefix only in sheen_name
		stm_dct_keys = list(stm_src_definition.keys())
		if ldm_sheet_name not in stm_dct_keys:
			ldm_sheet_name = re.findall('t\d+', ldm_sheet_name, re.I)[0].lower()


		################################
		# SRC AREAS TABLE
		row_num = 15
		# row_num = dict_to_range_with_formatting(stm_src_areas_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Źródło do Tabeli docelowej', orientation='H', formatting_type=None)
		row_num = dict_to_range_with_formatting(stm_src_areas, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Lista Powiązanych obszarów', orientation='H', formatting_type='STM_src_areas')
		
		################################
		# SRC LIST TABLE
		# row_num = dict_to_range_with_formatting(stm_src_tables_dct_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Lista Tabel Źródłowych', orientation='H', formatting_type=None)
		row_num = dict_to_range_with_formatting(stm_src_tables_dct[ldm_sheet_name], tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Lista Tabel Źródłowych', orientation='H', formatting_type='STM_src_tables')


		################################
		# SRC DEFINITION TABLE
		# row_num = dict_to_range_with_formatting(stm_src_definition_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Źródło do Tabeli docelowej', orientation='H', formatting_type=None)
		row_num = dict_to_range_with_formatting(stm_src_definition[ldm_sheet_name], tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Definicja zbiorów danych (join)', orientation='H', formatting_type='STM_src_definition')
		
		################################
		# MAIN STM TABLE
		row_num = dict_to_range_with_formatting(stm_main_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Źródło do Tabeli docelowej', orientation='H', formatting_type='STM_main_header')
		row_num = dict_to_range_with_formatting(new_dct_5[ldm_sheet_name], tmp_wb[stm_sheet_name], start_cell=f'B{row_num-4}', table_name=None, orientation='H', formatting_type='STM_main')

		################################
		# PARAMETERS TABLE
		# row_num = dict_to_range_with_formatting(stm_parameters_header, tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Źródło do Tabeli docelowej', orientation='H', formatting_type=None)
		row_num = dict_to_range_with_formatting(stm_parameters[ldm_sheet_name], tmp_wb[stm_sheet_name], start_cell=f'B{row_num}', table_name='Lista parametrów', orientation='H', formatting_type='STM_parameters')

		################################
		# create validation sheet
		# stm_val_sheet_name = f'Walidacje_{stm_sheet_name}'
		# stm_sheet_name = copy_and_move_sheet(tmp_wb, 'tmp_validation', stm_val_sheet_name, dest_pos=None)
		# tmp_wb[stm_val_sheet_name].sheet_view.zoomScale = 85
		# row_num = dict_to_range_with_formatting(stm_validation[stm_sheet_name], tmp_wb[stm_val_sheet_name], start_cell='B3', table_name=None, orientation='H', formatting_type='STM_validation')

	################################
	# LISTA TABEL
	row = 4
	for tgt_table in tgt_table_names:
		tmp_wb['Lista tabel'][f'B{row}'].value = f'=HYPERLINK("#LDM_{tgt_table[0:7]}!B1","{tgt_table}")'
		tmp_wb['Lista tabel'][f'C{row}'].value = f'=HYPERLINK("#STM_{tgt_table[0:7]}!B1","STM_{tgt_table[0:7]}")'
		tmp_wb['Lista tabel'][f'D{row}'].value = 'D.Wiśniewski'
		tmp_wb['Lista tabel'][f'E{row}'].value = ''
		tmp_wb['Lista tabel'][f'F{row}'].value = '1.0'
		tmp_wb['Lista tabel'][f'G{row}'].value = 'I'
		row+=1

	# remove tmp sheet
	del tmp_wb['tmp']
	del tmp_wb['tmp_validation']
	del tmp_wb['helper']
	del tmp_wb['Txxxxxx']
	del tmp_wb['Walidacje_Txxxxx']
	del tmp_wb['template']

	# activate cell
	# tmp_wb["Lista tabel"].views.sheetView[0].selection[0].sqref = "B4"

	# save workbook
	tmp_wb.save(output_file_path)  # jeżeli błąd to zainstalować starszą wersję: pip install openpyxl-2.6.2
	
	# open file
	os.system(output_file_path) # development purpose only

# if __name__ == "__main__":
# 	generate_stm()
