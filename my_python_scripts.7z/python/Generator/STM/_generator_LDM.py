import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
from openpyxl import load_workbook, Workbook
import pandas as pd

# from datetime import datetime
# import re
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from copy import deepcopy
# from excel_functions_stm import *

# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
from control_panel import wf_ID, new_table_codes, ldm_atc, xda_tgt_schema_name, xda_table_map, ldm_table_types
from const import ldm_pk_field, ldm_tech_fields_scd1_ovr, ldm_tech_fields_scd1_act, ldm_tech_fields_scd2, ldm_tech_fields_fact, ldm_tech_fields_snap_ovr
from excel_functions import *


# new_table_codes = ['T17101', 'T17102']
# jira = '8296'
# wf_ID = 'ESF'
# tgt_schema_name = 'IDA_420_COMMON_DATA'


tmp_wb_paths = [r"C:\Dane\repo\notebook\projects\_templates\tmp_LDM.xlsx"]


# path to executable file
base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output')
output_package_path = rf'C:\Dane\repo\python\Generator\_output'
output_file_path = os.path.join(output_package_path, f'{wf_ID.lower()}_IDA_LDM_v0.1.xlsx')

# [os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.xls'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany


# loop through workbooks
for tmp_wb_path in tmp_wb_paths:

	tmp_wb = load_workbook(tmp_wb_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again

	# open STM workbook
	old_table_names = [old_table_name for old_table_name, new_table_name in xda_table_map.items() if re.findall('t\d+', new_table_name, re.IGNORECASE)[0] in new_table_codes]
	tgt_table_names = [new_table_name for old_table_name, new_table_name in xda_table_map.items() if re.findall('t\d+', new_table_name, re.IGNORECASE)[0] in new_table_codes]
	tgt_table_codes = [re.findall('t\d+', tgt_table_names, re.IGNORECASE)[0] for tgt_table_names in tgt_table_names if re.findall('t\d+', tgt_table_names, re.IGNORECASE)[0] in new_table_codes]
	ldm_sheet_names = [f'LDM_{table_code}' for table_code in tgt_table_codes]

	new_dct = {}
	for table_row in ldm_atc:
		table_name = table_row['table_name']
		dct = deepcopy(table_row)
		del dct['table_name']
		new_dct.setdefault(table_name, []).append(dct)
	

	# enrich dictionary
	new_dct_2 = {}
	for table_type_dct, (table_name, lst) in zip(ldm_table_types, new_dct.items()):
		new_lst = []
		tech_num = 0
		pk_num = 0
		for num, dct in enumerate(lst):
			if num == 0:
				ldm_pk_field[0]['Kolumna'] = f'{table_name[7:]}_KEY'
				new_lst.extend(deepcopy(ldm_pk_field))
				pk_num = len(ldm_pk_field)
				if table_type_dct['apply_mode_id'].upper() in ['SCD1_ACT', 'SCD1ACT']:
					new_lst.extend(ldm_tech_fields_scd1_act)
					tech_num = len(ldm_tech_fields_scd1_act)
				elif table_type_dct['apply_mode_id'].upper() in ['SCD1_OVR', 'SCD1OVR']:
					new_lst.extend(ldm_tech_fields_scd1_act)
					tech_num = len(ldm_tech_fields_scd1_act)
				elif table_type_dct['apply_mode_id'].upper() in ['SCD2']:
					new_lst.extend(ldm_tech_fields_scd2)
					tech_num = len(ldm_tech_fields_scd2)
				elif table_type_dct['apply_mode_id'].upper() in ['TRANSINSRT', 'TRANS', 'FACT']:
					new_lst.extend(ldm_tech_fields_fact)
					tech_num = len(ldm_tech_fields_fact)
				elif table_type_dct['apply_mode_id'].upper() in ['SNAPSHOT', 'SNAP']:
					new_lst.extend(ldm_tech_fields_snap_ovr)
					tech_num = len(ldm_tech_fields_snap_ovr)
				else:
					new_lst.extend(ldm_tech_fields_scd2)
					tech_num = len(ldm_tech_fields_scd2)
					print(f'WARNING! Nie rozpoznano typu tabeli dla tabeli: {table_name}. Przyjęto SCD2 jako domyślny typ tabeli.')

			if 'VARCHAR2' in dct['data_type']:
				data_type = re.sub('VARCHAR2', 'STRING', dct['data_type'])
				data_type = re.sub(' CHAR', '', data_type)
			elif 'VARSTRING' in dct['data_type']:
				data_type = re.sub('VARSTRING\(', 'STRING(', dct['data_type'])
				data_type = re.sub(' CHAR', '', data_type)
			elif 'CHAR' in dct['data_type']:
				data_type = re.sub('CHAR\(', 'STRING(', dct['data_type'])
				data_type = re.sub(' CHAR', '', data_type)
			elif 'NUMBER' in dct['data_type']:
				data_type = re.sub('NUMBER', 'NUMERIC', dct['data_type'])
			elif 'TIMESTAMP' in dct['data_type']:
				data_type = 'TIMESTAMP'
			elif dct['data_type'] == 'INTEGER':
				data_type = 'INT64'
			else:
				data_type = dct['data_type']

			natural_key = 'T' if dct['pk'] == 'PRIMARY KEY' else ''

			elem = {'#': num + pk_num + tech_num + 1, 'Kolumna': dct['column_name'].upper(), 'Typ': data_type, 'Primary Key': '', 'Not Null': f"{'T' if dct['nullable'] == 'N' else ''}", 'Natural Key': natural_key, 'Foreign Key': '', 'FK - Tabela referencyjna': '', 'Opis biznesowy': '', 'Dane wrażliwe': '', 'Release': '', 'Komentarze': '', 'Wersja': '1.0', 'Zmiana': 'I', 'Komentarze do zmiany': ''}
			new_lst.append(elem)

		new_dct_2.setdefault(table_name, []).extend(new_lst)


	for old_table_name, tgt_table_name, ldm_sheet_name, table_type_dct in zip(old_table_names, tgt_table_names, ldm_sheet_names, ldm_table_types):
		ldm_sheet_name = copy_and_move_sheet(tmp_wb, 'tmp', ldm_sheet_name, dest_pos=None)

		# set zoom
		tmp_wb[ldm_sheet_name].sheet_view.zoomScale = 85

		tmp_wb[ldm_sheet_name]['C5'].value = ''
		tmp_wb[ldm_sheet_name]['C6'].value = tgt_table_name
		tmp_wb[ldm_sheet_name]['C7'].value = xda_tgt_schema_name
		tmp_wb[ldm_sheet_name]['C8'].value = ''

		if table_type_dct['apply_mode_id'].upper() in ['SCD1_ACT', 'SCD1ACT']:
			table_type = 'Historyzacja stanami danych na datę przez aktualizację'
		elif table_type_dct['apply_mode_id'].upper() in ['SCD1_OVR', 'SCD1OVR']:
			table_type = 'Brak historyzacji (SCD1) przez nadpisanie'
		elif table_type_dct['apply_mode_id'].upper() in ['SCD2']:
			table_type = 'Historyzacja datami od - do (SCD2)'
		elif table_type_dct['apply_mode_id'].upper() in ['TRANSINSRT', 'TRANS', 'FACT']:
			table_type = 'Dopisanie faktów za dowolną datę biznesową'
		elif table_type_dct['apply_mode_id'].upper() in ['SNAPSHOT', 'SNAP']:
			table_type = 'Snapshot - stan danych na datę'

		tmp_wb[ldm_sheet_name]['C9'].value = table_type

		row_num = dict_to_range_with_formatting(new_dct_2[old_table_name], tmp_wb[ldm_sheet_name], start_cell='B13', table_name=None, orientation='H', formatting_type='LDM')

	
	################################
	# LISTA TABEL
	row = 4
	for tgt_table in tgt_table_names:
		tgt_table_prefix = re.findall('t\d+', tgt_table, re.IGNORECASE)[0]
		tmp_wb['Lista tabel'][f'B{row}'].value = f'=HYPERLINK("#LDM_{tgt_table_prefix}!B1","{tgt_table}")'
		tmp_wb['Lista tabel'][f'C{row}'].value = f'=HYPERLINK("#STM_{tgt_table_prefix}!B1","STM_{tgt_table_prefix}")'
		tmp_wb['Lista tabel'][f'D{row}'].value = 'D.Wiśniewski'
		tmp_wb['Lista tabel'][f'F{row}'].value = '1.0'
		tmp_wb['Lista tabel'][f'G{row}'].value = 'I'
		row+=1

	# remove tmp sheet
	del tmp_wb['tmp']

	# save workbook
	tmp_wb.save(output_file_path)  # jeżeli błąd to zainstalować starszą wersję: pip install openpyxl-2.6.2
	
	# open file
	os.system(output_file_path) # development purpose only

