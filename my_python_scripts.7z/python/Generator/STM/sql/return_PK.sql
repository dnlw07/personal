-- @"C:\Dane\repo\python\Generator\STM\sql\return_PK.sql"
-- Jeżęli występuje problem z kodowaniem w SQL Developerze to zmienić kodowanie: Tools>Preferences>Environment>Encoding to UTF-8

-- return PK
SELECT DISTINCT /*json*/
ACC.TABLE_NAME, 
ACC.COLUMN_NAME
FROM ALL_CONS_COLUMNS ACC
LEFT JOIN ALL_CONSTRAINTS AC
ON ACC.CONSTRAINT_NAME = AC.CONSTRAINT_NAME
WHERE 1=1 
AND AC.CONSTRAINT_TYPE = 'P'
-------------------INSERT TABLE -------------------------
--AND ACC.OWNER IN ('BTIFACE') 
AND ACC.TABLE_NAME in ('T60911_ODD_RAP_CTL_CLOSE_TO_LOOP','T60102_FCTD_ACTION_STATUS','T60103_FCTD_LEAD_STATUS','T60008_DIM_MARKETING_CAMPAIGN')
------------------------------------------------------------