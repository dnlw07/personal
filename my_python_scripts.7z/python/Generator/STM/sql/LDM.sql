-- @"C:\Dane\repo\python\Generator\STM\sql\LDM.sql"
-- JeżEli występuje problem z kodowaniem w SQL Developerze to zmienić kodowanie: Tools>Preferences>Environment>Encoding to UTF-8

SELECT /*json*/ 
ATC.TABLE_NAME, 
ATC.COLUMN_NAME,
atc.DATA_TYPE || CASE 
	WHEN atc.DATA_TYPE IN ('VARCHAR2', 'CHAR') THEN '(' || atc.CHAR_LENGTH || ')'
	WHEN atc.DATA_TYPE = 'NUMBER' AND atc.DATA_PRECISION IS NOT NULL THEN '(' || atc.DATA_PRECISION || ',' || atc.DATA_SCALE || ')'
	-- WHEN atc.DATA_TYPE = 'TIMESTAMP' THEN '(' || atc.DATA_SCALE || ')'
	ELSE '' 
END AS DATA_TYPE,
/*NULL and PK*/ , DECODE(SUBQ.CONSTRAINT_TYPE, NULL, 'NOT A KEY', 'PRIMARY KEY') AS PK, DECODE(ATC.NULLABLE, 'N','NOTNULL', 'Y', 'NULL') AS NULLABLE
, '' AS FK
/*COMMENTS*/ , COM.COMMENTS AS COMMMENTS

FROM SYS.ALL_TAB_COLS ATC 
/*NULL and PK*/ LEFT JOIN ( SELECT ACC.OWNER, AC.TABLE_NAME, ACC.COLUMN_NAME, AC.CONSTRAINT_TYPE FROM ALL_CONS_COLUMNS ACC JOIN ALL_CONSTRAINTS AC ON ACC.CONSTRAINT_NAME = AC.CONSTRAINT_NAME WHERE AC.CONSTRAINT_TYPE = 'P' ) SUBQ ON ATC.OWNER=SUBQ.OWNER AND ATC.TABLE_NAME = SUBQ.TABLE_NAME AND ATC.COLUMN_NAME = SUBQ.COLUMN_NAME 
/*FK*/ LEFT JOIN ( SELECT c.owner, a.table_name, a.column_name, c_pk.table_name AS r_table_name, b.column_name AS r_column_name, c_pk.table_name ||'('|| b.column_name || ')' AS FOREIGN_KEY FROM user_cons_columns a JOIN user_constraints c ON a.owner = c.owner AND a.constraint_name = c.constraint_name JOIN user_constraints c_pk ON c.r_owner = c_pk.owner AND c.r_constraint_name = c_pk.constraint_name JOIN user_cons_columns b ON C_PK.owner = b.owner AND C_PK.CONSTRAINT_NAME = b.constraint_name AND b.POSITION = a.POSITION WHERE c.constraint_type = 'R') FK ON ATC.TABLE_NAME = FK.TABLE_NAME AND ATC.COLUMN_NAME = FK.COLUMN_NAME
/*COMMENTS*/ LEFT JOIN SYS.ALL_COL_COMMENTS COM ON COM.OWNER = ATC.OWNER AND COM.TABLE_NAME = ATC.TABLE_NAME AND COM.COLUMN_NAME = ATC.COLUMN_NAME 
WHERE 1=1
-------------------INSERT TABLE -------------------------
AND (ATC.OWNER IN ('DB10_MDM_COMMON') AND ATC.TABLE_NAME IN ('T10112_IPKO_ACTIVITY','T10113_IPKO_LOGIN','T10114_IPKO_USER_AGENT'))
------------------------------------------------------------
AND ATC.COLUMN_NAME NOT LIKE ('SYS_ST%') -- usuwa kolumny systemowe
AND ATC.COLUMN_NAME NOT IN ('DUE_DT')
AND ATC.COLUMN_NAME NOT IN ('LOAD_ID','UPDATE_ID','SRC_SYS_ID','SYS_ID','EFFECTIVE_ST_DT','EFFECTIVE_END_DT')
ORDER BY ATC.TABLE_NAME, ATC.COLUMN_ID;