# General
generor_mode = 'SDA' # ['Spec', 'LDM', 'STM', 'SDA', 'xDA']
xDA = 'SDA'
calendar_flg = 'ALL' # ['ALL', 'WORKING', 'CUSTOM', 'OZSI', 'LAST_MONTH_DAY']
wf_ID = 'CREDIT_SUSPENSION' # dla EDA analogicznie jak dla IDA/ADA (nazwa potrzebna np. dla wspólnego scheulera dla kilku tabel)
package_id = 'NEMO'  # max 8 letters
version = '04.00'

# input here sheet_names, table_names or table codes ('txxxxxx')
new_table_codes = ['t220044'] # used only by 'LDM', 'STM', 'xDA'

output_ldm_file_path = rf"C:\Dane\repo\python\Generator\_output\ipko_logs_IDA_LDM_v0.1.xlsx"  # olny only by 'LDM', 'xDA'
output_stm_file_path = rf"C:\Dane\repo\python\Generator\_output\ipko_logs_IDA_STM_v0.1.xlsx"  # used only by 'xDA'


################################################################################################
# xDA
################################################################################################

# filled or empty - wyciągnąć z metadanych po wykonaniu INSERTÓW i przegenerować, aby aktualizować semafory w obiektach ANOW
sem_bin_names = {
	'WFL_GCP_EDA_T602011_DEBT_RECOVE_PZKB_01': [
		'DTLK_RSC_SEM_DATALAKE_GCP_ADA_CUST_PZKB',
		'DTLK_RSC_SEM_DATALAKE_GCP_RDA_102_OHIO_DATA_IDA_02_HST_T02341_GARNISHMENT',
		'DTLK_RSC_SEM_DATALAKE_GCP_RDA_102_OHIO_DATA_IDA_02_HST_T02343_GARNISHMENT_CUST_REL'
	]
}


################################################################################################
# SDA
################################################################################################
sda_sheet_names = ['nemo_cred_susp']  # input here sheet_names, table_names or table codes ('txxxxxx')
tech_spec_file_path = rf"C:\Dane\repo\python\Generator\_output\Specyfikacja_interfejsów_NEMO_v1.0.xlsx"


################################################################################################
# Tech Spec generator
################################################################################################
sda_sys_cd = 'NEMO'
sda_type = 'FILE' # ['FILE', 'DB']
sda_tgt_schema_name = 'sda_220_nemo_data' ## new schema
sda_table_map = {
	'zawieszenia_PG_20241030_01': 't220044_nemo_cred_susp',
}


# wyciągnięte z bazy oracle - użyj F5
# @"C:\Dane\repo\python\Generator\STM\sql\tech_spec.sql"
# UWAGA! keep table_name proper order! 
# sda_atc = [
# 	{"table_name":"WEB_IPKO_ACTIVITY","column_id":1,"pk":"null","column_name":"event_dttm","data_type":"TIMESTAMP","data_precision":"null","column_name_2":"event_dttm","data_type_2":"TIMESTAMP","data_precision_2":"null3","format":"%Y-%m-%d %H:%M:%S","description":"null","standarization_busn":"null","standarization_tech":"null","dlugosc_nazwy_pola":"null","uwagi":"null","wersja":"null","zmiana":"null","komentarze_do_zmiany":"null"}
# ]
sda_atc = [
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 1, 'pk': 'NIE', 'column_name': 'nr_sprawy_nemo_dyspozycji', 'data_type': 'string', 'data_length': 9, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '42F06CE4E'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 2, 'pk': 'NIE', 'column_name': 'aktualny_status_dyspozycji', 'data_type': 'string', 'data_length': 42, 'data_precision': None, 'data_scale': None, 'format': None, 'description': 'DYSPOZYCJA/ZLECENIE ZREALIZOWANE - AUTOMAT'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 3, 'pk': 'NIE', 'column_name': 'deklaracja_czy_powodz_2024', 'data_type': 'string', 'data_length': 3, 'data_precision': None, 'data_scale': None, 'format': None, 'description': 'Nie'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 4, 'pk': 'NIE', 'column_name': 'data_rejestracji_dyspozycji', 'data_type': 'date', 'data_length': 10, 'data_precision': None, 'data_scale': None, 'format': '%Y-%m-%d', 'description': '2024-09-23'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 5, 'pk': 'NIE', 'column_name': 'pid_klienta', 'data_type': 'integer', 'data_length': 8, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '66458743'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 6, 'pk': 'NIE', 'column_name': 'kod_pocztowy_adresu_klienta', 'data_type': 'string', 'data_length': 6, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '28-305'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 7, 'pk': 'NIE', 'column_name': 'numer_nrb_zawieszanej_pozyczki', 'data_type': 'string', 'data_length': 26, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '08102027330000219600439999'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 8, 'pk': 'NIE', 'column_name': 'data_konca_kredytu', 'data_type': 'date', 'data_length': 10, 'data_precision': None, 'data_scale': None, 'format': '%Y-%m-%d', 'description': '2029-08-10'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 9, 'pk': 'NIE', 'column_name': 'aktualne_saldo_kapitalu_do_splaty', 'data_type': 'decimal', 'data_length': 9, 'data_precision': 8, 'data_scale': 2, 'format': None, 'description': '104386.73'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 10, 'pk': 'NIE', 'column_name': 'kwota_raty', 'data_type': 'decimal', 'data_length': 7, 'data_precision': 6, 'data_scale': 2, 'format': None, 'description': '1342.75'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 11, 'pk': 'NIE', 'column_name': 'pierwotna_kwota_raty', 'data_type': 'string', 'data_length': 'empty', 'data_precision': None, 'data_scale': None, 'format': '', 'description': 'empty'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 12, 'pk': 'NIE', 'column_name': 'dzien_splaty_raty', 'data_type': 'date', 'data_length': 10, 'data_precision': None, 'data_scale': None, 'format': '%Y-%m-%d', 'description': '2024-10-10'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 13, 'pk': 'NIE', 'column_name': 'stopa_procentowa_pozyczki_rrso', 'data_type': 'decimal', 'data_length': 7, 'data_precision': 6, 'data_scale': 4, 'format': None, 'description': '19.5496'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 14, 'pk': 'NIE', 'column_name': 'ilosc_zawieszanych_rat_kapitalowych', 'data_type': 'integer', 'data_length': 1, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '2'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 15, 'pk': 'NIE', 'column_name': 'ilosc_zawieszanych_rat_odsetkowych', 'data_type': 'integer', 'data_length': 1, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '2'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 16, 'pk': 'NIE', 'column_name': 'ilosc_rat_kapitalowych_zawieszonych_dotychczas', 'data_type': 'string', 'data_length': 1, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '0'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 17, 'pk': 'NIE', 'column_name': 'ilosc_rat_odsetkowych_zawieszonych_dotychczas', 'data_type': 'string', 'data_length': 1, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '0'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 18, 'pk': 'NIE', 'column_name': 'opcja_splaty_kapitalu', 'data_type': 'string', 'data_length': 7, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '1WYDOKR'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 19, 'pk': 'NIE', 'column_name': 'opcja_splaty_odsetek', 'data_type': 'string', 'data_length': 7, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '4ROZRAT'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 20, 'pk': 'NIE', 'column_name': 'wyliczona_kwota_prowizji_za_zawieszenie', 'data_type': 'decimal', 'data_length': 6, 'data_precision': 5, 'data_scale': 2, 'format': None, 'description': '120.85'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 21, 'pk': 'NIE', 'column_name': 'wyliczona_kwota_prowizji_za_prolongate', 'data_type': 'decimal', 'data_length': 6, 'data_precision': 5, 'data_scale': 2, 'format': None, 'description': '404.03'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 22, 'pk': 'NIE', 'column_name': 'oprocentowanie_pozyczki', 'data_type': 'decimal', 'data_length': 5, 'data_precision': 4, 'data_scale': 2, 'format': None, 'description': '17.99'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 23, 'pk': 'NIE', 'column_name': 'data_zawarcia_umowy_pozyczki', 'data_type': 'date', 'data_length': 10, 'data_precision': None, 'data_scale': None, 'format': '%Y-%m-%d', 'description': '2024-08-09'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 24, 'pk': 'NIE', 'column_name': 'okres_kredytowania_opisowo', 'data_type': 'string', 'data_length': 'empty', 'data_precision': None, 'data_scale': None, 'format': '', 'description': 'empty'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 25, 'pk': 'NIE', 'column_name': 'kanal_zlozenia_dyspozycji', 'data_type': 'string', 'data_length': 3, 'data_precision': None, 'data_scale': None, 'format': None, 'description': 'IKO'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 26, 'pk': 'NIE', 'column_name': 'czy_wniosek_z_cc', 'data_type': 'string', 'data_length': 3, 'data_precision': None, 'data_scale': None, 'format': None, 'description': 'Nie'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 27, 'pk': 'NIE', 'column_name': 'czy_kredyt_konsumencki', 'data_type': 'string', 'data_length': 3, 'data_precision': None, 'data_scale': None, 'format': None, 'description': 'Tak'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 28, 'pk': 'NIE', 'column_name': 'maksymalny_okres_kredytowania_dla_produktu', 'data_type': 'integer', 'data_length': 3, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '120'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 29, 'pk': 'NIE', 'column_name': 'nowy_okres_kredytowania', 'data_type': 'decimal', 'data_length': 4, 'data_precision': 3, 'data_scale': 1, 'format': None, 'description': '62.0'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 30, 'pk': 'NIE', 'column_name': 'liczba_rat_do_splaty_po_zawieszeniu', 'data_type': 'integer', 'data_length': 3, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '114'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 31, 'pk': 'NIE', 'column_name': 'kod_celu_przeznaczenia_pozyczki', 'data_type': 'integer', 'data_length': 5, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '50448'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 32, 'pk': 'NIE', 'column_name': 'pesel_wnioskodawcy', 'data_type': 'integer', 'data_length': 11, 'data_precision': None, 'data_scale': None, 'format': None, 'description': '99072308572'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 33, 'pk': 'NIE', 'column_name': 'pid_wspolposiadacza', 'data_type': 'string', 'data_length': 'empty', 'data_precision': None, 'data_scale': None, 'format': '', 'description': 'empty'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 34, 'pk': 'NIE', 'column_name': 'pesel_wspolposiadacza', 'data_type': 'string', 'data_length': 'empty', 'data_precision': None, 'data_scale': None, 'format': '', 'description': 'empty'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 35, 'pk': 'NIE', 'column_name': 'czesc_kapitalowa_kolejnych_rat_1', 'data_type': 'decimal', 'data_length': 7, 'data_precision': 6, 'data_scale': 2, 'format': None, 'description': '3143.72'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 36, 'pk': 'NIE', 'column_name': 'czesc_odsetkowa_kolejnych_rat_1', 'data_type': 'decimal', 'data_length': 7, 'data_precision': 6, 'data_scale': 2, 'format': None, 'description': '1612.72'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 37, 'pk': 'NIE', 'column_name': 'czesc_kapitalowa_kolejnych_rat_2', 'data_type': 'decimal', 'data_length': 7, 'data_precision': 6, 'data_scale': 2, 'format': None, 'description': '3153.56'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 38, 'pk': 'NIE', 'column_name': 'czesc_odsetkowa_kolejnych_rat_2', 'data_type': 'decimal', 'data_length': 7, 'data_precision': 6, 'data_scale': 2, 'format': None, 'description': '1655.65'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 39, 'pk': 'NIE', 'column_name': 'czesc_kapitalowa_kolejnych_rat_3', 'data_type': 'decimal', 'data_length': 7, 'data_precision': 6, 'data_scale': 2, 'format': None, 'description': '1083.94'},
{'table_name': 'zawieszenia_PG_20241030_01', 'lp': 40, 'pk': 'NIE', 'column_name': 'czesc_odsetkowa_kolejnych_rat_3', 'data_type': 'decimal', 'data_length': 7, 'data_precision': 6, 'data_scale': 2, 'format': None, 'description': '1592.18'}
]


################################################################################################
# LDM generator
################################################################################################
xda_tgt_schema_name = 'ida_429_digital_channels_data' ## new schema
xda_table_map = {
	'T10112_IPKO_ACTIVITY': 'T429043_IPKO_ACTIVITY',
	'T10113_IPKO_LOGIN': 'T429044_IPKO_LOGIN',
	'T10114_IPKO_USER_AGENT': 'T429045_IPKO_USER_AGENT',
}

ldm_table_types = [
	{"table_name":"T10112_IPKO_ACTIVITY","apply_mode_id":"TRANSINSRT"}
	,{"table_name":"T10113_IPKO_LOGIN","apply_mode_id":"TRANSINSRT"}
	,{"table_name":"T10114_IPKO_USER_AGENT","apply_mode_id":"TRANSINSRT"}
]


# wyciągnięte z bazy oracle - użyj F5
# @"C:\Dane\repo\python\Generator\STM\sql\LDM.sql"
# UWAGA! keep table_name proper order!
# ldm_atc = [
# {"table_name":"T60911_ODD_RAP_CTL_CLOSE_TO_LOOP","column_name":"touchedcount","type":"NUMERIC(,)","wersja":"1.0","zmiana":"I"}
# ]
ldm_atc = [
	{"table_name":"T10112_IPKO_ACTIVITY","column_name":"EVENT_DTTM","data_type":"TIMESTAMP(,6)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10112_IPKO_ACTIVITY","column_name":"EVENT_DT","data_type":"DATE","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10112_IPKO_ACTIVITY","column_name":"ORIG_CUST_ID","data_type":"VARCHAR2(10 CHAR)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10112_IPKO_ACTIVITY","column_name":"SESSION_ID","data_type":"CHAR(29 CHAR)","pk":"PRIMARY KEY","nullable":"NOTNULL"}
	,{"table_name":"T10112_IPKO_ACTIVITY","column_name":"URL","data_type":"CHAR(70 CHAR)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10112_IPKO_ACTIVITY","column_name":"SERVICE_TYPE_CD","data_type":"CHAR(1 CHAR)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10112_IPKO_ACTIVITY","column_name":"HTTP_PARAMETERS","data_type":"VARCHAR2(2000 CHAR)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10113_IPKO_LOGIN","column_name":"LOGIN_DTTM","data_type":"TIMESTAMP(,6)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10113_IPKO_LOGIN","column_name":"LOGIN_DT","data_type":"DATE","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10113_IPKO_LOGIN","column_name":"IP","data_type":"VARCHAR2(15 CHAR)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10113_IPKO_LOGIN","column_name":"ORIG_CUST_ID","data_type":"VARCHAR2(10 CHAR)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10113_IPKO_LOGIN","column_name":"SESSION_ID","data_type":"CHAR(29 CHAR)","pk":"PRIMARY KEY","nullable":"NOTNULL"}
	,{"table_name":"T10113_IPKO_LOGIN","column_name":"IAS","data_type":"CHAR(1 CHAR)","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10114_IPKO_USER_AGENT","column_name":"SESSION_DT","data_type":"DATE","pk":"NOT A KEY","nullable":"NULL"}
	,{"table_name":"T10114_IPKO_USER_AGENT","column_name":"SESSION_ID","data_type":"CHAR(29 CHAR)","pk":"PRIMARY KEY","nullable":"NOTNULL"}
	,{"table_name":"T10114_IPKO_USER_AGENT","column_name":"USER_AGENT","data_type":"VARCHAR2(400 CHAR)","pk":"NOT A KEY","nullable":"NULL"}
]



################################################################################################
# STM generator
################################################################################################
stm_sys_cd = 'NEMO'
stm_tgt_schema_name = 'ida_429_digital_channels_data'


# fill in if input_stm_file_path is empty or None
stm_source_lst = {
	't429044_ipko_login': ['sda_241_ipko_data.t241019_web_ipko_login'],
	't429043_ipko_activity': ['sda_241_ipko_data.t241020_web_ipko_activity'],
	't429045_ipko_user_agent': ['sda_241_ipko_data.t241020_web_ipko_activity'],
}




################################################################################################
# MAIN
################################################################################################
from pathlib import Path
import sys


if __name__ == "__main__":
	if generor_mode == 'Spec':
		sys.path.append(Path(__file__).parent.joinpath('STM').as_posix())
		from STM import _generator_Tech_spec
	elif generor_mode == 'LDM':
		sys.path.append(Path(__file__).parent.joinpath('STM').as_posix())
		from STM import _generator_LDM
	elif generor_mode == 'STM':
		sys.path.append(Path(__file__).parent.joinpath('STM').as_posix())
		from STM import _generator_STM
	elif generor_mode == 'SDA':
		sys.path.append(Path(__file__).parent.joinpath('SDA').as_posix())
		from SDA import _generator_SDA
	elif generor_mode in ['IDA', 'ADA', 'EDA', 'xDA']:
		sys.path.append(Path(__file__).parent.joinpath('xDA').as_posix())
		from xDA import _generator_xDA


# # Manually generate/update INSTALL.txt file
# sys.path.append(Path(__file__).parent.parent.as_posix())
# from xDA.gen_xda_install import generate_install_files
# package_path = Path(r'C:\Dane\repo\git\INSTALL\GCP\GCP-ADA_WR-05.05')
# generate_install_files(package_path, package_path.name)



