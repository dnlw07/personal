import os
import re
from pathlib import Path
from glob import glob
from excel_functions_ida import *


# def generate_tag_list_file(output_package_path, wfl_name, calendar_name, scheduler_name, stock_name, sin_publish_sem_name, process_names, calendar_flg):
def generate_object_list_file(output_path, locals_dct):

	list_txt = f'''
tag: {locals_dct['tag_name']}
package: {locals_dct['package_name']}

workflow: {locals_dct['wfl_name']}

process: 
{f'{chr(10)}'.join([item['proc_nm'] for item in locals_dct['t00014_process_definition_dct']])}

scheduler: {locals_dct['scheduler_name']}
calendar: {locals_dct['calendar_name']}
stock: {locals_dct['stock_name']}
semafore: {locals_dct['sin_publish_sem_name']}
semafore TI: {locals_dct['sin_ti_sem_nm_013']}
metric: {locals_dct['sin_metric_name']}


target schema: {locals_dct['target_schema']}

target table: 
{f'{chr(10)}'.join([f"{item['table_nm']}, {item['model_table_type_cd']}, {item['pk_column_list']}" for item in locals_dct['t00010_table_definition_dct']])}, 

procedure: 
{f'{chr(10)}'.join([item['processing_nm'] for item in locals_dct['t00014_process_definition_dct']])}
'''
	list_txt = re.sub('\.json', '', list_txt)


	# save procedure into file
	install_file = f"{locals_dct['xDA']}_{locals_dct['package_id']}_object_list.yaml"
	install_file_path = os.path.join(output_path, install_file)
	with open(install_file_path, 'w', encoding='utf-8') as f:
		f.write(list_txt)

