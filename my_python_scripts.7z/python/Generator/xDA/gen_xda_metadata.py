import os
import numpy as np
from excel_functions_ida import *
from datetime import datetime


def generate_metadata_files(local_scope_dct, output_path, output_package_path, xDA, package_name, sources_in_proc_dct):

	# log_meta_tables = ['t01006_rule_exec_log', 't01004_proc_load_hst', 't01003_wfl_load_hst']
	if xDA in ['ADA', 'IDA']:
		delete_meta_tables = ['t00012_source_target_map', 't00016_etl_pkg_definition', 't00017_rule_definition', 't00010_table_definition', 't00014_process_definition', 't00013_workflow_definition', 't00001_param']
		insert_meta_tables = ['t00010_table_definition', 't00013_workflow_definition', 't00014_process_definition', 't00016_etl_pkg_definition', 't00012_source_target_map', 't00017_rule_definition', 't00001_param']
	elif xDA == 'EDA':
		delete_meta_tables = ['t00027_export_definition', 't00012_source_target_map', 't00016_etl_pkg_definition', 't00017_rule_definition', 't00010_table_definition', 't00001_param']
		insert_meta_tables = ['t00027_export_definition', 't00010_table_definition', 't00016_etl_pkg_definition', 't00012_source_target_map', 't00017_rule_definition', 't00001_param']


	# generate log scripts for each meta table
	meta_dct = local_scope_dct['log_tables_dct']  # indirect variable call
	dataset_nm = "','".join([elem['dataset_nm'] for elem in meta_dct])
	table_nm = "','".join([elem['table_nm'] for elem in meta_dct])
	proc_nm = "','".join(list(dict.fromkeys([elem['proc_nm'] for elem in meta_dct])))
	wfl_nm = "','".join(list(dict.fromkeys([elem['wfl_nm'] for elem in meta_dct])))
	sys_cd = "','".join(list(dict.fromkeys([elem['sys_cd'] for elem in meta_dct])))
	
	select_logs_lst = [f"-- check SDA logs"]
	select_logs_lst.append(f"select * from mda_04_sem.t04001_dtlk_load_ext_sys_sem where 1=1 and sys_cd = 'PZKB' /* and gcp_table_nm in ('gcp_table_nm') */ order by tech_insert_ts desc;")
	select_logs_lst.append(f"select load_key, tech_update_ts, extract_due_dt, extract_version, sys_cd, extract_nm , gcp_dataset_nm, gcp_table_nm, db_connection_nm, import_status_cd from mda_01_log.t01001_dtlk_load_control where 1=1 and gcp_etl_pkg_cd in ('{sys_cd}_01') /* and gcp_table_nm in ('gcp_table_nm') */ order by tech_update_ts desc;")
	select_logs_lst.append(f"-- select * from mda_01_log.t01001_dtlk_load_control where 1=1 and gcp_etl_pkg_cd in ('{sys_cd}_01') order by tech_insert_ts desc;")
	select_logs_lst.append('')
	select_logs_lst.append(f'-- check {xDA.upper()} logs')
	select_logs_lst.append(f"-- select * from mda_01_log.t01006_rule_exec_log where 1=1 and table_nm in ('{table_nm}');")
	select_logs_lst.append(f"-- select * from mda_01_log.t01004_proc_load_hst where 1=1 and wfl_nm in ('{wfl_nm}');")
	select_logs_lst.append(f"select * from mda_01_log.t01003_wfl_load_hst where 1=1 and wfl_nm in ('{wfl_nm}');")
	select_logs_lst.append('')
	select_logs_lst.append('')

	select_script_lst = [f'-- check {xDA.upper()} metadata']
	insert_script_lst = [f'-- insert {xDA.upper()} metadata']



	# generate delete scripts for each meta table
	for meta_table in delete_meta_tables:

		meta_dct = local_scope_dct[f'{meta_table}_dct']  # indirect variable call

		if meta_table == 't00001_param' and len(meta_dct) != 0:
			table_nm = "','".join([elem['table_nm'] for elem in meta_dct])
			dataset_nm = "','".join(list(dict.fromkeys([elem['dataset_nm'] for elem in meta_dct])))
			select_script = f"select * from mda_00_def.{meta_table} where 1=1 and etl_pkg_cd = '{meta_dct[0]['etl_pkg_cd']}' and table_nm = '{meta_dct[0]['table_nm']}';"
		elif meta_table == 't00010_table_definition':
			select_script = f"select * from mda_00_def.{meta_table} where 1=1 and dataset_nm = '{dataset_nm}' and table_nm in ('{table_nm}') order by table_nm;"
			select_script += f"\n-- select * from mda_00_def.{meta_table} where 1=1 and dataset_nm = '{dataset_nm}' order by table_nm;"
		elif meta_table == 't00012_source_target_map':
			proc_nm = "','".join(list(dict.fromkeys([elem['proc_nm'] for elem in meta_dct])))
			select_script = f"select * from mda_00_def.{meta_table} where 1=1 and proc_nm in ('{proc_nm}') order by proc_nm asc, table_rel_type_cd desc, table_nm;"
			select_script += f"\n-- select * from mda_00_def.{meta_table} where 1=1 and proc_nm like ('WFL_GCP_{xDA}_%_{sys_cd}_01') order by proc_nm asc, table_rel_type_cd desc, table_nm;"
		elif meta_table == 't00013_workflow_definition':
			wfl_nm = "','".join(list(dict.fromkeys([elem['wfl_nm'] for elem in meta_dct])))
			select_script = f"select * from mda_00_def.{meta_table} where 1=1 and wfl_nm in ('{wfl_nm}');"
		elif meta_table == 't00014_process_definition':
			wfl_nm = "','".join(list(dict.fromkeys([elem['wfl_nm'] for elem in meta_dct])))
			select_script = f"select * from mda_00_def.{meta_table} where 1=1 and wfl_nm in ('{wfl_nm}');"
		elif meta_table == 't00016_etl_pkg_definition':
			table_nm = "','".join([elem['table_nm'] for elem in meta_dct])
			dataset_nm = "','".join(list(dict.fromkeys([elem['dataset_nm'] for elem in meta_dct])))
			gcp_etl_pkg_cd = "','".join(list(dict.fromkeys([elem['gcp_etl_pkg_cd'] for elem in meta_dct])))
			select_script = f"select * from mda_00_def.{meta_table} where 1=1 and gcp_etl_pkg_cd = '{gcp_etl_pkg_cd}' and dataset_nm = '{dataset_nm}' and table_nm in ('{table_nm}') order by table_nm;"
			select_script += f"\n-- select * from mda_00_def.{meta_table} where 1=1 and gcp_etl_pkg_cd = '{gcp_etl_pkg_cd}' and dataset_nm = '{dataset_nm}' order by table_nm;"
		elif meta_table == 't00017_rule_definition':
			table_nm = "','".join([elem['table_nm'] for elem in meta_dct])
			gcp_etl_pkg_cd = "','".join(list(dict.fromkeys([elem['gcp_etl_pkg_cd'] for elem in meta_dct])))
			select_script = f"select * from mda_00_def.{meta_table} where 1=1 and gcp_etl_pkg_cd = '{gcp_etl_pkg_cd}' and table_nm in ('{table_nm}') order by table_nm;"
			select_script += f"\n-- select * from mda_00_def.{meta_table} where 1=1 and gcp_etl_pkg_cd = '{gcp_etl_pkg_cd}' order by table_nm;"
		elif meta_table == 't00027_export_definition':
			# wfl_nm = "','".join(list(dict.fromkeys([elem['export_cd'] for elem in meta_dct])))
			proc_nm = "','".join(list(dict.fromkeys([elem['export_cd'] for elem in meta_dct])))
			gcp_etl_pkg_cd = "','".join(list(dict.fromkeys([elem['gcp_etl_pkg_cd'] for elem in meta_dct])))
			select_script = f"select * from mda_00_def.{meta_table} where 1=1 and export_cd = '{proc_nm}' and gcp_etl_pkg_cd = '{gcp_etl_pkg_cd}';"
		else:
			select_script = ''

		select_script_lst.append(select_script)
	select_script_lst.append('')
	select_script_lst.append('')


	# generate insert scripts for each meta table
	for meta_table in insert_meta_tables:
		meta_dct = local_scope_dct[f'{meta_table}_dct']  # indirect variable call

		# create insert scripts
		insert_script = generate_insert_sripts(meta_dct, 'mda_00_def', meta_table)

		if meta_table == 't00012_source_target_map':
			proc_nm = "','".join(list(dict.fromkeys([elem['proc_nm'] for elem in meta_dct])))
			# src_tables_lst = [f"'{src_table}'" for src_table, src_schema in local_scope_dct['src_table_dct'].items()]
			# src_tables_lst = [f"'{src_table}'" for src_table, src_schema in local_scope_dct['t00012_source_target_map_dct'].items()]
			# src_tables_str = ",".join(src_tables_lst)
			# t12 = f"-- generate src insert scripts manually\nINSERT INTO mda_00_def.t00012_source_target_map (proc_nm, table_nm, dataset_nm, project_id, table_rel_type_cd, gcp_etl_pkg_cd) \nselect '{proc_nm}' as proc_nm, table_nm, dataset_nm, project_id, 'SRC' as table_rel_type_cd, gcp_etl_pkg_cd from mda_00_def.t00016_etl_pkg_definition where table_nm in ({src_tables_str.lower()});\n\n"
			t12 = f"-- generate src insert scripts manually\nINSERT INTO mda_00_def.t00012_source_target_map (proc_nm, table_nm, dataset_nm, project_id, table_rel_type_cd, gcp_etl_pkg_cd)\n"
			for proc_nm_k, src_dataset_table_lst in sources_in_proc_dct.items():
				src_table_nm_str = "','".join([re.sub('_act$', '', item[1]) for item in src_dataset_table_lst])
				t12 += f"select '{proc_nm_k}' as proc_nm, table_nm, dataset_nm, project_id, 'SRC' as table_rel_type_cd, gcp_etl_pkg_cd from mda_00_def.t00016_etl_pkg_definition where table_nm in ('{src_table_nm_str.lower()}') union all\n"
			t12 = t12[:-11] # remove union all from last line
			t12 += ';\n\n'
			insert_script += t12

		# create dml script body
		# dml_script = f'{delete_script}\n\n{insert_scripts_txt}\n\n\n'
		# insert_script = f'{insert_scripts_txt}\n\n\n'

		# create files to store the SQL scripts
		file_path = rf'{output_package_path}\POSTGRES\DML\{meta_table}.sql'
		
		# if xDA == 'EDA' and meta_table not in ['t00013_workflow_definition','t00014_process_definition']:
		# 	with open(file_path, 'w', encoding='utf-8') as file:
		# 		file.write(insert_script)
		# 	insert_script_lst.append(insert_script)
		# elif xDA in  ['ADA', 'IDA'] and meta_table not in ['t00027_export_definition']:
		# 	with open(file_path, 'w', encoding='utf-8') as file:
		# 		file.write(insert_script)
		# 	insert_script_lst.append(insert_script)

		with open(file_path, 'w', encoding='utf-8') as file:
			file.write(insert_script)
		insert_script_lst.append(insert_script)


	# add select scripts
	select_scripts_lst = select_logs_lst + select_script_lst

	delete_scripts_lst = select_scripts_lst
	delete_scripts_lst = [re.sub(r'^-- check', '-- -- delete', elem) for elem in delete_scripts_lst]
	delete_scripts_lst = [re.sub(r'select .+ from ', '-- delete from ', elem) for elem in delete_scripts_lst]
	delete_scripts_lst = [re.sub(r'\n-- delete from .*', '', elem) for elem in delete_scripts_lst]
	delete_scripts_lst = [re.sub(r'(\/\* )|( \*\/)', '', elem) for elem in delete_scripts_lst]
	delete_scripts_lst = [re.sub(r' order by .*?;', ';', elem) for elem in delete_scripts_lst]
	delete_scripts_lst[3] = '' # delete last entry


	# add semafor check
	semafore_check_sql = f"""-- sem check
select distinct
t12.proc_nm,
t10.dataset_nm,
t12.table_nm as src_table_nm,
coalesce(t13_2.sin_publish_sem_nm, t10.sin_publish_sem_nm) as publish_sem,
case 
when t13_2.sin_publish_sem_nm is not null then 'OBSZAROWY' 
when t10.sin_publish_sem_nm is not null then 'TABELARYCZNY'
else 'BRAK'
end as sem_flg,
calendar_nm
from mda_00_def.t00012_source_target_map t12
left join  mda_00_def.t00012_source_target_map t12_2
on t12.table_nm = t12_2.table_nm
and t12_2.table_rel_type_cd = 'TGT'
left join mda_00_def.t00014_process_definition t14_2
on t12_2.proc_nm = t14_2.proc_nm
left join mda_00_def.t00013_workflow_definition t13_2
on t13_2.wfl_nm = t14_2.wfl_nm
left join mda_00_def.t00010_table_definition t10
on t12.table_nm = t10.table_nm
where 1=1 
and t12.table_rel_type_cd = 'SRC'
and t12.dataset_nm not like 'sda_%'
and t12.dataset_nm <> 'ida_498_dictionaries_data'
and t12.proc_nm in ('{proc_nm}')
;\n\n"""



	table_nm_lst = [elem['table_nm'] for elem in local_scope_dct['log_tables_dct']]
	dataset_nm_lst = [elem['dataset_nm'] for elem in local_scope_dct['log_tables_dct']]
	distinct_sql_lst = [f'select * from {dataset_nm}.{table_nm} union all' for dataset_nm, table_nm in zip(dataset_nm_lst, table_nm_lst)]
	select_sql = '\n'.join(distinct_sql_lst)
	count_sql = re.sub(rf'\*', rf'count(*)', select_sql)

	select_sql = f'\n\n\n---------------------------------------------------------------------------------------\n/* paste to BQ */\n---------------------------------------------------------------------------------------\n-- check data\n{select_sql[:-10]};\n\n'
	select_sql = re.sub(rf' union all', rf';', select_sql)
	count_sql = f'-- check count\n{count_sql[:-10]};\n\n'


	dataset_nm_lst = [item[0] for dummy, src_dataset_table_lst in sources_in_proc_dct.items() for item in src_dataset_table_lst]
	table_nm_lst = [item[1] for dummy, src_dataset_table_lst in sources_in_proc_dct.items() for item in src_dataset_table_lst]
	distinct_sql_lst = [f'\tselect distinct due_dt from {dataset_nm}.{table_nm} union all' for dataset_nm, table_nm in zip(dataset_nm_lst, table_nm_lst)]
	distinct_sql_txt = '\n'.join(distinct_sql_lst)


	bq_due_dt_check_sql = f"""-- wygeneruj skrypt sprawdzający czy na BQ występuje DUE_DT dla wszysthich tabel źródłowych
select 'with query as (' union all
select 'select distinct due_dt from ' || dataset_nm || '.' || table_nm || ' union all' from mda_00_def.t00010_table_definition 
where table_nm in (
	select table_nm from mda_00_def.t00012_source_target_map 
	where 1=1 and proc_nm like upper('{proc_nm}')
)
and model_table_type_cd != 'SCD2_ACT_B' union all
select 'select ''1900-01-01'')' union all
select 'SELECT due_dt, COUNT(*) AS DUPLICATES FROM QUERY GROUP BY due_dt HAVING COUNT(*)>1 ORDER BY DUPLICATES DESC;'
"""

# 	bq_due_dt_check_sql = f'''-- due_dt check
# with query as (
# {distinct_sql_txt}
# select '1900-01-01')
# SELECT due_dt, COUNT(*) AS DUPLICATES FROM QUERY GROUP BY due_dt HAVING COUNT(*)>1 ORDER BY DUPLICATES DESC;\n\n'''

	pk_str = re.sub(r'\|', ', ', local_scope_dct['pk_str'])
	non_null_lst = [f'COUNTIF({item} IS NULL) as cnt_{item},' for item in local_scope_dct['non_null_lst']]
	non_null_str = '\n'.join(non_null_lst)
	non_null_str = non_null_str[:-1]

	null_check_sql = f'''-- null check
DECLARE in_etl_package_cd STRING;
DECLARE v_sys_cd STRING;
DECLARE v_due_dt DATE;
DECLARE v_end_dt DATE;

SET v_due_dt = PARSE_DATE("%Y/%m/%d", '2023/11/03');
SET v_end_dt = PARSE_DATE("%Y/%m/%d", "9999/12/31");



with query as (
	select * from stored_procedure
)
select 
	{non_null_str}
from query
;\n
'''

	pk_check_sql = f'''-- check duplicates
DECLARE in_etl_package_cd STRING;
DECLARE v_sys_cd STRING;
DECLARE v_due_dt DATE;
DECLARE v_end_dt DATE;

SET v_due_dt = PARSE_DATE("%Y/%m/%d", '2023/11/03');
SET v_end_dt = PARSE_DATE("%Y/%m/%d", "9999/12/31");


with query as (
	select * from stored_procedure
)
select {pk_str}, count(*) as duplicates from query group by {pk_str} having count(*)>1 order by duplicates desc
;\n\n\n
'''

	separator = ['---------------------------------------------------------------------------------------\n']
	# script_lst = select_scripts_lst  + separator +  delete_scripts_lst + separator + insert_script_lst  + separator + [semafore_check_sql] + separator + [select_sql] + separator + [count_sql] + separator + [null_check_sql] + separator + [pk_check_sql]
	script_lst = select_scripts_lst  + separator +  delete_scripts_lst + separator + insert_script_lst  + separator + [semafore_check_sql] + separator + [bq_due_dt_check_sql] + separator + [select_sql] + separator + [count_sql] + separator + [null_check_sql] + separator + [pk_check_sql]
	script_txt = '\n'.join(script_lst)


	# create a signle file to store all scripts
	file_path = rf'{output_path}\{xDA}_{package_name.upper()}_dml_metadata.sql'
	with open(file_path, 'w', encoding='utf-8') as file:
		file.write(script_txt)

	# create a signle file to store all scripts
	# timestamp = datetime.now()
	# timestamp_str = timestamp.strftime("%Y-%m-%d_%H_%M_%S_%f")
	# file_path = rf'{output_path}\_archive\backup\{xDA}_{package_name.upper()}_dml_metadata_{timestamp_str}.sql'
	# with open(file_path, 'w', encoding='utf-8') as file:
		# file.write(script_txt)

