import re

def procedure_body(procedure_name, source_schema, source_table, source_table_alias, extract_version_str, join_str, target_fields, target_schema, target_table, source_table_prefix, cast_logic, where_clause, model_table_type_cd, xDA):
	
	if xDA == 'IDA':
		procedure_param = f"""IN in_due_dt STRING,
	IN in_etl_package_cd STRING,
	IN in_surrogate_key_separator STRING,
	IN in_missing_val_replacement_text STRING,
	{extract_version_str}
	"""
		procedure_param = procedure_param.strip()[:-1]

	elif xDA == 'ADA':
		procedure_param = f"""IN in_due_dt STRING,
	IN in_etl_package_cd STRING,
	IN in_surrogate_key_separator STRING,
	IN in_missing_val_replacement_text STRING"""

	elif xDA == 'EDA':
		procedure_param = f"""IN in_due_dt STRING, 
	IN in_extract_version STRING, 
	IN in_etl_package_cd STRING, 
	IN in_load_id STRING"""

	
	where_clause = f"""WHERE 1=1
	and {source_table_alias.lower()}.due_dt = v_due_dt 
	and {source_table_alias.lower()}.extract_version = in_extract_version_{source_table_prefix}"""


	procedure_body = f"""
CREATE OR REPLACE PROCEDURE {target_schema.lower()}.{procedure_name.lower()}(
	{procedure_param}
)
BEGIN

DECLARE v_due_dt DATE;
DECLARE v_end_dt DATE;

SET v_due_dt = PARSE_DATE("%Y/%m/%d", in_due_dt);
SET v_end_dt = PARSE_DATE("%Y/%m/%d", "9999/12/31");

INSERT INTO {target_schema.lower()}.{target_table.lower()}{'_act' if model_table_type_cd == 'SCD2_ACT_B' else ''}
(
	{target_fields}
)
SELECT
	{cast_logic}
FROM {source_schema.lower()}.{source_table.lower()} {source_table_alias.lower()}\n
{join_str if xDA == 'IDA' else ''}
{where_clause if xDA == 'IDA' else ''}
;


EXCEPTION WHEN ERROR THEN
	SELECT 'load_procedure=ERROR';
	SELECT
		@@error.message,
		@@error.stack_trace,
		@@error.statement_text,
		@@error.formatted_stack_trace;
END;
"""
	return procedure_body



def ddl_body(target_schema, target_table, target_fields, create_target_fields, model_table_type_cd, xDA, target_table_suffix):

	if model_table_type_cd == 'SCD2_ACT_B':
		ddl_body = f"""
drop table if exists {target_schema.lower()}.{target_table.lower()}_act;
drop table if exists {target_schema.lower()}.{target_table.lower()}_hst;
drop table if exists {target_schema.lower()}.{target_table.lower()}_err;



create table {target_schema.lower()}.{target_table.lower()}_act (
	{create_target_fields}
)
partition by end_dt
cluster by tech_etl_pkg_cd
;



create table {target_schema.lower()}.{target_table.lower()}_hst (
	{create_target_fields}
)
partition by end_dt
cluster by tech_etl_pkg_cd
;



create table {target_schema.lower()}.{target_table.lower()}_err (
	message_level_cd string(10) not null,
	rule_id string(50) not null,

	{create_target_fields}
)
partition by end_dt
cluster by tech_etl_pkg_cd
;



CREATE OR REPLACE VIEW {target_schema.lower()}.{target_table.lower()} as (
	(
		SELECT
			{target_fields}
		FROM {target_schema.lower()}.{target_table.lower()}_act
	)
	UNION ALL (
		SELECT
			{target_fields}
		FROM {target_schema.lower()}.{target_table.lower()}_hst
	)
);

"""

	elif xDA == 'EDA':
		target_fields = re.sub(r'(\t)+tech_etl_pkg_cd,\n(\t)+tech_insert_id,\n(\t)+tech_insert_ts,', '', target_fields)
		target_fields = f'{target_fields},\n\n\t\ttech_etl_pkg_cd,\n\t\ttech_insert_id,\n\t\ttech_insert_ts'
		target_fields = re.sub(r'(\t)+', r'\t', target_fields)

		ddl_body = f"""
drop table if exists {target_schema.lower()}.{target_table.lower()};
drop table if exists {target_schema.lower()}.{target_table.lower()}_err;



create table {target_schema.lower()}.{target_table.lower()} (
	{create_target_fields}
)
partition by due_dt
cluster by extract_version
;


create table {target_schema.lower()}.{target_table.lower()}_err (
	message_level_cd string(10) not null,
	rule_id string(50) not null,

	{create_target_fields}
)
partition by due_dt
cluster by extract_version
;


create or replace view {target_schema.lower()}.v_{target_table_suffix.lower()} as (
select
	{target_fields}

from {target_schema.lower()}.{target_table.lower()}
)
;

"""

	elif model_table_type_cd in ['SCD1_ACT_B', 'SCD1_OVR_B', 'SNAP_OVR_B', 'FACT_DUEDT_B']:
		ddl_body = f"""
drop table if exists {target_schema.lower()}.{target_table.lower()};
drop table if exists {target_schema.lower()}.{target_table.lower()}_err;



create table {target_schema.lower()}.{target_table.lower()} (
	{create_target_fields}
)
partition by due_dt
cluster by tech_etl_pkg_cd
;


create table {target_schema.lower()}.{target_table.lower()}_err (
	message_level_cd string(10) not null,
	rule_id string(50) not null,

	{create_target_fields}
)
partition by due_dt
cluster by tech_etl_pkg_cd
;

"""

# 	elif model_table_type_cd == 'FACT_DUEDT_B':
# 		ddl_body = f"""
# drop table if exists {target_schema.lower()}.{target_table.lower()};
# drop table if exists {target_schema.lower()}.{target_table.lower()}_err;



# create table {target_schema.lower()}.{target_table.lower()} (
# 	{create_target_fields}
# )
# partition by due_dt
# cluster by tech_etl_pkg_cd
# ;


# create table {target_schema.lower()}.{target_table.lower()}_err (
# 	message_level_cd string(10) not null,
# 	rule_id string(50) not null,

# 	{create_target_fields}
# )
# partition by due_dt
# cluster by tech_etl_pkg_cd
# ;

# """

	return ddl_body