import os
import numpy as np
import pandas as pd
import re

# add control_panel module by adding grandparent directory into environmental variables
# from pathlib import Path
# import sys
# sys.path.append(Path(__file__).parent.parent.as_posix())
# from excel_functions import *


def generate_ddl_files(dct, t10_dct, output_package_path):

	target_schema = t10_dct[0]['dataset_nm']
	target_table = t10_dct[0]['table_nm']


	pd.options.mode.chained_assignment = None  # default='warn'
	df = pd.DataFrame(dct)
	df['Pole interfejsu źródłowego/tabeli'] = df['Pole interfejsu źródłowego/tabeli'].str.lower().str.strip()
	df['Typ danych wyjściowych'] = df['Typ danych wyjściowych'].str.lower().str.strip()
	df['Typ danych wyjściowych'] = df['Typ danych wyjściowych'].replace({'varchar2': 'string', 'char': 'string'})
	df['Typ danych wyjściowych'] = df['Typ danych wyjściowych'].str.replace(r'char(\(\d+\))', r'string\1', regex=True)
	df['Typ danych wyjściowych'] = df['Typ danych wyjściowych'].str.replace(r'varchar(\(\d+\))', r'string\1', regex=True)
	df['Typ danych wyjściowych'] = df['Typ danych wyjściowych'].str.replace(r'varchar2(\(\d+\))', r'string\1', regex=True)


	# escape special characters
	df['Krótki opis pola'] = df['Krótki opis pola'].replace('"', '\'', regex=True)
	df['Krótki opis pola'] = df['Krótki opis pola'].replace(' +', ' ', regex=True)
	df['Krótki opis pola'] = df['Krótki opis pola'].replace('–', '-', regex=True)
	df['Krótki opis pola'] = df['Krótki opis pola'].replace('‘|’', '\'', regex=True)


	# create ddl create body
	df = df.set_index('Pole interfejsu źródłowego/tabeli')
	df['create_target_fields_logic'] = df.index + ' ' + df['Typ danych wyjściowych'] + ' OPTIONS(description="' + df['Krótki opis pola'] + '")'
	
	create_target_fields_lst =  df['create_target_fields_logic'].values.tolist()
	create_target_fields_lst = [re.sub('\n', r'\\n', elem) for elem in create_target_fields_lst]
	create_target_fields_lst = [re.sub('\n', r'\\t', elem) for elem in create_target_fields_lst]
	create_target_fields_lst = [re.sub(' char', '', elem) for elem in create_target_fields_lst]
	create_target_fields = ',\n\t'.join(create_target_fields_lst)
	create_target_fields = re.sub(r'\t,\n', r'\n', create_target_fields)

	tech_fields = '''\tdue_dt date OPTIONS(description="data ładowania danych (biznesowa) - pobierana z nazwy dostarczonego pliku, lub wypełniana na etapie konwersji pliku na podstawie pola występujacego w polu pliku"),
\textract_version string(100) OPTIONS(description="wersja danych - wypełniane z nazwy pliku lub z tabeli t01007_bucket_notification z pola object_version. wartość pola przekazywana w ścieżce do obiektu w buckecie extract_version=<value>"),
\tsys_cd string(10) OPTIONS(description="wartość stała dla danego ekstraktu pobierana z tabeli t01001_dtlk_load_control kolumna sys_cd"),
\ttech_insert_id string(500) OPTIONS(description="kolumna techniczna: itentyfikator zadania ładującego dane"),
\ttech_insert_ts timestamp default cast(CURRENT_DATETIME('Europe/Warsaw') AS TIMESTAMP) OPTIONS(description="kolumna techniczna: timestamp z jakim zostały załadowane dane"),
'''

	ddl_body_txt = f"""
drop table if exists {target_schema.lower()}.{target_table.lower()};


create table {target_schema.lower()}.{target_table.lower()} (
{tech_fields}
\t{create_target_fields}
)
partition by due_dt
cluster by extract_version
;

"""

	#%%
	# save procedure into file
	ddl_file = f'{target_table}.sql'
	ddl_file_path = os.path.join(output_package_path, 'BQ/DDL', ddl_file)
	with open(ddl_file_path, 'w', encoding='utf-8') as f:
		f.write(ddl_body_txt)

