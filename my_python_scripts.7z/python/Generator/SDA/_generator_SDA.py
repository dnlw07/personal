#%%
import os # manipulacje ścieżkami
from glob import glob # umożliwia stosowanie wildcars podczas podawania ścieżek
import re
import pandas as pd
from openpyxl import load_workbook, Workbook
# from datetime import datetime
# import numpy as np
# from shutil import copy
# from openpyxl.utils import get_column_letter as letter # convert number to letter
# from openpyxl.utils.cell import column_index_from_string as number # convert letter to number
from copy import deepcopy
from gen_sda_ddl import generate_ddl_files
from gen_sda_metadata import generate_metadata_files
from gen_sda_install import generate_install_files
# from gen_tag_list import generate_tag_list_file


# add control_panel module by adding grandparent directory into environmental variables
from pathlib import Path
import sys
sys.path.append(Path(__file__).parent.parent.as_posix())
from excel_functions import *
from control_panel import package_id, xDA, version, tech_spec_file_path, sda_sheet_names



########################################################################################################################
# CONTROL PANEL
########################################################################################################################

xDA = 'SDA'
# package_id = 'ACCB'
# sda_sheet_names = ['BGDTMDF','BGDTIAF']  # input here sheet_names, table_names or table codes ('txxxxxx')
# tech_spec_file_path = rf"C:\Users\PZ006369\Desktop\Specyfikacje_Interfejsow_OZSI_v0.14.xlsx"
# version = '01.00'

########################################################################################################################


tech_spec_wb_paths = [tech_spec_file_path] # if None then generates only DDL files
package_name = f'GCP-{xDA}_{package_id}-{version}'
tag_name = f'GCP_{xDA}_{package_id}_{version}'

# path to executable file
# base_path = os.path.dirname(__file__)
# output_package_path = os.path.join(base_path, 'output', package_name)
output_path = rf'C:\Dane\repo\python\Generator\_output'
output_package_path = rf'C:\Dane\repo\python\Generator\_output\{package_name}'


# create missing folders in a package if yet not exist
if not os.path.exists(os.path.join(output_package_path)):
	os.makedirs(os.path.join(output_package_path))
if not os.path.exists(os.path.join(output_package_path, 'BQ')):
	os.makedirs(os.path.join(output_package_path, 'BQ'))
if not os.path.exists(os.path.join(output_package_path, 'BQ', 'DDL')):
	os.makedirs(os.path.join(output_package_path, 'BQ', 'DDL'))
if not os.path.exists(os.path.join(output_package_path, 'POSTGRES')):
	os.makedirs(os.path.join(output_package_path, 'POSTGRES'))
if not os.path.exists(os.path.join(output_package_path, 'POSTGRES', 'DML')):
	os.makedirs(os.path.join(output_package_path, 'POSTGRES', 'DML'))


# clear output directory
[os.remove(file) for file in glob(os.path.join(output_package_path, '**\*.sql'), recursive=True)] # wywala błąd jeżeli plik w folderze jest używany


# loop through workbooks
for tech_spec_wb_path in tech_spec_wb_paths:

	tech_spec_wb = load_workbook(tech_spec_wb_path, read_only=False, data_only=True) # read-only mode is super slow, if multiple calls like data[workbook][worksheet]['A1'] are used. It forces the library to parse the worsheet again and again
	
	meta_sheet_names = [string for string in tech_spec_wb.sheetnames if string[5:] in sda_sheet_names and string[0:5] == 'META_']
	data_sheet_names = [string for string in tech_spec_wb.sheetnames if string[5:] in sda_sheet_names and string[0:5] == 'DATA_']
	conv_sheet_names = [string for string in tech_spec_wb.sheetnames if string[5:] in sda_sheet_names and string[0:5] == 'CONV_']

	meta_dct = all_datasets_by_table_name(tech_spec_wb, meta_sheet_names, table_name_pattern='Nazwa ekstraktu', offset_header_rows=0, orientation='V')
	data_dct = all_datasets_by_table_name(tech_spec_wb, data_sheet_names, table_name_pattern='Lp.', offset_header_rows=2, orientation='H')
	conv_dct = all_datasets_by_table_name(tech_spec_wb, conv_sheet_names, table_name_pattern='Lp.', offset_header_rows=0, orientation='H')

	# filter only first row
	meta_dct = {sheet_name: [table_body[0]] for sheet_name, table_body in meta_dct.items() if table_body}
	
	meta_key_map = {
		'Nazwa ekstraktu': 'extract_nm',
		'Opis ekstraktu': '',
		'Warstwa dolecowa': '',
		'Silnik źródłowej DB': '',
		'Typ ekstraktu': '',
		# t16
		'Nazwa datasetu': 'dataset_nm',
		'Nazwa tabeli': 'table_nm',
		'Nazwa projektu w GCP': 'project_id',
		'Nazwa pakietu ETL': 'gcp_etl_pkg_cd',
		'Sposób generowania TI sem': 'sin_ti_sem_mode_cd',
		'Nazwa semafora ANOW': 'sin_ti_sem_nm',
		# t10
		'Kolumna partycjonowania': 'partitioned_by',
		'Lista kolumn klucza głównego': 'pk_column_list',
		'Typ tabeli': 'model_table_type_cd',
		# t02
		'Schemat tabeli źródłowej': 'schema_nm',
		'Kod systemu źródłowego': 'sys_cd',
		# t07
		# 'Nazwa datasetu': 'gcp_dataset_nm',
		# 'Nazwa tabeli': 'gcp_table_nm',
		'Typ danych źródłowych': 'delivery_type_cd',
		'Nazwa połączenia do DB': 'db_connection_nm',
		'Tryb ekstraktu': 'extract_mode_cd',
		'Współczynnik zrównoleglenia': 'parallel_factor_num',
		'Mail dla notyfikacji': 'notification_mail',
		'Format pliku': 'file_format',
		'Nazwa grupy procesu': 'workload_grp_cd',
		'Ścieżka do pliku po konwersji': 'gcp_data_root_path',
		'Ścieżka pliku do konwersji': 'gcp_data_root_in_path',
		'Nazwa node ANOW do połącznia z VM': 'tgt_sin_os_node_nm',
		'Wersja konwertera': 'converter_type_cd',
		'Flaga ekstrakcji': 'extraction_flg',
		'Flaga transformacji': 'transform_flg',
		'Flaga ładowania GCS': 'gcs_load_flg',
		'Flaga ładowania BQ': 'bq_load_flg',
		'Nazwa WFL ANOW': 'process_sin_wfl_nm',
		'Nazwa folderu IPC': 'ipc_folder_nm',
		'Nazwa repozytorium IPC': 'ipc_repository_nm',
		'Program czytający': 'reading_program_nm',
		'Warunek filtrowania danych': 'src_filter_condition',
		'Czy nowy system?': '',
		# t18
		'ID interfejsu': '',
		'Parametr in_file_cd': 'in_file_cd',
		'Opis dla in_file_cd': 'in_file_desc',
		# 'Kod systemu źródłowego': 'input_file_sys_cd',
		'Format pliku_2': 'file_type',
		'Pochodzenie pliku': 'storage_type',
		'Źródło': 'resource_nm',
		'Ścieżka pliku': 'file_path',
		'Maska nazwy pliku': 'file_name_mask',
		'Pola w nazwie pliku': 'file_name_fields',
		'Kodowanie znaków': 'character_encoding_system',
		'Strona kodowa': 'character_encoding_cd',
		'Liczba pominiętych linii': 'skipped_number_lines',
		'Czy nagłówek': 'is_header',
		'Czy stopka': 'is_footer',
		'Separator rekordu': 'record_separator',
		'Separator pola': 'field_separator',
		'Separator dziesiętny': 'decimal_point',
		'Separator tysięczny': 'digit_separator',
		'Typ wejścia': 'file_input_type',
		'Czy string w cudzysłowie': 'is_quote',
		'Czy string w podwójnym cudzysłowie': 'is_double_quote',
		'Znak cytowania w formacie hex': 'quote',
		# t20
		'Parametr out_file_cd': 'out_file_cd',
		'Obszar, w którym tworzony jest plik': 'file_area',
		'Ścieżka do pliku': 'file_path_2',
		'Format nazwy pliku': 'file_name_format',
		'Czy nagłówek_3': 'is_header_2',
		'Czy stopka_4': 'is_footer_2',
		'Separator rekordu_5': 'record_separator_2',
		'Separator pola_6': 'field_separator_2',
		'Kodowanie znaków_7': 'character_encoding_system_2',
		'Strona kodowa_8': 'character_encoding_cd_2',
		'Typ docelowego zasobu do zapisu': 'gcp_resource_type',
		'Separator dziesiętny_9': 'decimal_point_2',
		'Separator tysięczny_10': 'digit_separator_2',
		# t06
		'Nazwa kodowa grupy': 'workload_grp_cd',
		'Maksymalne dopusczalne obciążenie': 'max_parallel_fctr_num',
		# t25
		# 'in_file_FULL_mode_file_nm': 'in_file_full_mode_file_nm',
		# 'in_file_INCR_mode_file_nm': 'in_file_incr_mode_file_nm',

	}

	# rename column names
	meta_dct = {table_nm: [{meta_key_map.get(column_nm, column_nm): column_val for column_nm, column_val in table_row_dct.items()} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}


	# add missing keys
	for meta_sheet_name, data_sheet_name, conv_sheet_name in zip(meta_sheet_names, data_sheet_names, conv_sheet_names):
		meta_dct[meta_sheet_name][0]['gcp_project_nm'] = 'GCP_DTLK_PROJECT_ID'  # t18
		meta_dct[meta_sheet_name][0]['input_file_sys_cd'] = meta_dct[meta_sheet_name][0]['sys_cd']  # t18
		meta_dct[meta_sheet_name][0]['gcp_dataset_nm'] = meta_dct[meta_sheet_name][0]['dataset_nm']  # t07
		meta_dct[meta_sheet_name][0]['gcp_table_nm'] = meta_dct[meta_sheet_name][0]['table_nm']  # t07
		meta_dct[meta_sheet_name][0]['gcp_etl_pkg_cd'] = f"{meta_dct[meta_sheet_name][0]['sys_cd']}_01"  # t07
		# meta_dct[meta_sheet_name][0]['publish_method_cd'] = 'SIMPLE'  # t07 ## TODO: sprawdzić czy używane czy nie
		# meta_dct[meta_sheet_name][0]['chunking_type_cd'] = 'full'  # t07 ## TODO: sprawdzić czy używane czy nie
		meta_dct[meta_sheet_name][0]['project_id'] = 'GCP_DTLK_PROJECT_ID'  # t10
		meta_dct[meta_sheet_name][0]['model_table_type_cd'] = 'EDA_DSA'  # t10
		meta_dct[meta_sheet_name][0]['default_mode_cd'] = 'INCR'  # t10
		meta_dct[meta_sheet_name][0]['sin_publish_sem_nm'] = None  # t10
		meta_dct[meta_sheet_name][0]['sin_metric_nm'] = None  # t10
		meta_dct[meta_sheet_name][0]['file_sys_cd'] = meta_dct[meta_sheet_name][0]['sys_cd']  # t18
		meta_dct[meta_sheet_name][0]['storage_type'] = meta_dct[meta_sheet_name][0]['storage_type'].lower()  # t18


	# filter columns
	t16_filter_column_names = ['dataset_nm','table_nm','project_id','gcp_etl_pkg_cd','sin_ti_sem_mode_cd','sin_ti_sem_nm']
	t16_dct = {table_nm: [{column_nm: column_val for column_nm, column_val in table_row_dct.items() if column_nm in t16_filter_column_names} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}
	t10_filter_column_names = ['project_id', 'model_table_type_cd','partitioned_by','pk_column_list', 'dataset_nm', 'table_nm','default_mode_cd','sin_publish_sem_nm','sin_metric_nm']
	t10_dct = {table_nm: [{column_nm: column_val for column_nm, column_val in table_row_dct.items() if column_nm in t10_filter_column_names} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}
	t02_filter_column_names = ['schema_nm','sys_cd']
	t02_dct = {table_nm: [{column_nm: column_val for column_nm, column_val in table_row_dct.items() if column_nm in t02_filter_column_names} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}
	t07_filter_column_names = ['gcp_dataset_nm','gcp_table_nm','sys_cd','delivery_type_cd','db_connection_nm','extract_mode_cd','parallel_factor_num','notification_mail','file_format','workload_grp_cd','gcp_data_root_path','gcp_data_root_in_path','tgt_sin_os_node_nm','converter_type_cd','extraction_flg','transform_flg','gcs_load_flg','bq_load_flg','process_sin_wfl_nm','ipc_folder_nm','ipc_repository_nm','reading_program_nm','src_filter_condition','gcp_etl_pkg_cd','publish_method_cd','chunking_type_cd','src_file_nm_mask','src_dir_path','src_sem_file_regexp','src_sem_file_mask','src_sem_dir_path','src_sem_sin_fm_node','src_sin_os_node_nm','delete_src_file_flg','scd2_infinite_dt','scd2_start_dt_col_nm','src_pkg_cd_col_nm']
	t07_dct = {table_nm: [{column_nm: column_val for column_nm, column_val in table_row_dct.items() if column_nm in t07_filter_column_names} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}
	t18_filter_column_names = ['in_file_cd','in_file_desc','input_file_sys_cd','file_type','storage_type','resource_nm','file_path','file_name_mask','file_name_fields','character_encoding_system','character_encoding_cd','skipped_number_lines','is_header','is_footer','record_separator','field_separator','decimal_point','digit_separator','file_input_type','is_quote','is_double_quote','quote']
	t18_dct = {table_nm: [{column_nm: column_val for column_nm, column_val in table_row_dct.items() if column_nm in t18_filter_column_names} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}
	t20_filter_column_names = ['file_sys_cd','out_file_cd','file_area','file_name_format','gcp_resource_type','decimal_point','digit_separator']
	t20_dct = {table_nm: [{column_nm: column_val for column_nm, column_val in table_row_dct.items() if column_nm in t20_filter_column_names} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}
	t06_filter_column_names = ['workload_grp_cd','max_parallel_fctr_num']
	t06_dct = {table_nm: [{column_nm: column_val for column_nm, column_val in table_row_dct.items() if column_nm in t06_filter_column_names} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}
	t25_filter_column_names = ['in_file_full_mode_file_nm','in_file_incr_mode_file_nm']
	t25_dct = {table_nm: [{column_nm: column_val for column_nm, column_val in table_row_dct.items() if column_nm in t25_filter_column_names} for table_row_dct in table_rows_lst] for table_nm, table_rows_lst in meta_dct.items()}
	
	t19_dct = {}
	t21_dct = {}
	# t21_dct = conv_dct
	t22_dct = deepcopy(t18_dct)
	t22_dct = {sheet_name: [{}] for sheet_name, row_lst in t22_dct.items() if row_lst} # create empty dict structure


	for meta_sheet_name, data_sheet_name, conv_sheet_name in zip(meta_sheet_names, data_sheet_names, conv_sheet_names):

		# get values
		file_cd = deepcopy(t18_dct[meta_sheet_name][0]['in_file_cd'].strip().lower())[3:]


		# update values
		# t07_dct[meta_sheet_name][0]['file_format'] = 'avro'
		# t07_dct[meta_sheet_name][0]['gcp_dataset_nm'] = t07_dct[meta_sheet_name][0]['gcp_dataset_nm'].lower()
		# t07_dct[meta_sheet_name][0]['gcp_table_nm'] = t07_dct[meta_sheet_name][0]['gcp_table_nm'].lower()
		# t07_dct[meta_sheet_name][0]['src_file_nm_mask'] = None
		# t07_dct[meta_sheet_name][0]['src_dir_path'] = None
		# t07_dct[meta_sheet_name][0]['src_sem_file_regexp'] = None
		# t07_dct[meta_sheet_name][0]['src_sem_file_mask'] = None
		# t07_dct[meta_sheet_name][0]['src_sem_dir_path'] = None
		# t07_dct[meta_sheet_name][0]['src_sem_sin_fm_node'] = None
		# t07_dct[meta_sheet_name][0]['src_sin_os_node_nm'] = None
		# t07_dct[meta_sheet_name][0]['delete_src_file_flg'] = None
		# t07_dct[meta_sheet_name][0]['scd2_infinite_dt'] = None
		# t07_dct[meta_sheet_name][0]['scd2_start_dt_col_nm'] = None
		# t07_dct[meta_sheet_name][0]['src_pkg_cd_col_nm'] = None


		# if t18_dct[meta_sheet_name][0]['digit_separator'].strip() != '':
		# 	digit_separator_hex = f"0x{t18_dct[meta_sheet_name][0]['digit_separator'].encode('utf-8').hex()}"
		# else:
		# 	digit_separator_hex = ''

		if t18_dct[meta_sheet_name][0]['is_header'].strip().upper() == 'TRUE':
			is_header_val = True
		elif t18_dct[meta_sheet_name][0]['is_header'].strip().upper() == 'FALSE':
			is_header_val = False
		else:
			is_header_val = None

		if t18_dct[meta_sheet_name][0]['is_footer'].strip().upper() == 'TRUE':
			is_footer_val = True
		elif t18_dct[meta_sheet_name][0]['is_footer'].strip().upper() == 'FALSE':
			is_footer_val = False
		else:
			is_footer_val = None

		if t18_dct[meta_sheet_name][0]['is_quote'].strip().upper() == 'TRUE':
			is_quote_val = True
		elif t18_dct[meta_sheet_name][0]['is_quote'].strip().upper() == 'FALSE':
			is_quote_val = False
		else:
			is_quote_val = None

		if t18_dct[meta_sheet_name][0]['is_double_quote'].strip().upper() == 'TRUE':
			is_double_quote_val = True
		elif t18_dct[meta_sheet_name][0]['is_double_quote'].strip().upper() == 'FALSE':
			is_double_quote_val = False
		else:
			is_double_quote_val = None

		# t18_dct[meta_sheet_name][0]['in_file_cd'] = f'in_{file_cd}'
		t18_dct[meta_sheet_name][0]['record_separator'] = re.sub('^\w+ - ', '', t18_dct[meta_sheet_name][0]['record_separator']).lower()
		t18_dct[meta_sheet_name][0]['field_separator'] = re.sub('^\w+ - ', '', t18_dct[meta_sheet_name][0]['field_separator']).lower()
		t18_dct[meta_sheet_name][0]['decimal_point'] = re.sub('^\w+ - ', '', t18_dct[meta_sheet_name][0]['decimal_point']).lower()
		t18_dct[meta_sheet_name][0]['digit_separator'] = re.sub('^\w+ - ', '', t18_dct[meta_sheet_name][0]['digit_separator']).lower()
		t18_dct[meta_sheet_name][0]['is_header'] = is_header_val
		t18_dct[meta_sheet_name][0]['is_footer'] = is_footer_val
		t18_dct[meta_sheet_name][0]['is_double_quote'] = is_quote_val
		t18_dct[meta_sheet_name][0]['is_quote'] = is_double_quote_val


		# if t20_dct[sheet_name][0]['record_separator'].strip().upper() == 'CRLF':
		# 	record_separator_hex = '0x0a'
		# elif t20_dct[sheet_name][0]['record_separator'].strip().upper() == 'LF':
		# 	record_separator_hex = '0x0a'
		# else:
		# 	record_separator_hex = f"0x{t20_dct[sheet_name][0]['record_separator'].encode('utf-8').hex()}"

		# if t20_dct[sheet_name][0]['digit_separator'].strip() != '':
		# 	digit_separator_hex = f"0x{t20_dct[sheet_name][0]['digit_separator'].encode('utf-8').hex()}"
		# else:
		# 	digit_separator_hex = ''

		# t20_dct[sheet_name][0]['out_file_cd'] = f'out_{file_cd}'
		t20_dct[meta_sheet_name][0]['record_separator'] = '0x0a'
		t20_dct[meta_sheet_name][0]['character_encoding_system'] = 'UTF-8'
		t20_dct[meta_sheet_name][0]['character_encoding_cd'] = 'UTF-8'
		# t20_dct[meta_sheet_name][0]['field_separator'] = re.sub('^\w+ - ', '', meta_dct[meta_sheet_name][0]['field_separator_2'])
		t20_dct[meta_sheet_name][0]['field_separator'] = '0x7c'
		t20_dct[meta_sheet_name][0]['decimal_point'] = re.sub('^\w+ - ', '', meta_dct[meta_sheet_name][0]['decimal_point_2']).lower()
		t20_dct[meta_sheet_name][0]['digit_separator'] = re.sub('^\w+ - ', '', meta_dct[meta_sheet_name][0]['digit_separator_2']).lower()
		t20_dct[meta_sheet_name][0]['file_path'] = re.sub('^\w+ - ', '', meta_dct[meta_sheet_name][0]['file_path_2']).lower()
		t20_dct[meta_sheet_name][0]['file_type'] = 'avro'
		t20_dct[meta_sheet_name][0]['is_header'] = True
		t20_dct[meta_sheet_name][0]['is_footer'] = False


		# # add missing keys
		timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
		t06_dct[meta_sheet_name][0]['tech_insert_ts'] = timestamp_str


		# # add missing keys
		t07_dct[meta_sheet_name][0]['container_nm'] = 'TRANSPORTER'
		t07_dct[meta_sheet_name][0]['extract_nm'] = f'out_{file_cd}'
		# t07_dct[meta_sheet_name][0]['sys_cd'] = 'OZSI'
		t07_dct[meta_sheet_name][0]['processing_state_cd'] = 'ACTIVE'
		# t07_dct[meta_sheet_name][0]['delivery_type_cd'] = 'BUCKET_FILE'
		# t07_dct[meta_sheet_name][0]['parallel_factor_num'] = 1
		# t07_dct[meta_sheet_name][0]['workload_grp_cd'] = 'TRPT' # jeżeli plik to TRPT a jeżeli DB to ustalić grupę
		t07_dct[meta_sheet_name][0]['converter_type_cd'] = 'GENERIC'
		t07_dct[meta_sheet_name][0]['gcp_bucket_nm'] = '<GCP_BUCKET_NM>'
		t07_dct[meta_sheet_name][0]['gcp_project_nm'] = 'GCP_DTLK_PROJECT_ID'
		t07_dct[meta_sheet_name][0]['pipeline_app'] = 'SIN'
		# t07_dct[meta_sheet_name][0]['extraction_flg'] = '0'
		# t07_dct[meta_sheet_name][0]['transform_flg'] = '0'
		# t07_dct[meta_sheet_name][0]['gcs_load_flg'] = '0'
		# t07_dct[meta_sheet_name][0]['bq_load_flg'] = '1'
		t07_dct[meta_sheet_name][0]['conversion_cd'] = f'in_{file_cd}_2_out_{file_cd}'
		# t07_dct[meta_sheet_name][0]['file_num'] = 1
		# t07_dct[meta_sheet_name][0]['data_chunk_size'] = 0

		t22_dct[meta_sheet_name][0]['conversion_cd'] = f'in_{file_cd}_2_out_{file_cd}'
		t22_dct[meta_sheet_name][0]['conversion_dsc'] = f'in_{file_cd}_2_out_{file_cd}'
		t22_dct[meta_sheet_name][0]['in_file_cd'] = f'in_{file_cd}'
		t22_dct[meta_sheet_name][0]['out_file_cd'] = f'out_{file_cd}'
		t22_dct[meta_sheet_name][0]['program_conversion'] = ''
		t22_dct[meta_sheet_name][0]['program_path'] = ''

		t25_dct[meta_sheet_name][0]['in_file_cd'] = f'in_{file_cd}'
		t25_dct[meta_sheet_name][0]['file_name_extract_mode'] = 'P'
		t25_dct[meta_sheet_name][0]['extract_mode_cd'] = 'INCR'

		t25_dct[meta_sheet_name].append({'in_file_cd': f'in_{file_cd}', 'file_name_extract_mode': 'C', 'extract_mode_cd': 'FULL'})
		# t25_dct[meta_sheet_name][1]['in_file_cd'] = ''
		# t25_dct[meta_sheet_name][1]['file_name_extract_mode'] = ''
		# t25_dct[meta_sheet_name][1]['extract_mode_cd'] = ''

		# for row in t07_dct[sheet_name]:
		# 	t07_row_dct = {
		# 		'table_nm': row['gcp_table_nm'],
		# 		'dataset_nm': row['gcp_dataset_nm'],
		# 		'project_id': 'GCP_DTLK_PROJECT_ID',
		# 		'gcp_etl_pkg_cd': row['gcp_etl_pkg_cd'],
		# 		'sin_ti_sem_nm': f"DTLK_RSC_SEM_TI_DATALAKE_GCP_{row['gcp_dataset_nm'].upper()}_{row['gcp_table_nm'].upper()}_{row['gcp_etl_pkg_cd'].upper()}",
		# 		'sin_ti_sem_mode_cd': 'SINGLE'
		# 	}
		# 	t16_dct.setdefault(sheet_name, []).append(t07_row_dct)


		for num, row in enumerate(data_dct[data_sheet_name]):
			file_cd = deepcopy(t18_dct[meta_sheet_name][0]['in_file_cd'].strip().lower())[3:]
			
			if row['Typ danych wyjściowych'].lower() == 'numeric':
				data_type = 'decimal'
			else:
				data_type = row['Typ danych wyjściowych'].lower()

			t19_input_row_dct = {
				'in_out_file_cd': f'in_{file_cd}',
				'in_out_cd': 'in',
				'field_nm': row['Pole interfejsu źródłowego/tabeli'].upper(),
				'field_index': num,
				'field_type': data_type,
				'fileld_length': row['Długość pola'],
				'field_length_precision': '',
				'field_length_scale': '',
				'filed_format': row['Format'],
			}
			
			
			if row['Typ danych wyjściowych'].lower() == 'numeric':
				data_type = 'decimal'
			else:
				data_type = row['Typ danych wyjściowych'].lower()

			# if len(re.split(r'[.,]', row['Długość pola'])) > 1 and row['Typ danych wyjściowych'].lower() in ['numeric', 'decimal', 'number']:
			# 	scale = re.split(r'[.,]', row['Długość pola'])[1]
			# elif len(re.split(r'[.,]', row['Długość pola'])) > 1 and row['Typ danych wyjściowych'].lower() not in ['numeric', 'decimal', 'number']: 
			# 	scale = 0
			# else:
			# 	scale = ''

			# if len(re.split(r'[.,]', row['Długość pola'])) > 1 and row['Typ danych wyjściowych'].lower() in ['numeric', 'decimal', 'number']:
			# 	precision = re.split(r'[.,]', row['Długość pola'])[0]
			# else:
			# 	precision = ''


			t19_output_row_dct = {
				'in_out_file_cd': f'out_{file_cd}',
				'in_out_cd': 'out',
				'field_nm': row['Pole interfejsu wyjściowego/tabeli'].upper(),
				'field_index': num,
				'field_type': data_type,
				'fileld_length': '',
				'field_length_precision': row['Precyzja_9'],
				'field_length_scale': row['Skala_10'],
				'filed_format': '',
			}
			
			# Adding the rows to the processed list
			t19_dct.setdefault(data_sheet_name, []).append(t19_input_row_dct)
			t19_dct.setdefault(data_sheet_name, []).append(t19_output_row_dct)


			def conversion_type_func(data_type):
				if data_type.lower() == 'string':
					return 'text'
				else:
					return 'none'

			t21_row_dct = {
				'conversion_index': str(num + 1),
				'src_field_nm': row['Pole interfejsu źródłowego/tabeli'].upper(),
				'output_field_nm': row['Pole interfejsu wyjściowego/tabeli'].upper(),
				'conversion_type': conversion_type_func(row['Typ danych wyjściowych']),
				'conversion_cd': f'in_{file_cd}_2_out_{file_cd}',
				'conversion_field_index': 1,
				'output_file_cd': f'out_{file_cd}',
				'src_file_cd': f'in_{file_cd}',
				'regex_value': '',
				'default_value': ''
			}
			t21_dct.setdefault(data_sheet_name, []).append(t21_row_dct)


		# remove keys
		# del t18_dct[meta_sheet_name][0]['']


	for meta_sheet_name, data_sheet_name, conv_sheet_name in zip(meta_sheet_names, data_sheet_names, conv_sheet_names):
		generate_ddl_files(data_dct[data_sheet_name],t10_dct[meta_sheet_name], output_package_path)
	generate_metadata_files(data_dct, t16_dct, t18_dct, t19_dct, t20_dct, t21_dct, t22_dct, t10_dct, t07_dct, t06_dct, t25_dct, output_path, output_package_path, xDA, package_name, meta_sheet_names, data_sheet_names)
	generate_install_files(output_package_path, package_name)

	print(f'\n\n\n\n\n\n{package_name} pacgkage generated!\n\n')

